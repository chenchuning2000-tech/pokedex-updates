import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import db,hub,pop_sync,app

class SnapshotTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();root=Path(self.tmp.name);(root/'data').mkdir()
  (root/'data/name_map.json').write_text(json.dumps({'1':{'ja':'フシギダネ','en':'Bulbasaur'}}))
  self.rootpatch=patch.object(pop_sync,'ROOT',root);self.rootpatch.start()
  self.c=db.init(str(root/'data/cards.db'));hub.init(self.c)
  self.c.execute("INSERT INTO sets(set_id,lang,name) VALUES('en:base1','en','Base')")
  self.c.execute("INSERT INTO cards(card_id,set_id,lang,name,number,rarity_tier) VALUES('en:base1-1','en:base1','en','Alakazam','1',5)")
  self.c.execute("INSERT INTO sets(set_id,lang,name) VALUES('ja:sv1','ja','merged')")
  self.c.commit()
 def tearDown(self):self.c.close();self.rootpatch.stop();self.tmp.cleanup()
 def core(self,rows=None):
  rows=rows or [('Alakazam-Holo','Base',10,100),('Alakazam-Reverse Foil','Base',2,20)]
  data=dict(si=[],num=[],name=[],par=[],g10=[],g9=[],tot=[],img=[],lang=[])
  for name,par,p10,total in rows:
   for k,v in dict(si=0,num='1',name=name,par=par,g10=p10,g9=0,tot=total,img='p:base1/1',lang='en').items():data[k].append(v)
  return {'sets':[[1999,'Game','en']],'cards':data},{'built':'2026-11-23','cards':len(rows),'sets':1}
 def test_variant_name_preserved_and_idempotent(self):
  core,meta=self.core();a=pop_sync.apply(self.c,core,meta);b=pop_sync.apply(self.c,core,meta)
  self.assertEqual(a['new_coverage'],1);self.assertEqual(b['new_coverage'],0)
  self.assertEqual(self.c.execute('select count(*) from current_variants').fetchone()[0],2)
  self.assertEqual(self.c.execute('select psa_total from cards where lang="en"').fetchone()[0],120)
  self.assertEqual(self.c.execute('select pop_scope from cards where lang="en"').fetchone()[0],'matched_variants')
 def test_newer_report_preserved(self):
  self.c.execute("UPDATE cards SET psa_total=500,psa_10=200,psa_report_date='2026-11-24'");self.c.commit()
  core,meta=self.core();r=pop_sync.apply(self.c,core,meta)
  self.assertEqual(r['preserved_newer'],1)
  self.assertEqual(self.c.execute('select psa_total from cards').fetchone()[0],500)
 def test_no_number_or_wrong_name_never_matches(self):
  m=pop_sync.Matcher(self.c)
  self.assertIsNone(m.match(dict(lang='en',num='',set_name='Game',name='Alakazam',img='p:base1/1'))[0])
  self.assertIsNone(m.match(dict(lang='en',num='1',set_name='Game',name='Charizard',img='p:base1/1'))[0])
 def test_duplicate_source_keys_rejected(self):
  core,meta=self.core([('Alakazam-Holo','Base',10,100)]*2)
  r,rows,miss=pop_sync.plan(self.c,core,meta);self.assertEqual(len(rows),0);self.assertEqual(r['reasons']['duplicate_source_key'],2)
 def test_split_japanese_code_and_duplicate_local_ids(self):
  for cid,code in [('ja:1','SV1S'),('ja:2','SV1V')]:
   self.c.execute('INSERT INTO cards(card_id,set_id,lang,name,number,image_large) VALUES(?,?,?,?,?,?)',(cid,'ja:sv1','ja','フシギダネ','001',f'https://www.pokemon-card.com/assets/images/card_images/large/{code}/x.jpg'))
  self.c.commit();m=pop_sync.Matcher(self.c)
  r=dict(lang='jp',num='001',set_name='Japanese Sv1s-Scarlet EX',name='Bulbasaur',img='')
  self.assertEqual(m.match(r)[0],'ja:1')
  self.c.execute("INSERT INTO cards(card_id,set_id,lang,name,number,image_large) SELECT 'ja:3',set_id,lang,name,number,image_large FROM cards WHERE card_id='ja:1'");self.c.commit()
  self.assertIsNone(pop_sync.Matcher(self.c).match(r)[0])
 def test_old_pokedex_number_collision_blocked(self):
  # Deliberately create 12 species with identical Pokedex and modern set numbers.
  names={}
  for i in range(1,13):
   names[str(i)]={'ja':f'種{i}','en':f'Species{i}'}
   self.c.execute('INSERT INTO cards(card_id,set_id,lang,name,number,image_large,release_date) VALUES(?,?,?,?,?,?,?)',(f'ja:{i}','ja:sv1','ja',f'種{i}',str(i),'https://www.pokemon-card.com/assets/images/card_images/large/SV2A/x.jpg','2023-06-16'))
  (pop_sync.ROOT/'data/name_map.json').write_text(json.dumps(names))
  m=pop_sync.Matcher(self.c)
  rows=[dict(lang='jp',set_name='Japanese Basic',num=str(i),name=f'Species{i}',year=1996) for i in range(1,13)]
  m.infer_jp_sets(rows);self.assertNotIn('Japanese Basic',m.jp_aliases)
 def test_snapshot_shape_validation(self):
  core,meta=self.core();meta['cards']=999
  with self.assertRaises(ValueError):pop_sync.plan(self.c,core,meta)

if __name__=='__main__':unittest.main()
