// Run: node tests/test_frontend.cjs
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const elements=new Map();
const node=s=>{if(!elements.has(s))elements.set(s,{value:'',dataset:{},classList:{toggle(){},remove(){}},addEventListener(){}});return elements.get(s)};
const ctx=vm.createContext({console,URLSearchParams,setTimeout,clearTimeout,window:{addEventListener(){}},document:{addEventListener(){},querySelector:node,querySelectorAll:()=>[]},location:{hash:'#lang=all'},history:{replaceState(){}},fetch:()=>{throw Error('unexpected fetch')}});
vm.runInContext(fs.readFileSync(__dirname+'/../web/app.js','utf8').replace(/bind\(\);\s*boot\(\);\s*$/,''),ctx);
(async()=>{
vm.runInContext("readHash(); if(state.lang!=='ja')throw Error('old all bookmark'); renderGrid=()=>{}; renderFacets=()=>{}; showSkeleton=()=>{};",ctx);
assert.equal(vm.runInContext("SCOPE_ORDER.join(',')",ctx),'ja,en');
let pending=[];ctx.fetch=url=>new Promise(resolve=>pending.push({url,resolve}));
const first=vm.runInContext('load(true)',ctx);
vm.runInContext("state.lang='en'",ctx);
const second=vm.runInContext('load(true)',ctx);
pending[1].resolve({ok:true,json:async()=>({total:1,items:[{card_id:'en:new'}]})});await second;
pending[0].resolve({ok:true,json:async()=>({total:9,items:[{card_id:'ja:old'}]})});await first;
assert.equal(vm.runInContext('state.loaded[0].card_id',ctx),'en:new');
pending=[];
const a=vm.runInContext('reloadFacets()',ctx);
vm.runInContext("state.lang='ja';state.sets=['en:old'];state.rarities=['Rare']",ctx);
const b=vm.runInContext('reloadFacets()',ctx);
pending[1].resolve({ok:true,json:async()=>({sets:[{set_id:'ja:new'}],rarities:[{rarity:'C'}],variants:['Holo']})});await b;
pending[0].resolve({ok:true,json:async()=>({sets:[{set_id:'en:old'}],rarities:[{rarity:'Rare'}],variants:[]})});await a;
assert.equal(vm.runInContext('facets.sets[0].set_id',ctx),'ja:new');
assert.equal(vm.runInContext('state.sets.length+state.rarities.length',ctx),0);
vm.runInContext('bind()',ctx);node('#resetAll').onclick();
assert.equal(vm.runInContext('state.lang',ctx),'ja');
console.log('Frontend: legacy bookmarks, binary scope, stale responses, facet cleanup and reset passed');
})().catch(e=>{console.error(e);process.exitCode=1});
