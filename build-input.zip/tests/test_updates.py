import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app,db,hub,updater,scoring

class DataTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.path=str(Path(self.tmp.name)/'cards.db')
  self.c=db.init(self.path);hub.init(self.c)
  self.c.execute("INSERT INTO sets(set_id,lang,name) VALUES('en:sv','en','Example')")
  self.c.execute("INSERT INTO cards(card_id,set_id,lang,name,number,search_name,name_zh,psa_total,psa_10,psa_report_date,rarity_tier) VALUES('en:x','en:sv','en','Pikachu','001','皮卡丘pikachu','皮卡丘',100,5,'2026-10-01',4)")
  self.c.commit();self.ap=patch.object(app,'DB_PATH',self.path);self.ap.start()
 def tearDown(self):
  self.ap.stop();self.c.close();self.tmp.cleanup()
 def row(self,**kw):
  r=dict(card_id='en:x',source='gemrate',metric='pop',variant='Holo',report_date='2026-11-01',value='0',total='50');r.update(kw);return r
 def test_missing_pop_excluded_from_sort_filter_and_counts(self):
  self.c.execute("UPDATE cards SET psa10_rate=5 WHERE card_id='en:x'")
  for cid,total,p10,rate in [('en:missing',None,None,None),('en:zero',0,0,None),('en:zero10',40,0,0)]:
   self.c.execute('INSERT INTO cards(card_id,set_id,lang,name,psa_total,psa_10,psa10_rate) VALUES(?,?,?,?,?,?,?)',(cid,'en:sv','en',cid,total,p10,rate))
  self.c.commit()
  self.assertEqual(app.list_cards({})['total'],4)
  for sort in ['pop_asc','pop_desc']:
   result=app.list_cards({'sort':sort,'page_size':'1'})
   self.assertEqual(result['total'],3);self.assertEqual(result['pages'],3)
   self.assertNotIn('en:missing',[x['card_id'] for x in app.list_cards({'sort':sort})['items']])
  for sort in ['rate_asc','rate_desc']:
   self.assertEqual(app.list_cards({'sort':sort})['total'],2)
  zero=app.list_cards({'pop_min':'0','pop_max':'0'})
  self.assertEqual([r['card_id'] for r in zero['items']],['en:zero'])
  zero10=app.list_cards({'rate_max':'0'})
  self.assertEqual([r['card_id'] for r in zero10['items']],['en:zero10'])
  self.assertEqual(app.facet_data()['counts']['with_pop'],3)

 def test_preview_atomic_validation(self):
  self.assertTrue(hub.import_rows(self.c,[self.row()],True)['ok'])
  self.assertEqual(self.c.execute('SELECT count(*) FROM observations').fetchone()[0],0)
  r=hub.import_rows(self.c,[self.row(),self.row(card_id='unknown')],False)
  self.assertFalse(r['ok']);self.assertEqual(self.c.execute('SELECT count(*) FROM observations').fetchone()[0],0)
 def test_idempotent_zero_and_variant_latest(self):
  hub.import_rows(self.c,[self.row()],False);hub.import_rows(self.c,[self.row()],False)
  hub.import_rows(self.c,[self.row(report_date='2026-11-02',total='51',value='1')],False)
  hub.import_rows(self.c,[self.row(source='betterpop',report_date='2026-11-03',total='51',value='1')],False)
  self.assertEqual(len(app.card_detail('en:x')['variants']),1)
  self.assertEqual(app.card_detail('en:x')['psa_total'],100)
  self.assertEqual(scoring.psa10_rate(0,50),0)
  self.assertEqual(app.card_detail('en:x')['variants'][0]['source'],'betterpop')
 def test_total_import_and_older_not_override(self):
  hub.import_rows(self.c,[self.row(variant='__all__',value='0')],False)
  self.assertEqual(app.card_detail('en:x')['psa10_rate'],0)
  hub.import_rows(self.c,[self.row(variant='__all__',report_date='2026-09-01',value='10')],False)
  self.assertEqual(app.card_detail('en:x')['psa_10'],0)
  self.assertEqual(app.card_detail('en:x')['provenance']['report_date'],'2026-11-01')
 def test_same_variant_filter_and_search(self):
  hub.import_rows(self.c,[self.row(total='500',value='5'),self.row(variant='Reverse Holo',total='50',value='20')],False)
  self.assertEqual(app.list_cards({'variant_pop_max':'100','variant_10_max':'10'})['total'],0)
  self.assertEqual(app.list_cards({'variant':'Holo','variant_10_max':'10'})['total'],1)
  for q in ['皮卡丘','en:x','1']:
   if q=='1': self.c.execute("UPDATE cards SET number_int=1");self.c.commit()
   self.assertEqual(app.list_cards({'q':q})['total'],1)
 def test_price_dimensions_and_dedup(self):
  base=self.row(metric='market',variant='Holo',currency='USD',condition='raw',value='12')
  rows=[base,dict(base,variant='Reverse Holo'),dict(base,condition='PSA 10'),dict(base,currency='JPY'),dict(base,metric='trade',external_id='sale1'),dict(base,metric='trade',external_id='sale2')]
  hub.import_rows(self.c,rows,False);hub.import_rows(self.c,rows,False)
  result=app.price_series('en:x');self.assertEqual(len(result),5)
  trade=[v for v in result.values() if v['kind']=='trade'][0];self.assertEqual(trade['stats']['count'],2)
 def test_reject_bad_fields(self):
  for change in [dict(value='nan'),dict(total='-1'),dict(value='51'),dict(url='javascript:alert(1)'),dict(report_date='2099-01-01'),dict(variant=''),dict(metric='trade',currency='USD',condition='raw')]:
   self.assertFalse(hub.import_rows(self.c,[self.row(**change)],False)['ok'])
 def test_tcgcsv_matching_skips_ambiguous(self):
  p={'name':'Pikachu','extendedData':[{'name':'Number','value':'001/100'}]}
  self.assertEqual(updater.match_product(self.c,'en:sv',p),'en:x')
  p['name']='Pikachu V';self.assertIsNone(updater.match_product(self.c,'en:sv',p))
  self.assertIsNone(updater.match_set(self.c,{'name':'SV: Example Trainer Gallery'}))
 def test_catalog_preserves_pop_and_alias_and_adds(self):
  sets=[{'id':'sv','name':'Example','series':'Scarlet & Violet','releaseDate':'2026/11/01'}]
  cards=[{'id':'x','name':'Pikachu','number':'001'},{'id':'new','name':'Eevee','number':'002'}]
  with patch.object(updater,'fetch',side_effect=lambda url,*a,**k:sets if '/sets/' in url else cards):
   a,_,_=updater.sync_en(self.c);self.assertEqual(a,1)
   a,_,_=updater.sync_en(self.c);self.assertEqual(a,0)
  row=app.card_detail('en:x');self.assertEqual(row['psa_total'],100);self.assertEqual(row['name_zh'],'皮卡丘');self.assertIn('皮卡丘',row['search_name'])
 def test_jp_new_card_no_duplicate_or_set_overwrite(self):
  self.c.execute("INSERT INTO sets(set_id,lang,name,code) VALUES('ja:SV1','ja','Correct name','SV1')");self.c.commit()
  data={'maxPage':1,'cardList':[{'cardID':999,'cardNameViewText':'ピカチュウ','cardThumbFile':'/assets/images/card_images/large/SV1/test.jpg'}]}
  with patch.object(updater,'fetch',side_effect=lambda url,*a,**k:'<title>ピカチュウ | 公式</title><b> 001 / 078 </b>' if 'details.php' in url else data):
   a,_,_=updater.sync_ja(self.c);self.assertEqual(a,1)
   a,_,_=updater.sync_ja(self.c);self.assertEqual(a,0)
  self.assertEqual(self.c.execute("SELECT name FROM sets WHERE set_id='ja:SV1'").fetchone()[0],'Correct name')
 def test_failed_source_keeps_data_and_cools_down(self):
  def fail(c): raise OSError('offline')
  with patch.object(db,'init',side_effect=lambda:db.connect(self.path)),patch.object(updater,'FUNCTIONS',{'tcgcsv':fail}),patch.object(updater,'backup'):
   # No production updater process lock in unit tests.
   class Lock:
    def __enter__(self): return self
    def __exit__(self,*a):pass
   with patch.object(updater,'ProcessLock',Lock):
    r=updater.run();self.assertEqual(r['results'][0]['status'],'failed')
    r=updater.run();self.assertEqual(r['results'][0]['status'],'cooldown')
  self.assertEqual(app.card_detail('en:x')['psa_total'],100)
 def test_migration_idempotent_and_settings(self):
  hub.init(self.c);hub.init(self.c)
  self.assertEqual(hub.settings(self.c)['interval_hours'],24)
  with self.assertRaises(ValueError):hub.save_settings(self.c,{'interval_hours':1})
  hub.save_settings(self.c,{'enabled':False});self.assertFalse(hub.settings(self.c)['enabled'])

if __name__=='__main__':unittest.main()
