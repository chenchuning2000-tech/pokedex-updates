import hashlib,io,json,sqlite3,sys,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import software_update as sw
class SoftwareTests(unittest.TestCase):
 def setUp(self):
  self.v=patch.object(sw,'VERSION','2.4.0');self.v.start();self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.p=patch.object(sw,'ROOT',self.root);self.p.start();sw.folder()
 def tearDown(self):self.v.stop();self.p.stop();self.tmp.cleanup()
 def package(self,extra=None):
  buf=io.BytesIO()
  with zipfile.ZipFile(buf,'w') as z:
   for n,c in {'app.py':'# new app','software_update.py':'# updater','version.json':'{"version":"2.5.0"}',**(extra or {})}.items():z.writestr(n,c)
  blob=buf.getvalue();return blob,{'version':'2.5.0','url':'https://example.com/update.zip','size':len(blob),'sha256':hashlib.sha256(blob).hexdigest()}
 def stage(self):
  blob,m=self.package();sw.write(sw.folder()/'release.json',m)
  with patch.object(sw,'fetch',return_value=blob):sw.download()
 def test_version_order(self):
  self.assertGreater(sw.version('2.10.0'),sw.version('2.9.0'))
  with self.assertRaises(ValueError):sw.version('banana')
 def test_reject_unsafe_archive(self):
  for name in ['../outside.py','data/cards.db','config.json','C:/evil.py','web/../../evil.py']:
   blob,m=self.package({name:'bad'})
   with self.assertRaises(ValueError):sw.unpack(blob,m,self.root/'stage')
 def test_hash_and_python_validation(self):
  blob,m=self.package();m['sha256']='0'*64
  with self.assertRaises(ValueError):sw.unpack(blob,m,self.root/'stage')
  blob,m=self.package({'broken.py':'bad python code !'})
  with self.assertRaises(SyntaxError):sw.unpack(blob,m,self.root/'stage')
 def test_keep_data_and_backup(self):
  (self.root/'app.py').write_text('# old app');(self.root/'config.json').write_text('{"mine":true}')
  with sqlite3.connect(self.root/'data/cards.db') as c:c.execute('create table example(value)');c.execute('insert into example values (42)')
  self.stage();self.assertTrue(sw.apply_pending());self.assertEqual((self.root/'app.py').read_text(),'# new app')
  self.assertEqual((self.root/'config.json').read_text(),'{"mine":true}')
  for db in [self.root/'data/cards.db',sw.folder()/'backup/cards.db']:
   with sqlite3.connect(db) as c:self.assertEqual(c.execute('select value from example').fetchone()[0],42)
  self.assertEqual((sw.folder()/'backup/program/app.py').read_text(),'# old app')
 def test_tampered_stage_not_installed(self):
  self.stage();(sw.folder()/'staged/app.py').write_text('# altered')
  with self.assertRaises(ValueError):sw.apply_pending()
  self.assertFalse((self.root/'app.py').exists())
 def test_failed_install_restores_old_files(self):
  (self.root/'app.py').write_text('# old');self.stage();original=sw.os.replace
  def fail(src,dst):
   if str(src).endswith('software_update.py.upgrade-tmp'):raise OSError('disk write failed')
   return original(src,dst)
  with patch.object(sw.os,'replace',side_effect=fail):
   with self.assertRaises(OSError):sw.apply_pending()
  self.assertEqual((self.root/'app.py').read_text(),'# old')
  self.assertFalse((self.root/'software_update.py').exists())
 def test_interrupted_install_recovers(self):
  b=sw.folder()/'backup/program';b.mkdir(parents=True);(b/'app.py').write_text('# old');(self.root/'app.py').write_text('# new')
  sw.write(sw.folder()/'journal.json',{'files':{'app.py':True,'added.py':False}})
  (self.root/'added.py').write_text('# extra');self.assertFalse(sw.apply_pending())
  self.assertEqual((self.root/'app.py').read_text(),'# old');self.assertFalse((self.root/'added.py').exists())
 def test_manifest_and_https(self):
  for u in ['http://example.com/x','file:///tmp/x','https://user:pass@example.com/x']:
   with self.assertRaises(ValueError):sw.configure(u)
  sw.configure('https://example.com/latest.json');_,m=self.package()
  with patch.object(sw,'fetch',return_value=json.dumps(m).encode()):sw.check()
  self.assertEqual(sw.status()['status'],'available')
