"""SQLite 数据层：表结构、连接、查询构造。"""
from __future__ import annotations

import json
import os
import re
import sqlite3
from typing import Any

from runtime_paths import APP_ROOT
DB_PATH = str(APP_ROOT / "data" / "cards.db")

SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS sets (
  set_id        TEXT PRIMARY KEY,   -- 如 ja:m7 / en:sv3pt5
  lang          TEXT NOT NULL,      -- ja | en
  code          TEXT,               -- m7 / sv3pt5
  name          TEXT NOT NULL,
  name_en       TEXT,
  series        TEXT,
  era           TEXT,               -- 时代/世代 key，见 ERA_ORDER
  release_date  TEXT,
  printed_total INTEGER,
  total         INTEGER,
  is_promo      INTEGER DEFAULT 0,
  source_url    TEXT
);
CREATE INDEX IF NOT EXISTS idx_sets_lang ON sets(lang);
CREATE INDEX IF NOT EXISTS idx_sets_promo ON sets(is_promo);

CREATE TABLE IF NOT EXISTS cards (
  card_id       TEXT PRIMARY KEY,   -- ja:50856 / en:sv3pt5-2
  set_id        TEXT NOT NULL,
  lang          TEXT NOT NULL,
  number        TEXT,
  number_int    INTEGER,
  set_total     INTEGER,
  name          TEXT NOT NULL,
  name_en       TEXT,
  name_zh       TEXT,               -- 官方简体中文名（宝可梦种名）；训练家卡为 NULL
  name_core     TEXT,               -- 去掉修饰词的核心名
  search_tokens TEXT,               -- 空格分隔的检索 token（核心名+修饰词）
  zh_mapped     INTEGER DEFAULT 0,  -- 是否拿到官方中文名
  search_name   TEXT,               -- 归一化后的检索串（小写、去空格、片假名转平假名）
  rarity        TEXT,
  rarity_code   TEXT,
  rarity_tier   INTEGER,
  artist        TEXT,
  supertype     TEXT,
  image_small   TEXT,
  image_large   TEXT,
  price_usd     REAL,
  price_eur     REAL,
  price_date    TEXT,
  release_date  TEXT,
  is_promo      INTEGER DEFAULT 0,
  source_label  TEXT,               -- 具体来源（人话）
  source_url    TEXT,
  difficulty    REAL,
  diff_json     TEXT,
  psa_total     INTEGER,
  psa_10        INTEGER,
  psa_9         INTEGER,
  psa_8         INTEGER,
  psa_7         INTEGER,
  psa_half      INTEGER,            -- 8.5/9.5 等半档合计
  psa_lower     INTEGER,            -- 7 分以下
  psa_report_date TEXT,
  psa10_rate    REAL,
  pop_updated   TEXT,
  updated_at    TEXT,
  FOREIGN KEY (set_id) REFERENCES sets(set_id)
);
CREATE INDEX IF NOT EXISTS idx_cards_set    ON cards(set_id);
CREATE INDEX IF NOT EXISTS idx_cards_lang   ON cards(lang);
CREATE INDEX IF NOT EXISTS idx_cards_promo  ON cards(is_promo);
CREATE INDEX IF NOT EXISTS idx_cards_rarity ON cards(rarity);
CREATE INDEX IF NOT EXISTS idx_cards_pop    ON cards(psa_total);
CREATE INDEX IF NOT EXISTS idx_cards_rate   ON cards(psa10_rate);
CREATE INDEX IF NOT EXISTS idx_cards_diff   ON cards(difficulty);
CREATE INDEX IF NOT EXISTS idx_cards_name   ON cards(search_name);

CREATE TABLE IF NOT EXISTS pop_history (
  card_id     TEXT NOT NULL,
  report_date TEXT NOT NULL,
  psa_total   INTEGER,
  psa_10      INTEGER,
  PRIMARY KEY (card_id, report_date)
);

-- 变体级 pop：PSA 会把同一卡号的不同版本（普卡/闪卡/镜面/1st Edition…）
-- 拆成多行，每行是独立的评级存量。cards 表存的是这些变体的合计，
-- 明细放这里，避免「多行写同一张卡、后写覆盖前写」。
CREATE TABLE IF NOT EXISTS card_variants (
  card_id     TEXT NOT NULL,
  variant     TEXT NOT NULL,        -- PSA 名称栏第二行，如 Holo / Reverse Holo
  psa_total   INTEGER,
  psa_10      INTEGER,
  report_date TEXT NOT NULL,
  PRIMARY KEY (card_id, variant, report_date)
);
CREATE INDEX IF NOT EXISTS idx_cv_card ON card_variants(card_id);

CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT
);

-- 成交/挂价明细。每一次观测是一行，日K/月K/年K/全部 全部由这张表聚合出来。
-- kind: trade=已成交，listing=在售挂价
CREATE TABLE IF NOT EXISTS price_points (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id   TEXT NOT NULL,
  source    TEXT NOT NULL,          -- snkrdunk | ebay
  kind      TEXT NOT NULL DEFAULT 'trade',
  ts        TEXT NOT NULL,          -- ISO 日期 YYYY-MM-DDTHH:MM:SS
  price     REAL NOT NULL,
  currency  TEXT NOT NULL,          -- JPY | USD
  condition TEXT,                   -- raw / graded / PSA 10 ...
  url       TEXT,
  extra     TEXT,
  UNIQUE(card_id, source, kind, ts, price)
);
CREATE INDEX IF NOT EXISTS idx_pp_card ON price_points(card_id, source, ts);
CREATE INDEX IF NOT EXISTS idx_pp_ts   ON price_points(ts);

-- 卡片与外部商品页的对应关系，抓价时按这张表找目标页
CREATE TABLE IF NOT EXISTS card_links (
  card_id   TEXT NOT NULL,
  source    TEXT NOT NULL,          -- snkrdunk | ebay | psa
  external_id TEXT,                 -- 商品 id / item id / PSA 规格 id
  url       TEXT,
  matched_by TEXT,                  -- 匹配依据，便于人工核对
  confidence REAL,
  updated_at TEXT,
  PRIMARY KEY (card_id, source)
);
"""


def connect(path: str = DB_PATH) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=45)
    conn.row_factory = sqlite3.Row
    # 多个同步脚本可能同时写库，遇到锁就等，别立刻抛 database is locked
    conn.execute("PRAGMA busy_timeout=45000")
    return conn


def init(path: str = DB_PATH) -> sqlite3.Connection:
    conn = connect(path)
    conn.executescript(SCHEMA)
    # 兼容早期库：补 era 列并回填
    cols = {r[1] for r in conn.execute("PRAGMA table_info(sets)")}
    if "era" not in cols:
        conn.execute("ALTER TABLE sets ADD COLUMN era TEXT")
        conn.commit()
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sets_era ON sets(era)")
    backfill_era(conn)
    # 中文名/分词列（早期库补列）
    ccols = {r[1] for r in conn.execute("PRAGMA table_info(cards)")}
    for col, ddl in (("name_zh", "TEXT"), ("name_core", "TEXT"),
                     ("search_tokens", "TEXT"), ("zh_mapped", "INTEGER DEFAULT 0")):
        if col not in ccols:
            conn.execute(f"ALTER TABLE cards ADD COLUMN {col} {ddl}")
    conn.commit()
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cards_core ON cards(name_core)")
    conn.commit()
    conn.commit()
    return conn


def set_meta(conn: sqlite3.Connection, key: str, value: Any) -> None:
    conn.execute(
        "INSERT INTO meta(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)),
    )


def get_meta(conn: sqlite3.Connection, key: str, default: Any = None) -> Any:
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


# ---------------------------------------------------------------- 稀有度体系
# 统一分级：tier 越大越稀有，用于难度分与筛选排序
RARITY_TIERS = {
    # 通用/美版
    "common": 1, "uncommon": 2, "rare": 4, "rare holo": 5, "holo rare": 5,
    "rare holo v": 7, "rare ultra": 7, "rare secret": 9, "rare rainbow": 9,
    "double rare": 6, "ultra rare": 8, "illustration rare": 8,
    "special illustration rare": 9, "hyper rare": 9, "ace spec rare": 8,
    "amazing rare": 8, "radiant rare": 8, "shiny rare": 8, "shiny ultra rare": 9,
    "trainer gallery rare holo": 8, "rare prime": 7, "legend": 8, "rare break": 7,
    "promo": 6, "classic collection": 8, "rare holo gx": 7, "rare holo ex": 7,
    "rare holo vmax": 8, "rare holo vstar": 9, "rare shining": 9, "rare crystal": 9,
    "rare holo lv.x": 8, "rare ace": 8, "rare holo star": 9,
    # 日版图标代码
    "c": 1, "u": 2, "r": 4, "rr": 6, "rrr": 7, "ar": 8, "sar": 9, "sr": 9,
    "ur": 9, "chr": 8, "csr": 9, "k": 5, "pr": 6, "tr": 7, "ace": 8,
    "bwr": 9, "p": 6, "promo_p": 6,
}

RARITY_LABEL_JA = {
    "c": "C 普通", "u": "U 非普通", "r": "R 稀有", "rr": "RR 双稀有",
    "rrr": "RRR 三稀有", "ar": "AR 艺术稀有", "sar": "SAR 特别艺术稀有",
    "sr": "SR 超级稀有", "ur": "UR 究极稀有", "chr": "CHR 角色稀有",
    "csr": "CSR 角色特别稀有", "k": "K 关键卡", "pr": "PR 宣传卡",
    "tr": "TR 训练家稀有", "ace": "ACE 特殊", "bwr": "BWR 黑白稀有",
}


def rarity_tier(code: str | None, fallback_name: str | None = None) -> int:
    for key in (code, fallback_name):
        if not key:
            continue
        t = RARITY_TIERS.get(str(key).strip().lower())
        if t:
            return t
    return 3


# ---------------------------------------------------------------- 卡名分词
# 卡名 = 前缀(超级/阿罗拉…) + 核心名 + 后缀(ex/V/VMAX…)
# 拆开的目的是让搜索能区分「皮卡丘」和「皮卡丘ex」：
# 修饰词单独成 token，查询没覆盖到它就不命中。
PREFIX_EN = {
    "mega": "超级", "alolan": "阿罗拉", "galarian": "伽勒尔",
    "hisuian": "洗翠", "paldean": "帕底亚",
}
PREFIX_JA = {
    "メガ": "超级", "アローラ": "阿罗拉", "ガラル": "伽勒尔",
    "ヒスイ": "洗翠", "パルデア": "帕底亚",
}
NAME_SUFFIXES = [
    "VMAX", "VSTAR", "V-UNION", "V", "ex", "EX", "GX", "BREAK", "LV.X", "PRIME",
    "LEGEND", "STAR", "δ", "◇", "TAG TEAM", "TAGTEAM",
]


def split_card_name(raw: str) -> tuple[str, list[str], list[str]]:
    """返回 (core, prefixes, suffixes)，按原语言切，不翻译。"""
    s = (raw or "").strip()
    s = re.sub(r"[’']s\b", "", s)
    s = s.replace("★", "").replace("☆", "")
    prefixes: list[str] = []
    suffixes: list[str] = []

    low = s.lower()
    for k in sorted(PREFIX_EN, key=len, reverse=True):
        if low.startswith(k) and len(s) > len(k) + 1:
            prefixes.append(s[:len(k)].strip())
            s = s[len(k):].strip()
            break
    for k in sorted(PREFIX_JA, key=len, reverse=True):
        if s.startswith(k) and len(s) > len(k) + 1:
            prefixes.append(k)
            s = s[len(k):].strip()
            break

    for _ in range(2):
        matched = False
        for suf in sorted(NAME_SUFFIXES, key=len, reverse=True):
            if s.lower().endswith(" " + suf.lower()) and len(s) > len(suf) + 2:
                suffixes.insert(0, s[-len(suf):])
                s = s[: -len(suf)].strip()
                matched = True
                break
            if s.lower().endswith(suf.lower()) and len(s) > len(suf) + 2:
                if suf in ("V", "ex", "EX", "GX") and s[-len(suf) - 1:-len(suf)].isalpha():
                    continue
                suffixes.insert(0, s[-len(suf):])
                s = s[: -len(suf)].strip()
                matched = True
                break
        if not matched:
            break
    s = s.strip(" -–—·")
    return s, prefixes, suffixes


def normalize_search_name(name: str | None) -> str:
    """检索用归一化：小写、去空白与标点、片假名转平假名。
    这样「リザードン」「りざーどん」可互相命中；拉丁名走小写包含匹配。"""
    if not name:
        return ""
    out = []
    for ch in name:
        code = ord(ch)
        # 片假名 -> 平假名
        if 0x30A1 <= code <= 0x30F6:
            out.append(chr(code - 0x60))
        elif ch.isspace():
            continue
        elif ch in "・･-ー–—'\"’“”！!？?、,，。.:：;；()（）[]【】/／":
            continue
        else:
            out.append(ch.lower())
    return "".join(out)


# ---------------------------------------------------------------- 时代分类
# 顺序即 UI 展示顺序（新→旧由前端反转）
ERA_ORDER = [
    ("me", "超级进化 ME", "Mega Evolution"),
    ("sv", "朱·紫 SV", "Scarlet & Violet"),
    ("swsh", "剑·盾 SWSH", "Sword & Shield"),
    ("sm", "太阳·月亮 SM", "Sun & Moon"),
    ("xy", "XY", "XY"),
    ("bw", "黑·白 BW", "Black & White"),
    ("hgss", "心金·魂银 HGSS", "HeartGold & SoulSilver"),
    ("platinum", "白金 Pt", "Platinum"),
    ("dp", "钻石·珍珠 DP", "Diamond & Pearl"),
    ("ex", "ADV/EX", "EX"),
    ("ecard", "e-Card", "e-Card"),
    ("neo", "金·银 Neo", "Neo"),
    ("base", "初代 Base", "Base Set"),
    ("other", "其他", "Other"),
]
ERA_LABEL = {k: (zh, en) for k, zh, en in ERA_ORDER}
ERA_INDEX = {k: i for i, (k, _, _) in enumerate(ERA_ORDER)}

# 美版 series 名称 -> 时代
_EN_SERIES_ERA = {
    "base": "base", "gym": "base", "legendary collection": "neo",
    "neo": "neo", "e-card": "ecard", "ex": "ex", "pop": "ex",
    "diamond & pearl": "dp", "platinum": "platinum",
    "heartgold & soulsilver": "hgss", "call of legends": "hgss",
    "black & white": "bw", "xy": "xy", "sun & moon": "sm",
    "sword & shield": "swsh", "scarlet & violet": "sv",
    "mega evolution": "me",
}


def era_of(lang: str | None, series: str | None, code: str | None,
           name: str | None = None) -> str:
    """按语言分别判定时代。判不出来归 other，绝不猜。"""
    s = (series or "").strip().lower()
    if lang == "en" and s in _EN_SERIES_ERA:
        return _EN_SERIES_ERA[s]

    c = (code or "").strip().upper()
    # 日版 M 系列（M1、M2、M6a…）是メガシンカ/超级进化世代，前缀规则里没有 M
    if re.match(r"^M\d", c):
        return "me"
    # 长前缀优先，避免 SM 被 S 吃掉
    rules = [
        ("SV", "sv"), ("SM", "sm"), ("XY", "xy"), ("BW", "bw"),
        ("SWSH", "swsh"), ("PCG", "dp"), ("ADV", "ex"),
        ("DP", "dp"), ("S", "swsh"), ("L", "hgss"), ("E", "ecard"),
        ("V", "neo"), ("WEB", "neo"), ("PMCG", "base"),
    ]
    for prefix, era in rules:
        if c.startswith(prefix):
            # S 开头的要排除 SM/SV 已处理，且形如 S12 / S-P
            return era

    n = (name or "").lower()
    for kw, era in (("scarlet", "sv"), ("sword", "swsh"), ("sun & moon", "sm"),
                    ("sun and moon", "sm"), ("black & white", "bw"),
                    ("diamond", "dp"), ("platinum", "platinum"),
                    ("heartgold", "hgss"), ("neo", "neo"), ("base", "base"),
                    ("プロモ", "other")):
        if kw in n:
            return era
    return "other"


def backfill_era(conn: sqlite3.Connection) -> int:
    rows = conn.execute(
        "SELECT set_id,lang,series,code,name FROM sets WHERE era IS NULL").fetchall()
    for r in rows:
        era = era_of(r["lang"], r["series"], r["code"], r["name"])
        conn.execute("UPDATE sets SET era=? WHERE set_id=?", (era, r["set_id"]))
    if rows:
        conn.commit()
    return len(rows)
