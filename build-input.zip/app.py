"""宝可梦卡牌图鉴 —— 本地服务

启动：python app.py            （或双击 启动.bat）
默认地址：http://127.0.0.1:8777
"""
from __future__ import annotations

import argparse
import json
import mimetypes
import os
import sqlite3
import sys
import threading
import urllib.request
import webbrowser
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

import db
import scoring
import hub
import updater
import software_update
import secrets
SESSION_TOKEN = secrets.token_urlsafe(32)

from runtime_paths import ASSET_ROOT, FROZEN
WEB = str(ASSET_ROOT / "web")
DB_PATH = db.DB_PATH

# 汇率：手工配置项，改这里或在应用内「设置」里改。不做实时抓取，避免伪造精度。
DEFAULT_FX = {"jpy_cny": 0.0478, "usd_cny": 7.12, "as_of": "2026-11-23"}

_locks = threading.Lock()


# ------------------------------------------------------------------ 查询
def conn() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH, timeout=45, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout=45000")   # 后台同步时别读失败
    return c


def _like_norm(q: str) -> str:
    return db.normalize_search_name(q)


def query_tokens(q: str) -> list[str]:
    """按空格切词并归一化（大小写、片假名→平假名）。
    多关键词之间是 AND：每个词都要在卡名里出现。"""
    return [t for t in (db.normalize_search_name(x) for x in q.split()) if t]


def match_score(row, q_norm: str) -> int:
    """相关度：0=卡名等于查询，1=以查询开头，2=包含，3=仅别名命中。
    用于默认排序下把「皮卡丘」排在「皮卡丘ex」前面。"""
    names = [x for x in (row["name_en"], row["name"], row["name_zh"]) if x]
    norm = [db.normalize_search_name(x) for x in names]
    if any(n == q_norm for n in norm):
        return 0
    if any(n.startswith(q_norm) for n in norm):
        return 1
    if any(q_norm in n for n in norm):
        return 2
    return 3


def build_where(p: dict) -> tuple[str, list]:
    where, args = ["1=1"], []

    zone = (p.get("zone") or "all").lower()
    if zone == "promo":
        where.append("c.is_promo = 1")
    elif zone == "main":
        where.append("c.is_promo = 0")

    lang = (p.get("lang") or "all").lower()
    if lang in ("ja", "en"):
        where.append("c.lang = ?")
        args.append(lang)

    q = (p.get("q") or "").strip()
    if q:
        qts = query_tokens(q)
        if qts and not q.isdigit() and ":" not in q:
            # search_name 是归一化后的检索串（含中文名/原名/英文名/别名），
            # 每个词都要命中 -> 天然是「包含」语义：
            #   搜「皮卡丘」会带出「皮卡丘ex」（前者是后者子串）
            #   搜「皮卡丘 ex」只会出 ex 版
            for t in qts:
                where.append("IFNULL(c.search_name,'') LIKE ?")
                args.append(f"%{t}%")
        # 编号 / 卡牌 ID 精确命中
        if q.isdigit():
            where.append("c.number_int = ?")
            args.append(int(q))
        elif ":" in q:
            where.append("c.card_id = ?")
            args.append(q)

    sets = (p.get("set") or "").strip()
    if sets:
        ids = [s for s in sets.split(",") if s]
        where.append("c.set_id IN (%s)" % ",".join("?" * len(ids)))
        args += ids

    rar = (p.get("rarity") or "").strip()
    if rar:
        names = [r for r in rar.split(",") if r]
        where.append("c.rarity IN (%s)" % ",".join("?" * len(names)))
        args += names

    def num(key, col, cast=float):
        v = p.get(key)
        if v not in (None, ""):
            try:
                return cast(v)
            except (TypeError, ValueError):
                return None
        return None

    for key, col in (("pop_min", "c.psa_total"), ("pop_max", "c.psa_total"),
                     ("rate_min", "c.psa10_rate"), ("rate_max", "c.psa10_rate"),
                     ("diff_min", "c.difficulty"), ("diff_max", "c.difficulty")):
        v = num(key, col)
        if v is None:
            continue
        op = ">=" if key.endswith("_min") else "<="
        where.append(f"{col} IS NOT NULL AND {col} {op} ?")
        args.append(v)

    # Missing Pop is unknown, not zero. Sorting must exclude it from both rows
    # and pagination counts, rather than merely pushing it to the end.
    if p.get("sort") in ("pop_asc", "pop_desc", "rate_asc", "rate_desc"):
        where.append("c.psa_total IS NOT NULL")
    if p.get("sort") in ("rate_asc", "rate_desc"):
        where.append("c.psa10_rate IS NOT NULL")
    if p.get("has_rate") == "1" or any(p.get(k) not in (None, "") for k in ("rate_min", "rate_max")):
        where.append("c.psa_total IS NOT NULL")

    if p.get("has_pop") == "1":
        where.append("c.psa_total IS NOT NULL")
    if p.get("has_rate") == "1":
        where.append("c.psa10_rate IS NOT NULL")
    if p.get("graded") == "1":
        where.append("c.psa_total > 0")

    variant = (p.get("variant") or "").strip()
    if variant or p.get("variant_pop_max") or p.get("variant_10_max"):
        conditions = ["v.card_id=c.card_id"]
        if variant:
            conditions.append("instr(lower(v.variant),lower(?))>0")
            args.append(variant)
        for key,col in (("variant_pop_max","v.psa_total"),("variant_10_max","v.psa_10")):
            if p.get(key):
                val = int(p[key])
                if val < 0: raise ValueError("变体数量不能为负数")
                conditions.append(col+"<=?")
                args.append(val)
        where.append("EXISTS(SELECT 1 FROM current_variants v WHERE "+" AND ".join(conditions)+")")

    return " AND ".join(where), args


SORTS = {
    "relevance": "c.is_promo ASC, c.release_date DESC, c.set_id, c.number_int",
    "newest": "c.release_date DESC, c.set_id, c.number_int",
    "oldest": "c.release_date ASC, c.set_id, c.number_int",
    "pop_asc": "c.psa_total IS NULL, c.psa_total ASC",
    "pop_desc": "c.psa_total DESC",
    "rate_desc": "c.psa10_rate IS NULL, c.psa10_rate DESC",
    "rate_asc": "c.psa10_rate IS NULL, c.psa10_rate ASC",
    "diff_desc": "c.difficulty IS NULL, c.difficulty DESC",
    "diff_asc": "c.difficulty IS NULL, c.difficulty ASC",
    "name": "c.name COLLATE NOCASE ASC",
}


def list_cards(p: dict) -> dict:
    where, args = build_where(p)
    sort = SORTS.get(p.get("sort") or "relevance", SORTS["relevance"])
    try:
        page = max(1, int(p.get("page") or 1))
    except ValueError:
        page = 1
    try:
        size = min(200, max(1, int(p.get("page_size") or 60)))
    except ValueError:
        size = 60

    q = (p.get("q") or "").strip()
    qts = query_tokens(q) if q else []

    # 默认排序在有查询词时按相关度：完全等于 → 以查询开头 → 包含，最后按名字长度
    sort_args: list = []
    if qts and (p.get("sort") or "relevance") == "relevance":
        ql = q.strip().lower()
        sort = ("CASE WHEN lower(COALESCE(c.name_zh,c.name))=? THEN 0 "
                "WHEN lower(COALESCE(c.name_zh,c.name)) LIKE ? THEN 1 ELSE 2 END, "
                "length(COALESCE(c.name_zh,c.name)), c.release_date DESC, c.card_id")
        sort_args = [ql, ql + "%"]

    sel = f"""SELECT c.card_id,c.set_id,c.lang,c.number,c.set_total,c.name,c.name_en,
                     c.name_zh,c.zh_mapped,c.rarity,c.rarity_tier,c.artist,c.supertype,
                     c.image_small,c.image_large,c.release_date,c.is_promo,c.source_label,c.psa_report_date,c.pop_updated,c.pop_scope,
                     c.difficulty,c.psa_total,c.psa_10,c.psa10_rate,c.price_usd,c.price_eur,
                     s.name AS set_name, s.series, s.code, s.era
              FROM cards c LEFT JOIN sets s ON s.set_id=c.set_id
              WHERE {where} ORDER BY {sort}"""

    c = conn()
    try:
        total = c.execute(
            f"SELECT COUNT(*) n FROM cards c WHERE {where}", args).fetchone()["n"]
        rows = c.execute(sel + " LIMIT ? OFFSET ?",
                         args + sort_args + [size, (page - 1) * size]).fetchall()
        ids = [r["card_id"] for r in rows]
        price_map = fetch_price_brief(c, ids)
    finally:
        c.close()

    items = []
    for r in rows:
        d = dict(r)
        d["display_name"] = d.get("name_zh") or d["name"]
        d["difficulty_label"] = scoring.difficulty_label(d.get("difficulty"))
        d["price"] = price_map.get(d["card_id"], {})
        d.pop("search_tokens", None)
        items.append(d)
    return {"total": total, "page": page, "page_size": size,
            "pages": max(1, (total + size - 1) // size), "items": items}


def fetch_price_brief(c: sqlite3.Connection, ids: list[str]) -> dict:
    out = {}
    for cid in ids:
        r=c.execute("SELECT value,currency,report_date,variant FROM observations WHERE card_id=? AND source='tcgcsv' AND metric='market' ORDER BY report_date DESC,id DESC LIMIT 1",(cid,)).fetchone()
        if r:
            out[cid]={'tcgcsv':dict(last_price=r['value'],currency=r['currency'],last_ts=r['report_date'],variant=r['variant'])}
    return out


WINDOWS = {"1d": 1, "1w": 7, "1m": 30, "3m": 90, "1y": 365, "all": None}


def price_series(card_id: str, window: str = "all") -> dict:
    c = conn()
    try:
        return hub.price_series(c, card_id, WINDOWS.get(window))
    finally:
        c.close()


def card_detail(card_id: str) -> dict | None:
    c = conn()
    try:
        row = c.execute(
            "SELECT c.*, s.name AS set_name, s.series, s.release_date AS set_release,"
            " s.printed_total, s.code, s.source_url AS set_source FROM cards c "
            "LEFT JOIN sets s ON s.set_id=c.set_id WHERE c.card_id=?", (card_id,)
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["display_name"] = d.get("name_zh") or d["name"]
        d["difficulty_label"] = scoring.difficulty_label(d.get("difficulty"))
        try:
            d["diff_detail"] = json.loads(d.get("diff_json") or "{}")
        except json.JSONDecodeError:
            d["diff_detail"] = {}
        d["pop_history"] = [dict(r) for r in c.execute(
            "SELECT report_date, psa_total, psa_10 FROM pop_history "
            "WHERE card_id=? ORDER BY report_date", (card_id,)).fetchall()]
        d["variants"] = [dict(r) for r in c.execute(
            "SELECT variant, psa_total, psa_10, report_date,source,url FROM current_variants "
            "WHERE card_id=? ORDER BY psa_total DESC", (card_id,)).fetchall()]
        d["provenance"] = hub.provenance(c, card_id)
        d["links"] = {r["source"]: dict(r) for r in c.execute(
            "SELECT * FROM card_links WHERE card_id=?", (card_id,)).fetchall()}
        return d
    finally:
        c.close()


def facet_data(lang: str = "all", zone: str = "all") -> dict:
    """筛选面板必须同时跟随「语言」和「卡种（PROMO / 正常系列）」变化：
    美版稀有度是 Common/Rare Holo…，日版是 C/U/R/RR/AR/SAR…；
    而 PROMO 专区的系列、稀有度分布又和补充包完全不同。

    注意：两个分区标签上的数字（promo / main）只按语言算，
    不按当前分区算——否则在 PROMO 区里「正常系列」会显示 0，标签就没意义了。
    """
    lang = (lang or "all").lower()
    zone = (zone or "all").lower()
    only = lang in ("ja", "en")

    # 语言条件
    c_lang = " WHERE c.lang = ?" if only else ""
    c_lang_a = [lang] if only else []
    # 语言 + 卡种条件（用于系列/稀有度）
    zc = ""
    zca: list = []
    if zone in ("promo", "main"):
        zc = ("AND" if only else "WHERE") + " c.is_promo = ?"
        zca = [1 if zone == "promo" else 0]
    scond, sargs = [], []
    if only:
        scond.append("s.lang = ?")
        sargs.append(lang)
    if zone in ("promo", "main"):
        scond.append("s.is_promo = ?")
        sargs.append(1 if zone == "promo" else 0)
    sw = (" WHERE " + " AND ".join(scond)) if scond else ""
    sa = sargs

    c = conn()
    try:
        langs = [dict(r) for r in c.execute(
            "SELECT lang, COUNT(*) n FROM cards GROUP BY lang ORDER BY n DESC")]
        sets = [dict(r) for r in c.execute(
            f"""SELECT s.set_id,s.name,s.series,s.era,s.release_date,s.is_promo,s.lang,
                      COUNT(c.card_id) n
               FROM sets s LEFT JOIN cards c ON c.set_id=s.set_id
               {sw} GROUP BY s.set_id HAVING n>0
               ORDER BY s.release_date DESC""", sa)]
        # 按时代分组 -> 前端做「时代 → 卡盒系列」两级筛选
        buckets: dict[str, dict] = {}
        for r in sets:
            k = r.get("era") or "other"
            zh, en = db.ERA_LABEL.get(k, ("其他", "Other"))
            b = buckets.setdefault(k, {"era": k, "zh": zh, "en": en, "n": 0, "sets": []})
            b["n"] += r["n"]
            b["sets"].append(r)
        eras = sorted(buckets.values(), key=lambda b: db.ERA_INDEX.get(b["era"], 99))
        rar = [dict(r) for r in c.execute(
            f"""SELECT c.rarity, COUNT(*) n, MIN(c.rarity_tier) t FROM cards c
                {c_lang} {zc} {"AND" if (only or zc) else "WHERE"} c.rarity IS NOT NULL
                GROUP BY c.rarity ORDER BY t DESC, n DESC""", c_lang_a + zca)]

        def cnt(extra: str = "") -> int:
            sql = f"SELECT COUNT(*) n FROM cards c{c_lang}"
            if extra:
                sql += (" AND " if only else " WHERE ") + extra
            return c.execute(sql, c_lang_a).fetchone()["n"]

        variants = sorted({r[0].split(' · ')[-1] for r in c.execute(
            f"SELECT DISTINCT v.variant FROM current_variants v JOIN cards c ON c.card_id=v.card_id {c_lang} {zc}", c_lang_a + zca)})
        return {"langs": langs, "sets": sets, "eras": eras, "rarities": rar, "variants": variants,
                "counts": {"promo": cnt("c.is_promo=1"),
                           "main": cnt("c.is_promo=0"),
                           "total": cnt(),
                           "with_pop": cnt("c.psa_total IS NOT NULL"),
                           "with_price": cnt("c.card_id IN (SELECT card_id FROM price_points UNION SELECT card_id FROM observations WHERE metric!='pop')")}}
    finally:
        c.close()


def stats() -> dict:
    c = conn()
    try:
        m = {r["key"]: r["value"] for r in c.execute("SELECT key,value FROM meta")}
    finally:
        c.close()
    fx = {"jpy_cny": float(m.get("fx_jpy_cny") or DEFAULT_FX["jpy_cny"]),
          "usd_cny": float(m.get("fx_usd_cny") or DEFAULT_FX["usd_cny"]),
          "as_of": m.get("fx_as_of") or DEFAULT_FX["as_of"]}
    return {"meta": m, "fx": fx}


# ------------------------------------------------------------------ HTTP
class Handler(BaseHTTPRequestHandler):
    server_version = "Pokedex/1.0"

    def log_message(self, fmt, *args):  # 静音默认日志
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path):
        if not os.path.isfile(path):
            self.send_error(404)
            return
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript",):
            ctype += "; charset=utf-8"
        with open(path, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        # Local app writes require a per-process token and a same-origin browser request.
        origin=self.headers.get('Origin')
        expected=f"http://{self.headers.get('Host')}"
        if self.headers.get('X-App-Token') != SESSION_TOKEN or (origin and origin!=expected):
            return self._json({'error':'请刷新页面后重试'},403)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0 < length <= 5_000_000:
                return self._json({'error':'请求须小于 5MB'},413)
            data=json.loads(self.rfile.read(length))
            path=urlparse(self.path).path
            c=conn()
            try:
                if path=='/api/software/source': return self._json(software_update.configure(data.get('url','')))
                if path=='/api/software/action': return self._json(software_update.start(data.get('action')),202)
                if path=='/api/settings': return self._json(hub.save_settings(c,data))
                if path=='/api/update': return self._json(updater.start(),202)
                if path=='/api/import':
                    rows=hub.read_csv(data['csv']) if 'csv' in data else data.get('rows',[])
                    if not isinstance(data.get('preview',True),bool): raise ValueError('preview 必须为布尔值')
                    return self._json(hub.import_rows(c,rows,data.get('preview',True)))
                return self._json({'error':'not found'},404)
            finally:
                c.close()
        except (ValueError,TypeError,KeyError) as e:
            return self._json({'error':str(e)},400)
        except Exception as e:
            return self._json({'error':str(e)},500)

    def do_GET(self):  # noqa: N802
        u = urlparse(self.path)
        path = unquote(u.path)   # 卡牌 id 形如 en:sv3pt5-2，冒号会被编码成 %3A
        p = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if path == "/api/manage":
                c=conn()
                try:
                    result=hub.status(c)
                    result['token']=SESSION_TOKEN
                    labels=updater.cv(c,'betterpop_variant_labels','[]')
                    result['variants']=sorted(set(json.loads(labels)) | {r[0] for r in c.execute("SELECT DISTINCT variant FROM current_variants WHERE source!='betterpop' ORDER BY variant LIMIT 500")})
                    result['pop_report']=json.loads(updater.cv(c,'betterpop_report','{}'))
                    result['running']=updater.is_running()
                    result['software']=software_update.status()
                    return self._json(result)
                finally:
                    c.close()
            if path == "/api/stats":
                return self._json(stats())
            if path == "/api/facets":
                return self._json(facet_data(p.get("lang") or "all",
                                             p.get("zone") or "all"))
            if path == "/api/cards":
                return self._json(list_cards(p))
            if path.startswith("/api/card/"):
                cid = path[len("/api/card/"):]
                d = card_detail(cid)
                if not d:
                    return self._json({"error": "not found", "card_id": cid}, 404)
                d["price"] = price_series(cid, p.get("window") or "all")
                return self._json(d)
            if path.startswith("/api/price/"):
                cid = path[len("/api/price/"):]
                return self._json(price_series(cid, p.get("window") or "all"))
        except Exception as e:  # noqa: BLE001
            return self._json({"error": str(e)}, 500)

        rel = path.lstrip("/") or "index.html"
        target = os.path.normpath(os.path.join(WEB, rel))
        if os.path.commonpath([target, WEB]) != WEB:
            return self.send_error(403)
        return self._file(target)


def _already_running(port: int) -> bool:
    """本机该端口上跑的是不是我们这个应用。"""
    try:
        with urllib.request.urlopen(
                f"http://127.0.0.1:{port}/api/stats", timeout=1.5) as r:
            return b'"fx"' in r.read(300)
    except Exception:
        return False


class Server(ThreadingHTTPServer):
    # Windows 上 SO_REUSEADDR 会让 bind 到已占用端口「假成功」，
    # 这里关掉，端口冲突时老实报错，便于上面顺延端口。
    allow_reuse_address = False
    daemon_threads = True


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8777)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--no-auto-update", action="store_true", help="本次启动不运行后台更新")
    args = ap.parse_args()


    srv = None
    port = args.port
    for cand in [args.port] + [args.port + i for i in range(1, 11)]:
        if _already_running(cand):
            url = f"http://127.0.0.1:{cand}/"
            print(f"已有实例在运行，直接打开：{url}")
            print("（如需重启，先关掉那个命令行窗口）")
            if not args.no_browser:
                webbrowser.open(url)
            return
        try:
            srv = Server(("127.0.0.1", cand), Handler)
            port = cand
            break
        except OSError:
            continue

    if srv is None:
        print(f"端口 {args.port}-{args.port + 10} 都被别的程序占用，启动失败。")
        input("按回车键退出…")
        return

    # EXE replacement runs in a separate temporary helper after this process exits.
    if FROZEN and (software_update.folder()/'pending.json').exists():
        if updater.is_running():
            print('卡牌数据更新仍在运行，软件升级留待下次启动。')
        else:
            software_update.launch_install_worker()
            srv.server_close()
            return
    try:
        with updater.ProcessLock():
            applied = False if FROZEN else software_update.apply_pending()
        if applied:
            srv.server_close()
            os.execv(sys.executable, [sys.executable, os.path.abspath(__file__), *sys.argv[1:]])
    except Exception as e:
        print(f"软件升级未完成，继续使用原程序：{e}")
    c=db.init()
    hub.init(c)
    c.close()

    url = f"http://127.0.0.1:{port}/"
    print(f"宝可梦卡牌图鉴已启动：{url}")
    print("按 Ctrl+C 停止")
    if not args.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    stop=threading.Event()
    if not args.no_auto_update:
        threading.Thread(target=updater.scheduler,args=(stop,),daemon=True).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止")
    finally:
        stop.set()
        srv.server_close()


if __name__ == "__main__":
    try:
        with software_update.instance_lock():
            main()
    except RuntimeError as e:
        print(e)
