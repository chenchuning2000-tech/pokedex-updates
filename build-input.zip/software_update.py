"""Software releases are separate from card-data updates; standard library only."""
import ast, contextlib, hashlib, json, os, re, shutil, sqlite3, stat, threading, urllib.request, zipfile
from pathlib import Path, PurePosixPath
from runtime_paths import APP_ROOT
ROOT=APP_ROOT
VERSION='2.6.0'
from runtime_paths import FROZEN
import sys,subprocess
DEFAULT_MANIFEST_URL=('https://github.com/chenchuning2000-tech/pokedex-updates/releases/latest/download/latest-windows.json' if FROZEN else 'https://raw.githubusercontent.com/chenchuning2000-tech/pokedex-updates/main/latest.json')
LOCK=threading.Lock()
MAX_ZIP=40*1024*1024

def folder():
 p=ROOT/'data'/'software_update';p.mkdir(parents=True,exist_ok=True);return p

def read(p,default=None):
 return json.loads(p.read_text('utf-8')) if p.exists() else default

def write(p,d):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2),'utf-8');tmp.replace(p)

def version(v):
 if not isinstance(v,str) or not re.fullmatch(r'\d{1,5}\.\d{1,5}\.\d{1,5}',v):raise ValueError('版本号须为 x.y.z')
 return tuple(map(int,v.split('.')))

def url(u):
 from urllib.parse import urlparse
 p=urlparse(u)
 if p.scheme!='https' or not p.hostname or p.username or p.password or p.fragment:raise ValueError('更新地址必须是 HTTPS 链接')
 return u

class HTTPSOnly(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  url(newurl)
  return super().redirect_request(req,fp,code,msg,headers,newurl)

def fetch(u,limit):
 req=urllib.request.Request(url(u),headers={'User-Agent':'PokedexSoftware/'+VERSION})
 with urllib.request.build_opener(HTTPSOnly).open(req,timeout=45) as r:
  data=r.read(limit+1)
 if len(data)>limit:raise ValueError('下载文件超过大小限制')
 return data

def status():
 d=read(folder()/'state.json',{})
 return dict(d,current=VERSION,edition='Windows 独立版' if FROZEN else 'Python 版',manifest_url=read(folder()/'settings.json',{}).get('manifest_url') or DEFAULT_MANIFEST_URL,busy=LOCK.locked())

def configure(address):
 with LOCK:
  if (folder()/'pending.json').exists():raise ValueError('已有待安装版本，请先关闭并重新启动软件')
  address=address.strip();url(address)
  write(folder()/'settings.json',{'manifest_url':address})
  write(folder()/'state.json',{'status':'idle','message':'更新源已保存，请检查新版'})
 return status()

def check():
 address=status()['manifest_url']
 if not address:raise ValueError('尚未配置软件发布地址')
 m=json.loads(fetch(address,128*1024))
 version(m['version']);url(m['url'])
 if not re.fullmatch('[a-fA-F0-9]{64}',m.get('sha256','')):raise ValueError('更新清单缺少 SHA256')
 if type(m.get('size')) is not int or not 0<m['size']<=MAX_ZIP:raise ValueError('升级包大小无效')
 newer=version(m['version'])>version(VERSION)
 write(folder()/'release.json',m)
 write(folder()/'state.json',{'status':'available' if newer else 'latest','latest':m['version'],'notes':str(m.get('notes',''))[:8000],'message':'发现新版本' if newer else '已是当前发布源的最新版本'})

def allowed(name):
 p=PurePosixPath(name)
 if '\\' in name or ':' in name or p.is_absolute() or any(x in ('..','.') for x in name.split('/')):return False
 if name=='Pokedex.exe':return FROZEN
 if p.parts[0] in ('web','tools'):return p.suffix.lower() in ('.py','.js','.css','.html','.csv','.json')
 return len(p.parts)==1 and (p.suffix.lower() in ('.py','.bat','.ps1','.md') or name in ('version.json','README.txt'))

def unpack(blob,m,target):
 if len(blob)!=m['size'] or hashlib.sha256(blob).hexdigest().lower()!=m['sha256'].lower():raise ValueError('升级包校验失败，原程序未修改')
 import io
 with zipfile.ZipFile(io.BytesIO(blob)) as z:
  entries=[i for i in z.infolist() if not i.is_dir()]
  names=[i.filename for i in entries]
  if len(entries)>1000 or sum(i.file_size for i in entries)>100*1024*1024:raise ValueError('升级包展开大小超限')
  if len({n.casefold() for n in names})!=len(names):raise ValueError('升级包存在重复文件')
  required={'Pokedex.exe','version.json'} if FROZEN else {'app.py','software_update.py','version.json'}
  if not required<=set(names):raise ValueError('升级包与当前程序类型不匹配')
  if FROZEN and not z.read('Pokedex.exe').startswith(b'MZ'):raise ValueError('无效的 Windows 程序')
  for i in entries:
   if not allowed(i.filename) or stat.S_ISLNK(i.external_attr>>16):raise ValueError('升级包包含不允许替换的文件：'+i.filename)
  if json.loads(z.read('version.json'))['version']!=m['version']:raise ValueError('升级包版本不一致')
  for i in entries:
   content=z.read(i)
   if i.filename.endswith('.py'):ast.parse(content,filename=i.filename)
   dest=target/i.filename;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content)
 return names

def download():
 m=read(folder()/'release.json')
 if not m or version(m['version'])<=version(VERSION):raise ValueError('请先检查可用的新版本')
 stage=folder()/'staged';shutil.rmtree(stage,ignore_errors=True);stage.mkdir()
 try:names=unpack(fetch(m['url'],MAX_ZIP),m,stage)
 except Exception:shutil.rmtree(stage,ignore_errors=True);raise
 write(folder()/'pending.json',{'version':m['version'],'files':names,'hashes':{n:hashlib.sha256((stage/n).read_bytes()).hexdigest() for n in names}})
 write(folder()/'state.json',{'status':'ready','latest':m['version'],'message':'下载校验完成，关闭软件窗口后重新启动即可安装'})

def start(action):
 if action not in ('check','download'):raise ValueError('无效操作')
 if not LOCK.acquire(False):return {'status':'busy'}
 def work():
  try:
   write(folder()/'state.json',{'status':'working','message':'正在检查新版…' if action=='check' else '正在下载并校验升级包…'})
   (check if action=='check' else download)()
  except Exception as e:write(folder()/'state.json',{'status':'failed','message':str(e)})
  finally:LOCK.release()
 threading.Thread(target=work,daemon=True).start()
 return {'status':'started'}

def restore(journal):
 for name,existed in journal['files'].items():
  dst=ROOT/name
  if existed:shutil.copy2(folder()/'backup'/'program'/name,dst)
  elif dst.exists():dst.unlink()

def apply_pending():
 """Called before serving requests, while holding the data updater's process lock."""
 f=folder();journal=read(f/'journal.json')
 if journal:
  restore(journal);(f/'journal.json').unlink()
  (f/'pending.json').unlink(missing_ok=True)
  write(f/'state.json',{'status':'failed','message':'上次安装中断，已恢复旧程序'})
  return False
 pending=read(f/'pending.json')
 if not pending:return False
 names=pending['files']
 if any(not allowed(n) for n in names):raise ValueError('待安装文件列表无效')
 for n in names:
  if hashlib.sha256((f/'staged'/n).read_bytes()).hexdigest()!=pending['hashes'][n]:raise ValueError('待安装文件校验失败')
 backup=f/'backup';shutil.rmtree(backup,ignore_errors=True);backup.mkdir()
 db=ROOT/'data'/'cards.db'
 if db.exists():
  with contextlib.closing(sqlite3.connect(db)) as src,contextlib.closing(sqlite3.connect(backup/'cards.db')) as dst:src.backup(dst)
 if (ROOT/'config.json').exists():shutil.copy2(ROOT/'config.json',backup/'config.json')
 journal={'files':{n:(ROOT/n).exists() for n in names}}
 for n,exists in journal['files'].items():
  if exists:
   dst=backup/'program'/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/n,dst)
 write(f/'journal.json',journal)
 try:
  for n in names:
   dst=ROOT/n;dst.parent.mkdir(parents=True,exist_ok=True)
   tmp=dst.with_name(dst.name+'.upgrade-tmp');shutil.copy2(f/'staged'/n,tmp);os.replace(tmp,dst)
 except Exception:
  restore(journal);(f/'journal.json').unlink();raise
 (f/'pending.json').unlink();(f/'journal.json').unlink()
 write(f/'state.json',{'status':'installed','message':'软件已升级到 '+pending['version']+'，旧程序及数据库备份已保留'})
 return True

@contextlib.contextmanager
def instance_lock():
 p=folder()/'instance.lock'
 with open(p,'a+b') as f:
  if os.name=='nt':
   import msvcrt
   f.seek(0,2)
   if not f.tell():f.write(b'0');f.flush()
   f.seek(0)
   try:msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
   except OSError:raise RuntimeError('软件已在运行，请先关闭原来的命令行窗口')
  else:
   import fcntl
   try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
   except OSError:raise RuntimeError('软件已在运行，请先关闭原来的命令行窗口')
  yield

def launch_install_worker():
 if not FROZEN:raise ValueError('仅独立 EXE 需要外部安装器')
 import shutil
 runner=folder()/('installer-'+str(os.getpid())+'.exe')
 shutil.copy2(sys.executable,runner)
 flags=subprocess.CREATE_NEW_CONSOLE if os.name=='nt' else 0
 subprocess.Popen([str(runner),'--install-update',str(ROOT),str(os.getpid())],cwd=ROOT,creationflags=flags)
