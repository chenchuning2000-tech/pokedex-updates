"""Windows standalone entry point, including out-of-process executable replacement."""
import os,sys,time,traceback,subprocess
from pathlib import Path

def install_worker(args):
 root=Path(args[0]).resolve();pid=int(args[1]);os.environ['POKEDEX_APP_ROOT']=str(root)
 if os.name=='nt':
  import ctypes
  from ctypes import wintypes
  kernel=ctypes.WinDLL('kernel32',use_last_error=True)
  kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
  kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.CloseHandle.argtypes=[wintypes.HANDLE]
  handle=kernel.OpenProcess(0x00100000,False,pid)
  if handle:
   try:
    if kernel.WaitForSingleObject(handle,120000)!=0:raise RuntimeError('旧程序未退出，停止升级')
   finally:kernel.CloseHandle(handle)
 import software_update,updater
 with software_update.instance_lock(),updater.ProcessLock():software_update.apply_pending()
 subprocess.Popen([str(root/'Pokedex.exe')],cwd=root)

class Tee:
 def __init__(self,stream,log):self.stream=stream;self.log=log
 def write(self,text):
  if self.stream:self.stream.write(text);self.stream.flush()
  self.log.write(text);self.log.flush();return len(text)
 def flush(self):
  if self.stream:self.stream.flush()
  self.log.flush()

def main():
 for stream in (sys.stdout,sys.stderr):
  if hasattr(stream,'reconfigure'):stream.reconfigure(encoding='utf-8',errors='replace')
 if len(sys.argv)>1 and sys.argv[1]=='--install-update':
  install_worker(sys.argv[2:]);return
 from runtime_paths import APP_ROOT
 os.chdir(APP_ROOT);(APP_ROOT/'data').mkdir(exist_ok=True)
 log=open(APP_ROOT/'data'/'startup.log','a',encoding='utf-8')
 sys.stdout=Tee(sys.stdout,log);sys.stderr=Tee(sys.stderr,log)
 print('\nPokedex desktop starting:',time.strftime('%Y-%m-%d %H:%M:%S'))
 try:
  import db,hub,updater,software_update
  if '--data-update' in sys.argv:
   c=db.init();hub.init(c);enabled=hub.settings(c)['enabled'];c.close()
   print(updater.run() if enabled or '--scheduled' not in sys.argv else {'status':'disabled'});return
  import app
  try:
   with software_update.instance_lock():app.main()
  except RuntimeError:
   import webbrowser
   for port in range(8777,8788):
    if app._already_running(port):
     print('软件已在运行，打开现有页面。')
     if '--no-browser' not in sys.argv:webbrowser.open('http://127.0.0.1:%s/'%port)
     return
   raise
 except Exception:
  traceback.print_exc()
  print('启动失败。请将 data/startup.log 发给维护者。')
  if sys.stdin and sys.stdin.isatty():input('按回车关闭此窗口…')
  raise
if __name__=='__main__':
 import multiprocessing
 multiprocessing.freeze_support()
 main()
