"""难度分模型（v2）与 PSA10 率。

口径全部写死在此文件，前端只展示结果，不重算。

五个因子：
  scarcity  PSA 送评总量 —— 反向，pop 越少越难拿到。权重最高，因为它直接反映可流通量。
  rarity    罕度分级（统一 tier 1-10）
  age       发行年限 —— 越老的卡越难找品相好的
  promo     是否限定渠道（PROMO / 活动赠送 / 赛事）
  price     市场价（可选，数据源不稳时缺省，缺省则权重重新归一）

不给价格也能出分，这是刻意的：美版价格源当前不可用，
若把价格设为主因子，全库难度分都会是空的。
"""
from __future__ import annotations

import math
from datetime import date

WEIGHTS = {
    "scarcity": 0.40,
    "rarity": 0.25,
    "age": 0.15,
    "promo": 0.10,
    "price": 0.10,
}
POP_CEIL = 30000      # PSA 总 pop ≥ 3 万 视为最易流通
AGE_CEIL = 27         # 27 年（1996 起点）视为最老
PRICE_CEIL = 3000.0   # 3000 美元以上视为最贵


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def scarcity_score(psa_total: int | None) -> float | None:
    if not psa_total or psa_total <= 0:
        return None
    return _clamp01(1 - math.log10(1 + psa_total) / math.log10(1 + POP_CEIL))


def rarity_score(tier: int | None) -> float:
    return _clamp01((tier or 3) / 10.0)


def age_score(release_date: str | None) -> float | None:
    if not release_date:
        return None
    try:
        y = int(str(release_date)[:4])
    except ValueError:
        return None
    if y < 1996 or y > date.today().year + 3:
        return None
    years = max(0, date.today().year - y)
    return _clamp01(years / AGE_CEIL)


def price_score(usd: float | None) -> float | None:
    if not usd or usd <= 0:
        return None
    return _clamp01(math.log10(1 + usd) / math.log10(1 + PRICE_CEIL))


def difficulty(price_usd: float | None,
               psa_total: int | None,
               rarity_tier: int | None,
               is_promo: bool,
               release_date: str | None) -> tuple[float | None, dict]:
    """返回 (1.0-10.0, 明细)。缺项时按可用因子的权重重新归一。"""
    comps: dict[str, float | None] = {
        "scarcity": scarcity_score(psa_total),
        "rarity": rarity_score(rarity_tier),
        "age": age_score(release_date),
        "promo": 1.0 if is_promo else 0.0,
        "price": price_score(price_usd),
    }
    avail = {k: v for k, v in comps.items() if v is not None}
    missing = [k for k, v in comps.items() if v is None]
    if not avail:
        return None, {"components": comps, "missing": missing, "raw": None}

    total_w = sum(WEIGHTS[k] for k in avail)
    raw = sum(WEIGHTS[k] * v for k, v in avail.items()) / total_w
    score = round(1 + 9 * raw, 1)
    return score, {
        "components": {k: (round(v, 3) if v is not None else None) for k, v in comps.items()},
        "weights": {k: (WEIGHTS[k] if k in avail else 0.0) for k in WEIGHTS},
        "missing": missing,
        "raw": round(raw, 4),
        "coverage": round(total_w, 3),
    }


def psa10_rate(psa_10: int | None, psa_total: int | None) -> float | None:
    if psa_10 is None or not psa_total:
        return None
    return round(psa_10 / psa_total * 100, 2)


DIFFICULTY_BANDS = [
    (1.0, 3.0, "易", "大宗常见，货架上随手能买到"),
    (3.0, 5.0, "普通", "常规渠道可获取，需挑品相"),
    (5.0, 6.5, "偏难", "要花时间找，价格有明显溢价"),
    (6.5, 8.0, "难", "需专门渠道或长期蹲守"),
    (8.0, 9.5, "很难", "高价值限定，二级市场为主"),
    (9.5, 10.1, "极难", "藏品级，流通极少"),
]


def difficulty_label(score: float | None) -> str:
    if score is None:
        return "数据不足"
    for lo, hi, label, _ in DIFFICULTY_BANDS:
        if lo <= score < hi:
            return label
    return "极难" if score >= 9.5 else "易"
