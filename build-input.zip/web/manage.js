const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let token='',csv='',previewed='',initialized=false;
const labels={running:'进行中',success:'完成',failed:'失败',interrupted:'已中断',partial:'部分完成'};
function notice(s){$('#notice').textContent=s;}
async function request(path,data){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-App-Token':token},body:JSON.stringify(data)});const result=await r.json();if(!r.ok)throw Error(result.error||'请求失败');return result;}
async function refresh(){
 try{
  const r=await fetch('/api/manage');if(!r.ok)throw Error('状态读取失败');const d=await r.json();token=d.token;
  const sw=d.software;
  $('#softwareVersion').textContent='当前版本 '+sw.current+(sw.latest?' · 发布版本 '+sw.latest:'');
  $('#softwareStatus').textContent=sw.message||(sw.manifest_url?'点击检查软件新版':'尚未配置软件发布地址');
  $('#releaseNotes').textContent=sw.notes||'';
  $('#softwareCheck').disabled=sw.busy||!sw.manifest_url||sw.status==='ready';
  $('#softwareDownload').disabled=sw.busy||sw.status!=='available';
  if(!initialized)$('#softwareUrl').value=sw.manifest_url;
  if(!initialized){for(const[k,v]of Object.entries(d.settings)){const el=$('#'+k);if(el.type==='checkbox')el.checked=v;else el.value=v;}initialized=true;}
  $('#summary').textContent=`共 ${d.counts.cards.toLocaleString()} 张卡 · ${d.counts.market.toLocaleString()} 张有市场价 · ${d.running?'更新中':'等待下次检查'}`;
  $('#update').disabled=d.running;
  $('#popSummary').textContent=d.pop_report?.date ? `Pop 快照 ${d.pop_report.date}：匹配 ${d.pop_report.matched_cards.toLocaleString()} 张卡、${d.pop_report.matched_rows.toLocaleString()} 条变体。未匹配记录不作零处理。` : 'Pop 快照尚未同步。';
  $('#sources').innerHTML=d.sources.map(s=>`<div class="source"><h3><a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.name)} ↗</a></h3><span class="badge">${esc(s.mode)}</span><p>${esc(s.note)}</p></div>`).join('');
  $('#runs').innerHTML=d.runs.length?d.runs.map(r=>`<tr><td>${esc(r.source)}</td><td>${esc(new Date(r.started_at).toLocaleString())}</td><td>${esc(labels[r.status]||r.status)}</td><td>${r.added}</td><td>${esc(r.message)}</td></tr>`).join(''):'<tr><td colspan="5">尚未执行更新</td></tr>';
 }catch(e){notice(e.message);}
}
$('#settings').onsubmit=async e=>{e.preventDefault();try{const d={};for(const k of ['enabled','catalog_en','catalog_ja','tcgcsv','betterpop'])d[k]=$('#'+k).checked;d.interval_hours=Number($('#interval_hours').value);await request('/api/settings',d);notice('设置已保存');}catch(e){notice(e.message);}};
$('#update').onclick=async()=>{try{const r=await request('/api/update',{});notice(r.status==='busy'?'已有更新正在运行':'已发起检查；未到更新间隔的来源会跳过');await refresh();}catch(e){notice(e.message);}};
$('#csvFile').onchange=()=>{csv='';previewed='';$('#commit').disabled=true;$('#previewResult').textContent='';};
$('#preview').onclick=async()=>{try{const file=$('#csvFile').files[0];if(!file)throw Error('请选择 CSV');if(file.size>4000000)throw Error('CSV 请控制在 4MB 内');csv=await file.text();const r=await request('/api/import',{csv,preview:true});$('#previewResult').textContent=JSON.stringify(r,null,2);previewed=r.ok?csv:'';$('#commit').disabled=!r.ok;}catch(e){notice(e.message);}};
$('#commit').onclick=async()=>{if(!previewed)return;$('#commit').disabled=true;try{const r=await request('/api/import',{csv:previewed,preview:false});notice(r.ok?`已写入 ${r.written} 条记录`:'导入失败，没有写入');$('#previewResult').textContent=JSON.stringify(r,null,2);previewed='';await refresh();}catch(e){notice(e.message);}};
$('#manual').onsubmit=async e=>{e.preventDefault();try{const row=Object.fromEntries(new FormData(e.target));const r=await request('/api/import',{rows:[row],preview:false});notice(r.ok?'记录已保存':r.errors.map(x=>x.error).join('；'));await refresh();}catch(e){notice(e.message);}};
refresh();setInterval(refresh,5000);

$('#metric').onchange=()=>{ $('#valueLabel').firstChild.textContent=$('#metric').value==='pop'?'PSA10 数量':'价格数值'; };

$('#softwareSource').onsubmit=async e=>{e.preventDefault();try{await request('/api/software/source',{url:$('#softwareUrl').value});await refresh();}catch(e){notice(e.message);}};
for(const [id,action] of [['softwareCheck','check'],['softwareDownload','download']])$('#'+id).onclick=async()=>{ $('#'+id).disabled=true;try{await request('/api/software/action',{action});await refresh();}catch(e){notice(e.message);await refresh();}};
