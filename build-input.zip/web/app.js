/* 卡牌图鉴 · 前端 */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const state = {
  zone: 'main', lang: 'ja', q: '', sort: 'relevance',
  sets: [], rarities: [], popMin: '', popMax: '', rateMin: '', rateMax: '',
  diffMin: '', diffMax: '', hasPop: false, variant: '', variantPopMax: '', variant10Max: '',
  page: 1, pageSize: 60, total: 0, loaded: [], loading: false,
};

let facets = null, FX = { jpy_cny: 0.0478, usd_cny: 7.12 };
const openEras = new Set();   // 已展开的时代，跨重绘保留

/* ---------------- 工具 ---------------- */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function fmtNum(n) { return n == null ? '—' : Number(n).toLocaleString('zh-CN'); }

function fmtMoney(v, cur) {
  if (v == null || isNaN(v)) return null;
  if (cur === 'JPY') return '¥' + Math.round(v).toLocaleString('en-US');
  return ({USD:'$',EUR:'€',CNY:'¥',GBP:'£'}[cur] || cur+' ') + Number(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function toCNY(v, cur) {
  if (v == null) return null;
  if(cur==='CNY') return v;
  if(!['JPY','USD'].includes(cur)) return null;
  const r = cur === 'JPY' ? FX.jpy_cny : FX.usd_cny;
  return v * r;
}
function fmtCNY(v) { return v == null ? '—' : '≈ ¥' + v.toLocaleString('zh-CN', { maximumFractionDigits: 0 }); }

function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

function toast(msg, ms = 2200) {
  const t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(t._t); t._t = setTimeout(() => t.hidden = true, ms);
}

/* ---------------- 参数拼装 ---------------- */
function params(extra = {}) {
  const p = new URLSearchParams();
  p.set('zone', state.zone); p.set('lang', state.lang); p.set('sort', state.sort);
  if (state.q) p.set('q', state.q);
  if (state.sets.length) p.set('set', state.sets.join(','));
  if (state.rarities.length) p.set('rarity', state.rarities.join(','));
  [['pop_min', state.popMin], ['pop_max', state.popMax],
   ['rate_min', state.rateMin], ['rate_max', state.rateMax],
   ['diff_min', state.diffMin], ['diff_max', state.diffMax]]
    .forEach(([k, v]) => { if (v !== '' && v != null) p.set(k, v); });
  if (state.hasPop) p.set('has_pop', '1');
  if (state.variant) p.set('variant', state.variant);
  if (state.variantPopMax) p.set('variant_pop_max', state.variantPopMax);
  if (state.variant10Max) p.set('variant_10_max', state.variant10Max);
  Object.entries(extra).forEach(([k, v]) => v != null && p.set(k, v));
  return p;
}

function syncHash() {
  const p = params();
  p.delete('page'); p.delete('page_size');
  history.replaceState(null, '', '#' + p.toString());
}

function readHash() {
  const h = location.hash.replace(/^#/, '');
  if (!h) return;
  const p = new URLSearchParams(h);
  state.zone = p.get('zone') || 'main';
  state.lang = p.get('lang') === 'en' ? 'en' : 'ja';
  state.q = p.get('q') || '';
  state.sort = p.get('sort') || 'relevance';
  state.sets = p.get('set') ? p.get('set').split(',') : [];
  state.rarities = p.get('rarity') ? p.get('rarity').split(',') : [];
  state.popMin = p.get('pop_min') || ''; state.popMax = p.get('pop_max') || '';
  state.rateMin = p.get('rate_min') || ''; state.rateMax = p.get('rate_max') || '';
  state.diffMin = p.get('diff_min') || ''; state.diffMax = p.get('diff_max') || '';
  state.hasPop = p.get('has_pop') === '1';
  state.variant=p.get('variant')||'';state.variantPopMax=p.get('variant_pop_max')||'';state.variant10Max=p.get('variant_10_max')||'';
}

/* ---------------- 初始化 ---------------- */
async function boot() {
  readHash();
  try {
    const st = await (await fetch('/api/stats')).json();
    FX = st.fx;
  } catch (e) { /* 保持默认 */ }
  await reloadFacets();
  if (!facets) {
    $('#grid').innerHTML = '';
    $('#gridEmpty').hidden = false;
    $('#gridEmpty').innerHTML = '<b>读不到数据</b>请先运行入库脚本（tools/ingest_en.py / tools/ingest_jp.py）。';
    return;
  }
  syncControls();
  load(true);
}

/* 筛选面板随语言重算：美版/日版的稀有度体系与系列完全不同，
   切语言时把不属于该语言的已选条件剔掉，避免出现「选了日版系列却看美版结果」 */
let facetRequest = 0;
async function reloadFacets() {
  const request = ++facetRequest;
  try {
    const r = await fetch('/api/facets?lang=' + state.lang + '&zone=' + state.zone);
    if (!r.ok) throw new Error('筛选项加载失败');
    const data = await r.json();
    if (request !== facetRequest) return false;
    facets = data;
  } catch (e) {
    if (request === facetRequest) toast('筛选项加载失败，请重试切换');
    return false;
  }
  const okSets = new Set(facets.sets.map(s => s.set_id));
  state.sets = state.sets.filter(s => okSets.has(s));
  const okRar = new Set(facets.rarities.map(r => r.rarity));
  state.rarities = state.rarities.filter(r => okRar.has(r));
  $('#variantOptions').innerHTML = (facets.variants || []).map(v => `<option value="${esc(v)}">`).join('');
  renderFacets();
  syncControls();
  return true;
}

function renderFacets() {
  $('#cntMain').textContent = fmtNum(facets.counts.main);
  $('#cntPromo').textContent = fmtNum(facets.counts.promo);
  const m = [];
  m.push(`共 ${fmtNum(facets.counts.total)} 张卡`);
  m.push(`有 PSA 数据 ${fmtNum(facets.counts.with_pop)}`);
  if (facets.counts.with_price) m.push(`有历史价格 ${fmtNum(facets.counts.with_price)}`);
  $('#dbMeta').textContent = m.join(' · ');

  // 时代 → 卡盒系列（两级）
  if (!openEras.size && facets.eras.length) openEras.add(facets.eras[0].era);

  const buildEras = (kw = '') => {
    const k = kw.trim().toLowerCase();
    const html = (facets.eras || []).map(e => {
      const eraHit = !k || e.zh.toLowerCase().includes(k) || e.en.toLowerCase().includes(k);
      const sets = eraHit ? e.sets
        : e.sets.filter(s => (s.name || '').toLowerCase().includes(k));
      if (!sets.length) return '';
      const ids = sets.map(s => s.set_id);
      const picked = ids.filter(id => state.sets.includes(id)).length;
      const all = picked === ids.length && ids.length > 0;
      const open = openEras.has(e.era) || !!k;
      return `
      <div class="era" data-era="${esc(e.era)}">
        <div class="era-head">
          <input type="checkbox" class="era-cb" data-era="${esc(e.era)}"
                 ${all ? 'checked' : ''} ${picked && !all ? 'data-indet="1"' : ''}>
          <span class="era-name">${esc(e.zh)}</span>
          <span class="era-n">${e.n}</span>
          <span class="era-chev ${open ? 'open' : ''}">▾</span>
        </div>
        <div class="era-sets" ${open ? '' : 'hidden'}>
          ${sets.map(s => `
            <label class="set-item">
              <input type="checkbox" class="set-cb" value="${esc(s.set_id)}"
                     ${state.sets.includes(s.set_id) ? 'checked' : ''}>
              <span class="sn" title="${esc(s.name)}">${esc(s.name)}</span>
              <span class="sc">${s.n}</span>
            </label>`).join('')}
        </div>
      </div>`;
    }).join('');
    $('#eraList').innerHTML = html || '<div class="set-item" style="color:#9aa0ae">没有匹配的系列</div>';
    $$('#eraList .era-cb').forEach(cb => { cb.indeterminate = !!cb.dataset.indet; });
  };
  renderFacets.rebuild = buildEras;
  buildEras($('#setSearch').value);
  $('#setSearch').oninput = e => buildEras(e.target.value);

  if (!renderFacets._bound) {
    renderFacets._bound = true;

    $('#eraList').addEventListener('click', e => {
      const head = e.target.closest('.era-head');
      if (head && e.target.type !== 'checkbox') {
        const era = head.parentElement.dataset.era;
        openEras.has(era) ? openEras.delete(era) : openEras.add(era);
        renderFacets.rebuild($('#setSearch').value);
      }
    });

    $('#eraList').addEventListener('change', e => {
      const t = e.target;
      if (t.classList.contains('set-cb')) {
        state.sets = t.checked ? [...new Set([...state.sets, t.value])]
          : state.sets.filter(x => x !== t.value);
        load(true);
      } else if (t.classList.contains('era-cb')) {
        const box = t.closest('.era');
        const ids = [...box.querySelectorAll('.set-cb')].map(c => c.value);
        state.sets = t.checked
          ? [...new Set([...state.sets, ...ids])]
          : state.sets.filter(x => !ids.includes(x));
        load(true);
      }
    });
  }

  // 稀有度
  $('#rarityChips').innerHTML = facets.rarities.map(r => {
    const label = r.rarity.length > 16 ? r.rarity.slice(0, 15) + '…' : r.rarity;
    return `<button data-r="${esc(r.rarity)}" title="${esc(r.rarity)} · ${r.n} 张">${esc(label)} <span style="opacity:.55">${r.n}</span></button>`;
  }).join('');
  $$('#rarityChips button').forEach(b => b.onclick = () => {
    const v = b.dataset.r;
    state.rarities = state.rarities.includes(v)
      ? state.rarities.filter(x => x !== v) : [...state.rarities, v];
    b.classList.toggle('on');
    load(true);
  });
}

/* ---------------- 控件状态 ---------------- */
const SCOPE_ORDER = ['ja', 'en'];
const SCOPE_LABEL = { ja: '日版', en: '美版' };

function syncControls() {
  $$('.zone').forEach(b => b.classList.toggle('on', b.dataset.zone === state.zone));
  const sb = $('#scopeBtn');
  if (sb) {
    sb.dataset.scope = state.lang;
    $('#scopeLabel').textContent = SCOPE_LABEL[state.lang] || '日版';
  }
  $('#q').value = state.q;
  $('#qClear').hidden = !state.q;
  $('#sort').value = state.sort;
  $('#popMin').value = state.popMin; $('#popMax').value = state.popMax;
  $('#rateMin').value = state.rateMin; $('#rateMax').value = state.rateMax;
  $('#diffMin').value = state.diffMin; $('#diffMax').value = state.diffMax;
  $('#hasPop').checked = state.hasPop;
  $('#variant').value=state.variant;$('#variantPopMax').value=state.variantPopMax;$('#variant10Max').value=state.variant10Max;
  $$('#rarityChips button').forEach(b => b.classList.toggle('on', state.rarities.includes(b.dataset.r)));
}

function renderActiveFilters() {
  const parts = [];
  if (state.lang !== 'all') parts.push(`语言：${state.lang === 'ja' ? '日版' : '美版'}`);
  if (state.sets.length) parts.push(`系列 ${state.sets.length} 个`);
  state.rarities.forEach(r => parts.push(r));
  if (state.popMin || state.popMax) parts.push(`Pop ${state.popMin || 0}–${state.popMax || '∞'}`);
  if (state.rateMin || state.rateMax) parts.push(`PSA10 ${state.rateMin || 0}–${state.rateMax || 100}%`);
  if (state.diffMin || state.diffMax) parts.push(`难度 ${state.diffMin || 1}–${state.diffMax || 10}`);
  if (state.hasPop) parts.push('仅有 PSA 数据');
  if (['pop_asc','pop_desc','rate_asc','rate_desc'].includes(state.sort)) parts.push('此排序已排除无 Pop 数据的卡');
  if(state.variant) parts.push('变体：'+state.variant);
  if(state.variantPopMax) parts.push('变体 Pop ≤ '+state.variantPopMax);
  if(state.variant10Max) parts.push('变体 PSA10 ≤ '+state.variant10Max);
  $('#activeFilters').innerHTML = parts.map(t => `<span class="af">${esc(t)}</span>`).join('');
}

/* ---------------- 列表 ---------------- */
let cardRequest = 0;
async function load(reset = false) {
  if (state.loading && !reset) return;
  const request = ++cardRequest;
  state.loading = true;
  if (reset) { state.page = 1; state.loaded = []; }
  if (reset) showSkeleton();

  try {
    const p = params({ page: state.page, page_size: state.pageSize });
    const r = await fetch('/api/cards?' + p.toString());
    if (!r.ok) throw new Error('服务器查询失败');
    const d = await r.json();
    if (request !== cardRequest) return;
    state.total = d.total;
    state.loaded = reset ? d.items : [...state.loaded, ...d.items];
    renderGrid();
    $('#count').innerHTML = `找到 <b>${fmtNum(d.total)}</b> 张卡`;
    renderActiveFilters();
    $('#more').hidden = state.loaded.length >= d.total;
    syncHash();
  } catch (e) {
    if (request === cardRequest) toast('查询失败：' + e.message);
  } finally {
    if (request === cardRequest) state.loading = false;
  }
}

function showSkeleton() {
  $('#gridEmpty').hidden = true;
  $('#grid').innerHTML = Array.from({ length: 12 }).map(() => `
    <div class="skel"><div class="sk-img"></div><div class="sk-l"></div><div class="sk-l s"></div></div>`).join('');
}

function priceOf(card) {
  const p = card.price || {};
  if(p.tcgcsv) return {v:p.tcgcsv.last_price,cur:p.tcgcsv.currency,src:'裸卡市场价 · '+p.tcgcsv.variant};
  const sk = p.snkrdunk, eb = p.ebay;
  if (sk && sk.last_price != null) return { v: sk.last_price, cur: 'JPY', src: 'SNKRDUNK' };
  if (eb && eb.last_price != null) return { v: eb.last_price, cur: 'USD', src: 'eBay' };
  if (card.price_usd != null) return { v: card.price_usd, cur: 'USD', src: 'TCG' };
  if (card.price_eur != null) return { v: card.price_eur, cur: 'EUR', src: 'CM' };
  return null;
}

function renderGrid() {
  const g = $('#grid');
  if (!state.loaded.length) {
    g.innerHTML = '';
    $('#gridEmpty').hidden = false;
    $('#gridEmpty').innerHTML = '<b>没有匹配的卡</b>试试放宽 PSA Pop / PSA10 率区间，或清掉稀有度筛选。';
    return;
  }
  $('#gridEmpty').hidden = true;
  g.innerHTML = state.loaded.map(c => {
    const pr = priceOf(c);
    const dots = Math.round((c.difficulty || 0));
    const img = c.image_small || c.image_large || '';
    return `
    <article class="card" data-id="${esc(c.card_id)}">
      <div class="card-img">
        ${img ? `<img loading="lazy" src="${esc(img)}" alt="${esc(c.name)}" onerror="this.style.opacity=.12">`
              : `<div style="display:grid;place-items:center;height:100%;color:#b9bec9;font-size:11px">无卡图</div>`}
        ${c.rarity ? `<span class="badge-rarity">${esc(c.rarity)}</span>` : ''}
        ${c.psa10_rate != null ? `<span class="badge-rate">10分 ${c.psa10_rate}%</span>` : ''}
        ${c.is_promo ? '<span class="badge-promo">PROMO</span>' : ''}
      </div>
      <div class="card-body">
        <div class="card-name">${esc(c.display_name || c.name)}</div>
        ${c.name_zh && c.name_zh !== c.name
          ? `<div class="card-sub">${esc(c.name)}</div>` : ''}
        <div class="card-set">
          <span class="sname" title="${esc(c.set_name || '')}">${esc(c.set_name || '')}</span>
          <span class="snum">#${esc(c.number || '—')}</span>
        </div>
        <div class="card-stats">
          <span class="pop-pill ${c.psa_total != null ? '' : 'none'}">${c.psa_total != null ? (c.pop_scope==='matched_variants'?'变体合计 ':'Pop ') + fmtNum(c.psa_total) : '无 Pop 数据'}</span>
          <span class="diff" title="获取难度 ${c.difficulty ?? '—'} · ${esc(c.difficulty_label || '')}">
            <span class="dots">${Array.from({ length: 5 }).map((_, i) => `<i class="${i < dots / 2 ? 'f' : ''}"></i>`).join('')}</span>
          </span>
        </div>
        ${pr ? `<div class="price-line">${fmtMoney(pr.v, pr.cur)}<span class="cur">${pr.src}</span></div>`
             : '<div class="price-line none">暂无价格数据</div>'}
      </div>
    </article>`;
  }).join('');

  $$('.card', g).forEach(el => el.onclick = () => openDrawer(el.dataset.id));
}

/* ---------------- 详情抽屉 ---------------- */
let drawerId = null, pxWindow = '1m';

async function openDrawer(id) {
  drawerId = id; pxWindow = '1m';
  $('#mask').hidden = false; $('#drawer').hidden = false;
  document.body.style.overflow = 'hidden';
  $('#drawerBody').innerHTML = '<div style="padding:60px 26px;color:#8b91a1">加载中…</div>';
  try {
    const d = await (await fetch('/api/card/' + encodeURIComponent(id) + '?window=1m')).json();
    if (d.error) throw new Error(d.error);
    renderDetail(d);
  } catch (e) {
    $('#drawerBody').innerHTML = `<div style="padding:60px 26px;color:#c0392b">加载失败：${esc(e.message)}</div>`;
  }
}

function closeDrawer() {
  $('#mask').hidden = true; $('#drawer').hidden = true;
  document.body.style.overflow = '';
  drawerId = null;
}

function renderDetail(d) {
  const img = d.image_large || d.image_small || '';
  const rate = d.psa10_rate;
  const diff = d.difficulty;
  const dd = d.diff_detail || {};
  const comp = dd.components || {};
  const w = dd.weights || {};

  $('#drawerBody').innerHTML = `
  <div class="d-hero">
    <div class="d-img">${img ? `<img src="${esc(img)}" alt="${esc(d.name)}">` : '<div style="height:280px;display:grid;place-items:center;color:#b9bec9">无卡图</div>'}</div>
    <div>
      <h1 class="d-title">${esc(d.display_name || d.name)}</h1>
      ${d.name_zh && d.name_zh !== d.name
        ? `<div class="d-orig">原名：${esc(d.name)}</div>` : ''}
      <div class="d-sub">${esc(d.set_name || '')} · ${esc(d.lang === 'ja' ? '日版' : '美版')} · #${esc(d.number || '—')}${d.set_total ? '/' + d.set_total : ''}</div>
      <div class="d-tags">
        ${d.rarity ? `<span class="tag">${esc(d.rarity)}</span>` : ''}
        ${d.is_promo ? '<span class="tag purple">PROMO 限定渠道</span>' : ''}
        ${d.release_date ? `<span class="tag">${esc(d.release_date)} 发售</span>` : ''}
        ${d.supertype ? `<span class="tag">${esc(d.supertype)}</span>` : ''}
        ${d.number ? `<span class="tag">编号 ${esc(d.number)}</span>` : ''}
      </div>
      <div class="kpis">
        <div class="kpi">
          <div class="k">获取难度</div>
          <div class="v">${diff != null ? diff.toFixed(1) : '—'}<small>/10</small></div>
          <div class="h">${esc(d.difficulty_label || '')}</div>
        </div>
        <div class="kpi">
          <div class="k">PSA 10 分率</div>
          <div class="v" style="color:${rate != null ? '#c9902a' : '#b9bec9'}">${rate != null ? rate + '<small>%</small>' : '—'}</div>
          <div class="h">${d.psa_total ? `psa10 ${fmtNum(d.psa_10)} / ${fmtNum(d.psa_total)}` : '暂无评级数据'}</div>
        </div>
        <div class="kpi">
          <div class="k">${d.pop_scope==='matched_variants'?'已匹配变体合计':'评级总量 Pop'}</div>
          <div class="v">${d.psa_total != null ? fmtNum(d.psa_total) : '—'}</div>
          <div class="h">${d.psa_report_date ? (d.pop_scope==='matched_variants'?'快照批次日 ':'报告日 ') + esc(d.psa_report_date) : '未同步'}</div>
        </div>
      </div>
    </div>
  </div>

  <div class="block">
    <h3>数据来源与日期</h3>
    <p>卡牌资料：${esc(d.lang==='ja'?'宝可梦日文官方卡表':'Pokemon TCG Data')} · 更新于 ${esc(d.updated_at||'未知')}</p>
    <p>总 Pop 来源：${esc(d.provenance?.source||'未录入')} · 报告 / 快照日期 ${esc(d.psa_report_date||'未知')} · 入库 ${esc(d.pop_updated||'未知')}</p>
    <p>${esc(d.provenance?.note||'变体记录独立展示；不同来源的 Pop 不相加。')}</p>
    <a href="https://www.gemrate.com/" target="_blank" rel="noopener">GemRate 查询 ↗</a> ·
    <a href="https://better-pop.com/app/" target="_blank" rel="noopener">BetterPop 查询 ↗</a> ·
    <a href="/manage.html">导入 / 补录</a>
  </div>
  <div class="block">
    <h3>卡牌规格</h3>
    <dl class="spec">
      <dt>卡名</dt><dd>${esc(d.name)}</dd>
      <dt>所属系列</dt><dd>${esc(d.set_name || '—')}${d.series ? ' · ' + esc(d.series) : ''}</dd>
      <dt>系列编号</dt><dd>${esc(d.code || d.set_id)}</dd>
      <dt>卡号</dt><dd>#${esc(d.number || '—')}${d.set_total ? ' / ' + d.set_total : ''}</dd>
      <dt>稀有度</dt><dd>${esc(d.rarity || '—')}</dd>
      <dt>贩卖形态</dt><dd>${d.is_promo ? 'PROMO（非补充包渠道）' : '正常系列（补充包/构筑卡组）'}</dd>
      <dt>发售日</dt><dd>${esc(d.release_date || d.set_release || '—')}</dd>
      <dt>绘师</dt><dd>${esc(d.artist || '—')}</dd>
      <dt>卡牌 ID</dt><dd style="font-family:ui-monospace,monospace;font-size:12px">${esc(d.card_id)}</dd>
    </dl>
  </div>

  <div class="block">
    <h3>具体来源<span class="hint">这张卡从哪来</span></h3>
    <div class="source-box">
      <span class="lbl">获取渠道</span>
      ${esc(d.source_label || '—')}
      ${d.source_url ? `<div style="margin-top:8px"><a href="${esc(d.source_url)}" target="_blank" rel="noopener" style="color:#2f6fed;font-size:11.5px">查看数据源页 ↗</a></div>` : ''}
    </div>
  </div>

  <div class="block">
    <h3>获取难度分解<span class="hint">${dd.missing && dd.missing.length
      ? '缺：' + dd.missing.map(k => FACTOR_ZH[k] || k).join('、')
      : '五个因子齐全'}</span></h3>
    <div class="diff-total">
      <span class="big">${diff != null ? diff.toFixed(1) : '—'}</span>
      <span class="lbl">${esc(d.difficulty_label || '')}</span>
      <span class="note">1 = 随手可得 · 10 = 藏品级</span>
    </div>
    <div class="diff-rows">
      ${diffRow('PSA 稀缺度', 'pop 越少越难', comp.scarcity, w.scarcity)}
      ${diffRow('罕度分级', RARITY_HINT(d.rarity), comp.rarity, w.rarity)}
      ${diffRow('发行年份', d.release_date || '—', comp.age, w.age)}
      ${diffRow('渠道限定', d.is_promo ? '限定渠道' : '常规渠道', comp.promo, w.promo)}
      ${diffRow('市场价', comp.price == null ? '暂无价格源' : '价格因子', comp.price, w.price)}
    </div>
  </div>

  <div class="block">
    <h3>PSA 评级分布<span class="hint">${d.psa_report_date ? (d.pop_scope==='matched_variants'?'快照批次日 ':'报告日 ') + esc(d.psa_report_date) : '尚未同步 PSA 数据'}</span></h3>
    ${popTable(d)}
    ${variantTable(d)}
  </div>

  <div class="block" id="pxBlock">
    <h3>价格记录<span class="hint">市场价、参考价与成交分开</span></h3>
    <div id="pxInner">${pxPlaceholder()}</div>
  </div>
  `;

  bindPxTabs(d);
}

const RARITY_HINT = r => (r || '未标注');
const FACTOR_ZH = {
  scarcity: 'PSA 稀缺度', rarity: '罕度分级', age: '发行年份',
  promo: '渠道限定', price: '市场价',
};

function diffRow(label, sub, val, weight) {
  const pct = val == null ? 0 : Math.round(val * 100);
  const wv = weight ? Math.round(weight * 100) : 0;
  return `
  <div class="diff-row">
    <span class="lab">${esc(label)}<small>${esc(sub)}</small></span>
    <span class="bar ${val == null ? '' : ''}"><i style="width:${pct}%"></i></span>
    <span class="num">${val == null ? '缺' : pct + '%'}<br><small style="font-size:9.5px">权重${wv}%</small></span>
  </div>`;
}

function variantTable(d) {
  const vs = (d.variants || []).filter(v => v.psa_total != null);
  if (!vs.length) return '<p>暂无独立变体记录；不代表不存在变体。</p>';    // 单一变体没有拆分的必要
  const sum = vs.reduce((s, v) => s + (v.psa_total || 0), 0);
  return `
  <div style="margin-top:14px;padding-top:12px;border-top:1px dashed var(--line-2)">
    <div style="font-size:11.5px;color:var(--muted);margin-bottom:7px">
      独立变体记录 · 逐条保留来源日期；上方标注为“已匹配变体合计”时，只统计该快照已确认的记录
    </div>
    <table class="pop-table">
      <thead><tr><th>变体</th><th>Pop</th><th>PSA 10</th><th>10 分率</th><th>来源 / 报告或批次日</th></tr></thead>
      <tbody>
        ${vs.map(v => `<tr>
          <td>${esc(v.variant)}</td>
          <td>${fmtNum(v.psa_total)}</td>
          <td>${fmtNum(v.psa_10)}</td>
          <td>${v.psa_total ? (v.psa_10 / v.psa_total * 100).toFixed(1) + '%' : '—'}</td>
          <td>${esc(v.source)} / ${esc(v.report_date)}</td>
        </tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

function popTable(d) {
  if (d.psa_total == null) {
    return `<div class="px-empty">这张卡暂无可靠 Pop 数据，不代表 Pop 为 0；不参与 Pop 数量或 PSA10 率筛选、排序。<br>
      可在“数据管理”中导入 GemRate / BetterPop 核验后的数据。也可在“数据管理”中更新 BetterPop 快照；PSA 直连抓取已停止。</div>`;
  }
  const rows = [['PSA 10', d.psa_10, true], ['PSA 9', d.psa_9, false],
                ['PSA 8', d.psa_8, false], ['PSA 7', d.psa_7, false],
                ['半档 (8.5/9.5)', d.psa_half, false], ['7 分以下', d.psa_lower, false]];
  const known = rows.reduce((s, r) => s + (r[1] || 0), 0);
  const other = Math.max(0, (d.psa_total || 0) - known);
  return `<table class="pop-table">
    <thead><tr><th>分数档</th><th>数量</th><th>占比</th></tr></thead>
    <tbody>
      ${rows.map(([k, v, hl]) => v == null ? '' : `<tr class="${hl ? 'hl' : ''}">
        <td>${k}</td><td>${fmtNum(v)}</td>
        <td>${d.psa_total ? (v / d.psa_total * 100).toFixed(1) + '%' : '—'}</td></tr>`).join('')}
      ${other ? `<tr><td>其他/未细分</td><td>${fmtNum(other)}</td><td>${(other / d.psa_total * 100).toFixed(1)}%</td></tr>` : ''}
      <tr style="border-top:2px solid var(--line)"><td><b>合计</b></td><td><b>${fmtNum(d.psa_total)}</b></td><td>100%</td></tr>
    </tbody></table>`;
}

function pxPlaceholder() {
  return '<div class="px-empty">暂无价格。可从数据管理更新裸卡市场价，或导入成交记录。</div>';
}
const KIND_LABEL={market:'市场参考价',trade:'实际成交',listing:'在售挂价'};
async function bindPxTabs(d) {
  const inner=$('#pxInner');
  if(!inner) return;
  const render=async(win)=>{
    pxWindow=win;
    const tabs=`<div class="px-tabs">${[['1d','近1天'],['1w','近7天'],['1m','近30天'],['1y','近1年'],['all','全部']].map(([k,l])=>`<button data-w="${k}" class="${k===win?'on':''}">${l}</button>`).join('')}</div>`;
    try {
      const res=await fetch('/api/price/'+encodeURIComponent(d.card_id)+'?window='+win);
      if(!res.ok) throw new Error('读取价格失败');
      const data=await res.json();
      if(drawerId!==d.card_id) return;
      inner.innerHTML=tabs+pxGrid(data,d)+'<div class="px-note">市场价为每日快照，不是逐笔成交。来源、币种、评级、变体分别统计；旧记录品相未标注时不视为 PSA10。横轴为已有观测日，不补造缺失日期。</div>';
      requestAnimationFrame(()=>Object.entries(data).forEach(([k,v])=>drawChart('ch-'+k,v.points,'#2f6fed')));
    } catch(e) {inner.innerHTML=tabs+'<p>读取失败，请重试。</p>';}
    $$('.px-tabs button',inner).forEach(b=>b.onclick=()=>render(b.dataset.w));
  };
  render(pxWindow);
}
function pxGrid(data,d) {
  return Object.keys(data).length ? `<div class="px-grid">${Object.entries(data).map(([k,v])=>pxCard(k,v,'#2f6fed',v.source,d)).join('')}</div>` : pxPlaceholder();
}
function pxCard(key,d,color,label,card) {
  const s=d.stats,cur=d.currency;
  return `<div class="px-card">
    <div class="px-head"><span class="px-src">${esc(label)} · ${esc(KIND_LABEL[d.kind]||d.kind)}</span><span>${esc(cur)}</span></div>
    <p>${esc(d.condition)} · ${esc(d.variant||'未标注变体')}</p>
    <div class="px-big">${fmtMoney(s.latest,cur)}<small>最新记录</small></div>
    <div class="px-cny">${fmtCNY(toCNY(s.latest,cur))} · ${s.count} 条记录</div>
    <canvas class="px-chart" id="ch-${key}"></canvas>
    <div class="px-kv"><span>报告日期</span><b>${esc(s.latest_ts)}</b></div>
    <div class="px-kv"><span>区间最低 / 最高</span><b>${fmtMoney(s.min,cur)} / ${fmtMoney(s.max,cur)}</b></div>
    <div class="trade-list">${d.trades.map(t=>`<div class="trade"><span>${esc(t.ts)}<small style="display:block">${t.fetched_at?'采集 '+esc(t.fetched_at):''}</small> ${t.url&&/^https?:\/\//.test(t.url)?`<a href="${esc(t.url)}" target="_blank" rel="noopener">来源 ↗</a>`:''}</span><span>${fmtMoney(t.price,t.currency)}</span></div>`).join('')}</div>
  </div>`;
}

/* 迷你折线图 */
function drawChart(canvasId, points, color, cur) {
  const cv = document.getElementById(canvasId);
  if (!cv || !points || points.length < 1) return;
  const dpr = window.devicePixelRatio || 1;
  const w = cv.clientWidth, h = cv.clientHeight;
  cv.width = w * dpr; cv.height = h * dpr;
  const ctx = cv.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, w, h);

  const vals = points.map(p => p.avg);
  const min = Math.min(...vals), max = Math.max(...vals);
  const pad = (max - min) * 0.18 || max * 0.1 || 1;
  const lo = min - pad, hi = max + pad;
  const X = i => points.length === 1 ? w / 2 : 4 + i * (w - 8) / (points.length - 1);
  const Y = v => h - 6 - ((v - lo) / (hi - lo || 1)) * (h - 12);

  // 网格
  ctx.strokeStyle = '#eef0f5'; ctx.lineWidth = 1;
  for (let i = 0; i <= 2; i++) {
    const y = 6 + i * (h - 12) / 2;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }
  // 面积
  const grd = ctx.createLinearGradient(0, 0, 0, h);
  grd.addColorStop(0, color + '33'); grd.addColorStop(1, color + '00');
  ctx.beginPath();
  points.forEach((p, i) => i ? ctx.lineTo(X(i), Y(p.avg)) : ctx.moveTo(X(i), Y(p.avg)));
  ctx.lineTo(X(points.length - 1), h); ctx.lineTo(X(0), h); ctx.closePath();
  ctx.fillStyle = grd; ctx.fill();
  // 线
  ctx.beginPath();
  points.forEach((p, i) => i ? ctx.lineTo(X(i), Y(p.avg)) : ctx.moveTo(X(i), Y(p.avg)));
  ctx.strokeStyle = color; ctx.lineWidth = 1.8; ctx.lineJoin = 'round'; ctx.stroke();
  // 点
  if (points.length <= 40) {
    points.forEach((p, i) => {
      ctx.beginPath(); ctx.arc(X(i), Y(p.avg), 2, 0, 7);
      ctx.fillStyle = '#fff'; ctx.fill();
      ctx.strokeStyle = color; ctx.lineWidth = 1.4; ctx.stroke();
    });
  }
}

/* ---------------- 事件 ---------------- */
function bind() {
  $$('.zone').forEach(b => b.onclick = async () => {
    if (state.zone === b.dataset.zone) return;
    state.zone = b.dataset.zone;
    $$('.zone').forEach(x => x.classList.toggle('on', x === b));
    ++cardRequest; state.loading = false;
    if (await reloadFacets()) load(true);
  });
  // 搜索范围仅在日版、美版之间切换
  const sb = $('#scopeBtn');
  if (sb) sb.onclick = async () => {
    const i = SCOPE_ORDER.indexOf(state.lang);
    state.lang = SCOPE_ORDER[(i + 1) % SCOPE_ORDER.length];
    toast('搜索范围：' + SCOPE_LABEL[state.lang] + '，正在重算筛选项…');
    ++cardRequest; state.loading = false;
    state.sets = []; state.rarities = []; state.variant = '';
    $('#setSearch').value = ''; openEras.clear();
    syncControls();
    if (await reloadFacets()) load(true);
  };

  const onSearch = debounce(() => {
    state.q = $('#q').value.trim();
    $('#qClear').hidden = !state.q;
    load(true);
  }, 220);
  $('#q').oninput = onSearch;
  $('#qClear').onclick = () => { $('#q').value = ''; state.q = ''; $('#qClear').hidden = true; load(true); };

  $('#sort').onchange = e => { state.sort = e.target.value; load(true); };

  [['popMin', 'popMin'], ['popMax', 'popMax'], ['rateMin', 'rateMin'],
   ['rateMax', 'rateMax'], ['diffMin', 'diffMin'], ['diffMax', 'diffMax']]
    .forEach(([id, key]) => {
      $('#' + id).onchange = e => { state[key] = e.target.value; load(true); };
    });

  ['variant','variantPopMax','variant10Max'].forEach(id=>$('#'+id).onchange=e=>{state[id]=e.target.value;load(true);});

  $('#hasPop').onchange = e => { state.hasPop = e.target.checked; load(true); };

  $$('#popPresets button').forEach(b => b.onclick = () => {
    state.popMin = b.dataset.min; state.popMax = b.dataset.max;
    $('#popMin').value = state.popMin; $('#popMax').value = state.popMax;
    $$('#popPresets button').forEach(x => x.classList.toggle('on', x === b));
    load(true);
  });
  $$('#ratePresets button').forEach(b => b.onclick = () => {
    state.rateMin = b.dataset.min; state.rateMax = b.dataset.max;
    $('#rateMin').value = state.rateMin; $('#rateMax').value = state.rateMax;
    $$('#ratePresets button').forEach(x => x.classList.toggle('on', x === b));
    load(true);
  });

  $('#resetAll').onclick = () => {
    Object.assign(state, {
      q: '', sort: 'relevance', sets: [], rarities: [],
      popMin: '', popMax: '', rateMin: '', rateMax: '', diffMin: '', diffMax: '', hasPop: false, variant: '', variantPopMax: '', variant10Max: '',
    });
    $('#setSearch').value = ''; renderFacets();
    syncControls();
    $$('#popPresets button,#ratePresets button').forEach(x => x.classList.remove('on'));
    load(true);
  };

  $('#more').onclick = () => { if (state.loading) return; state.page++; load(false); };

  $('#mask').onclick = closeDrawer;
  $('#drawerX').onclick = closeDrawer;
  document.addEventListener('keydown', e => {
    if (e.key === '/' && !['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)) { e.preventDefault(); $('#q').focus(); }
    if (e.key === 'Escape') closeDrawer();
  });

  // 无限滚动
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (ticking || state.loading || $('#more').hidden) return;
    if (window.innerHeight + window.scrollY > document.body.offsetHeight - 700) {
      ticking = true;
      state.page++; load(false).then(() => ticking = false);
    }
  });
}

bind();
boot();
