"""Provenance, validated imports and isolated price/pop observations. Standard library only."""
import csv
import io
import json
import math
import sqlite3
from datetime import datetime, timezone, date
from urllib.parse import urlparse
import db
import scoring

SOURCES = [
 {'id':'tcgcsv','name':'TCGCSV / TCGplayer','mode':'自动更新','url':'https://tcgcsv.com','note':'裸卡市场参考价；按印刷变体区分，不是逐笔成交或 PSA10 价格。'},
 {'id':'catalog_en','name':'Pokemon TCG Data','mode':'自动更新','url':'https://github.com/PokemonTCG/pokemon-tcg-data','note':'英文新卡与卡图；开源社区卡表，可能晚于实际发售。'},
 {'id':'catalog_ja','name':'宝可梦日文官方卡表','mode':'自动更新','url':'https://www.pokemon-card.com/card-search/','note':'日文新卡；仅新增，不覆盖已有系列修复。'},
 {'id':'gemrate','name':'GemRate','mode':'查询 / CSV 导入','url':'https://www.gemrate.com/','note':'尚未验证免费批量接口；导入时必须标注报告日期。'},
 {'id':'betterpop','name':'BetterPop / GemRate','mode':'自动更新 Pop 快照','url':'https://better-pop.com/app/','note':'公开批量快照已接通；显示来源批次日期，不等于 PSA 官方报告日。无法确认的卡牌保留待核验。'},
 {'id':'psa','name':'PSA 旧数据','mode':'停止自动抓取','url':'https://www.psacard.com/pop','note':'保留原有数据和日期，部分旧数据的变体覆盖问题尚未核验。'}]

SCHEMA = '''
CREATE TABLE IF NOT EXISTS observations (
 id INTEGER PRIMARY KEY, card_id TEXT NOT NULL, source TEXT NOT NULL,
 metric TEXT NOT NULL, variant TEXT NOT NULL DEFAULT '', report_date TEXT NOT NULL,
 value REAL NOT NULL, total INTEGER, currency TEXT NOT NULL DEFAULT '',
 condition TEXT NOT NULL DEFAULT '', url TEXT, fetched_at TEXT NOT NULL,
 external_id TEXT NOT NULL DEFAULT '',
 UNIQUE(card_id,source,metric,variant,report_date,currency,condition,external_id)
);
CREATE INDEX IF NOT EXISTS obs_card ON observations(card_id,metric,report_date);
CREATE TABLE IF NOT EXISTS sync_runs (
 id INTEGER PRIMARY KEY, source TEXT, started_at TEXT, finished_at TEXT,
 status TEXT, message TEXT, added INTEGER DEFAULT 0, updated INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sync_settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS source_cache (key TEXT PRIMARY KEY,value TEXT);
DROP VIEW IF EXISTS current_variants;
CREATE VIEW current_variants AS
 SELECT o.card_id,o.variant,o.source,o.report_date,CAST(o.total AS INTEGER) psa_total,
 CAST(o.value AS INTEGER) psa_10,o.url,o.fetched_at
 FROM observations o WHERE o.metric='pop' AND o.variant!='__all__'
 AND o.id=(SELECT z.id FROM observations z WHERE z.card_id=o.card_id AND z.metric='pop'
 AND z.variant=o.variant ORDER BY z.report_date DESC,z.fetched_at DESC,z.id DESC LIMIT 1);
'''

def now():
 return datetime.now(timezone.utc).isoformat(timespec='microseconds')

def init(c):
 c.executescript(SCHEMA)
 columns={r[1] for r in c.execute('PRAGMA table_info(cards)')}
 if 'pop_scope' not in columns:
  c.execute('ALTER TABLE cards ADD COLUMN pop_scope TEXT')
 if 'pop_source' not in columns:
  c.execute('ALTER TABLE cards ADD COLUMN pop_source TEXT')
 # One-time migration retains original report dates, never invents a fresh report.
 if not c.execute("SELECT 1 FROM sync_settings WHERE key='migrated'").fetchone():
  c.execute('''INSERT OR IGNORE INTO observations
   (card_id,source,metric,variant,report_date,value,total,fetched_at)
   SELECT card_id,'psa_legacy','pop',variant,report_date,psa_10,psa_total,report_date
   FROM card_variants WHERE psa_10 IS NOT NULL AND psa_total IS NOT NULL''')
  c.execute("INSERT INTO sync_settings VALUES('migrated','true')")
 c.commit()

DEFAULT = {'enabled':True,'interval_hours':24,'catalog_en':True,'catalog_ja':True,'tcgcsv':True,'betterpop':True}
def settings(c):
 s=dict(DEFAULT)
 for r in c.execute('SELECT key,value FROM sync_settings'):
  if r['key'] in s: s[r['key']]=json.loads(r['value'])
 return s

def save_settings(c,s):
 unknown=set(s)-set(DEFAULT)
 if unknown: raise ValueError('未知设置项')
 for k,v in s.items():
  if k=='interval_hours':
   if isinstance(v,bool) or not isinstance(v,int) or not 24<=v<=720: raise ValueError('更新间隔须为 24–720 小时')
  elif not isinstance(v,bool): raise ValueError('开关须为 true/false')
 for k,v in s.items(): c.execute('INSERT OR REPLACE INTO sync_settings VALUES(?,?)',(k,json.dumps(v)))
 c.commit()
 return settings(c)

def status(c):
 return {'settings':settings(c),'sources':SOURCES,'runs':[dict(r) for r in c.execute('SELECT * FROM sync_runs ORDER BY id DESC LIMIT 30')],
 'counts':{'cards':c.execute('SELECT count(*) FROM cards').fetchone()[0],
 'market':c.execute("SELECT count(DISTINCT card_id) FROM observations WHERE metric='market'").fetchone()[0]}}

def safe_url(s):
 s=(s or '').strip()
 if s and (urlparse(s).scheme not in ('https','http') or not urlparse(s).netloc): raise ValueError('来源网址须为 http(s) 链接')
 return s

def write_observation(c,r):
 c.execute('''INSERT INTO observations(card_id,source,metric,variant,report_date,value,total,currency,condition,url,fetched_at,external_id)
 VALUES(:card_id,:source,:metric,:variant,:report_date,:value,:total,:currency,:condition,:url,:fetched_at,:external_id)
 ON CONFLICT(card_id,source,metric,variant,report_date,currency,condition,external_id)
 DO UPDATE SET value=excluded.value,total=excluded.total,url=excluded.url,fetched_at=excluded.fetched_at''',r)

def validate(c,r):
 r={k:str(v).strip() if v is not None else '' for k,v in r.items()}
 cid=r.get('card_id','')
 if not c.execute('SELECT 1 FROM cards WHERE card_id=?',(cid,)).fetchone(): raise ValueError('卡牌 ID 不存在：'+cid)
 metric=r.get('metric','')
 if metric not in ('pop','market','trade','listing'): raise ValueError('metric 须为 pop/market/trade/listing')
 source=r.get('source','')
 if not source or len(source)>80: raise ValueError('请填写来源')
 dt=r.get('report_date','')
 parsed=date.fromisoformat(dt)
 if parsed>date.today(): raise ValueError('报告日期不能是未来日期')
 value=float(r.get('value',''))
 if not math.isfinite(value) or value<0: raise ValueError('数值必须为非负有限数')
 variant=r.get('variant','')
 total=None; currency=r.get('currency','').upper();condition=r.get('condition','')
 if metric=='pop':
  total=int(r.get('total',''))
  if not value.is_integer() or total<value: raise ValueError('PSA10 须为整数且不大于总 Pop')
  if not variant: raise ValueError('Pop 须指定变体；整卡总量填 __all__')
  currency='';condition='PSA'
 else:
  if currency not in ('USD','JPY','CNY','EUR','GBP'): raise ValueError('不支持的币种')
  if not condition: raise ValueError('请填写品相 / 评级（如 raw 或 PSA 10）')
  if metric=='trade' and not r.get('external_id'): raise ValueError('成交必须填唯一 external_id，防止重复或合并不同交易')
 return dict(card_id=cid,source=source,metric=metric,variant=variant,report_date=dt,value=value,total=total,currency=currency,
 condition=condition,url=safe_url(r.get('url','')),fetched_at=now(),external_id=r.get('external_id',''))

def import_rows(c, rows, preview=True):
 if not rows or len(rows)>10000: raise ValueError('每次导入 1–10000 行')
 checked=[]; errors=[]; keys=set()
 for n,row in enumerate(rows,2):
  try:
   r=validate(c,row)
   k=tuple(r[x] for x in ('card_id','source','metric','variant','report_date','currency','condition','external_id'))
   if k in keys: raise ValueError('文件中存在重复记录键')
   keys.add(k);checked.append(r)
  except (ValueError,TypeError) as e: errors.append({'row':n,'error':str(e)})
 if errors: return {'ok':False,'valid':len(checked),'errors':errors[:100],'written':0}
 if preview: return {'ok':True,'valid':len(checked),'preview':checked[:10],'written':0}
 try:
  for r in checked:
   write_observation(c,r)
   # Only explicitly declared whole-card totals replace the card-level value.
   if r['metric']=='pop' and r['variant']=='__all__':
    old=c.execute('SELECT * FROM cards WHERE card_id=?',(r['card_id'],)).fetchone()
    if not old['psa_report_date'] or r['report_date']>=old['psa_report_date']:
     diff,detail=scoring.difficulty(old['price_usd'],r['total'],old['rarity_tier'],bool(old['is_promo']),old['release_date'])
     c.execute('''UPDATE cards SET psa_total=?,psa_10=?,psa10_rate=?,psa_report_date=?,pop_updated=?,pop_source=?,
      pop_scope='reported_total',psa_9=NULL,psa_8=NULL,psa_7=NULL,psa_half=NULL,psa_lower=NULL,difficulty=?,diff_json=? WHERE card_id=?''',
      (r['total'],int(r['value']),scoring.psa10_rate(int(r['value']),r['total']),r['report_date'],r['fetched_at'],r['source'],diff,json.dumps(detail),r['card_id']))
  c.commit()
 except Exception:
  c.rollback();raise
 return {'ok':True,'valid':len(checked),'written':len(checked)}

def read_csv(text):
 reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
 if not {'card_id','source','metric','report_date','value'}.issubset(reader.fieldnames or []): raise ValueError('CSV 缺少必要列，请下载模板')
 return list(reader)

def provenance(c,cid):
 row=c.execute("SELECT source,report_date,fetched_at,url FROM observations WHERE card_id=? AND metric='pop' AND variant='__all__' AND report_date=(SELECT psa_report_date FROM cards WHERE card_id=?) AND source=(SELECT pop_source FROM cards WHERE card_id=?) ORDER BY id DESC LIMIT 1",(cid,cid,cid)).fetchone()
 return dict(dict(row),note='BetterPop 数据集批次日期；整卡值为已匹配变体合计，并非官方完整总量。') if row and row['source']=='betterpop' else dict(row) if row else {'source':'psa_legacy','note':'旧版数据，变体覆盖待核验'}

def price_series(c,cid,days=None):
 sql="SELECT * FROM observations WHERE card_id=? AND metric!='pop'";args=[cid]
 if days:
  from datetime import timedelta
  sql+=' AND report_date>=?';args.append((date.today()-timedelta(days=days)).isoformat())
 records=[dict(r) for r in c.execute(sql+' ORDER BY report_date,id',args)]
 # Historical records stay distinct by source, kind, condition and currency.
 oldsql='SELECT * FROM price_points WHERE card_id=?';oldargs=[cid]
 if days: oldsql+=' AND substr(ts,1,10)>=?';oldargs.append(args[-1])
 for r in c.execute(oldsql+' ORDER BY ts,id',oldargs):
  records.append(dict(source=r['source'],metric=r['kind'],variant='',report_date=r['ts'],value=r['price'],currency=r['currency'],condition=r['condition'] or '未标注品相',url=r['url'] or '',fetched_at='',external_id=str(r['id'])))
 groups={}
 for r in records:
  k=(r['source'],r['metric'],r['variant'],r['currency'],r['condition'])
  groups.setdefault(k,[]).append(r)
 out={}
 for i,(k,rs) in enumerate(groups.items()):
  rs.sort(key=lambda r:r['report_date']);byday={}
  for r in rs: byday.setdefault(r['report_date'][:10],[]).append(r['value'])
  pts=[dict(date=d,avg=sum(v)/len(v)) for d,v in sorted(byday.items())]
  vals=[r['value'] for r in rs]
  out[str(i)]={'source':k[0],'kind':k[1],'variant':k[2],'currency':k[3],'condition':k[4],'points':pts,
   'stats':dict(count=len(rs),avg=sum(vals)/len(vals),min=min(vals),max=max(vals),latest=rs[-1]['value'],latest_ts=rs[-1]['report_date'],first_ts=rs[0]['report_date']),
   'trades':[dict(ts=r['report_date'],price=r['value'],currency=r['currency'],kind=r['metric'],url=r['url'],fetched_at=r['fetched_at']) for r in rs[-40:]][::-1]}
 return out
