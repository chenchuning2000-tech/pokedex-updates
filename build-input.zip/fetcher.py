"""带重试的抓取层。

两条通道：
  1. urllib（标准库，用户机器上通常最省事）
  2. curl 子进程（本机代理会破坏 urllib 的 TLS 握手，curl 能过）
任一通道成功即返回；全部失败才抛异常。带主机级限速，避免打崩对方站点。
"""
from __future__ import annotations

import json
import random
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
DEFAULT_HEADERS = {
    "User-Agent": UA,
    "Accept": "application/json, text/html;q=0.9, */*;q=0.8",
    "Accept-Language": "ja,en-US;q=0.8,zh-CN;q=0.7",
}

_last_hit: dict[str, float] = {}
MIN_INTERVAL = 0.25  # 同一主机最小间隔（秒）


class FetchError(RuntimeError):
    pass


def _throttle(url: str) -> None:
    host = urllib.parse.urlparse(url).netloc
    prev = _last_hit.get(host, 0.0)
    wait = MIN_INTERVAL - (time.time() - prev)
    if wait > 0:
        time.sleep(wait)
    _last_hit[host] = time.time()


def _via_urllib(url: str, headers: dict, timeout: int) -> bytes:
    req = urllib.request.Request(url, headers=headers)
    ctx = None
    try:
        import ssl
        ctx = ssl.create_default_context()
    except Exception:
        pass
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.read()


def _via_curl(url: str, headers: dict, timeout: int) -> bytes:
    cmd = ["curl", "-sS", "--max-time", str(timeout), "--compressed",
           "-A", headers.get("User-Agent", UA)]
    for k, v in headers.items():
        if k.lower() == "user-agent":
            continue
        cmd += ["-H", f"{k}: {v}"]
    cmd.append(url)
    p = subprocess.run(cmd, capture_output=True, timeout=timeout + 15)
    if p.returncode != 0:
        raise FetchError(f"curl rc={p.returncode}: {p.stderr[:200]!r}")
    if not p.stdout:
        raise FetchError("curl 返回空响应")
    return p.stdout


def get_bytes(url: str, headers: dict | None = None, *,
              retries: int = 6, timeout: int = 45,
              prefer_curl: bool = False) -> bytes:
    hdrs = dict(DEFAULT_HEADERS)
    if headers:
        hdrs.update(headers)
    last_err: Exception | None = None
    order = (_via_curl, _via_urllib) if prefer_curl else (_via_urllib, _via_curl)
    for attempt in range(retries):
        _throttle(url)
        for fn in order:
            try:
                data = fn(url, hdrs, timeout)
                if data:
                    return data
                last_err = FetchError("空响应")
            except Exception as e:  # noqa: BLE001
                last_err = e
        sleep = min(12.0, 1.2 * (2 ** attempt)) + random.random()
        time.sleep(sleep)
    raise FetchError(f"抓取失败 {url} :: {last_err}")


def get_text(url: str, headers: dict | None = None, *, encoding: str = "utf-8",
             **kw: Any) -> str:
    return get_bytes(url, headers, **kw).decode(encoding, "ignore")


def get_json(url: str, headers: dict | None = None, **kw: Any) -> Any:
    return json.loads(get_text(url, headers, **kw))
