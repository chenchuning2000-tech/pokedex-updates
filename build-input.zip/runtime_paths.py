"""Writable data belongs beside the app; frozen resources stay in the bundle."""
import os,sys
from pathlib import Path
FROZEN=bool(getattr(sys,'frozen',False))
APP_ROOT=Path(os.environ.get('POKEDEX_APP_ROOT') or (Path(sys.executable).resolve().parent if FROZEN else Path(__file__).resolve().parent))
ASSET_ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
