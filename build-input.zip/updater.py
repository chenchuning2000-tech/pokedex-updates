"""Daily local updater. Never contacts PSA. Cross-process OS lock; no retry on blocks."""
import argparse
import hashlib
import json
import os
import re
import sqlite3
import threading
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
import db
import hub
from tools import ingest_en as en, ingest_jp as jp

from runtime_paths import APP_ROOT
ROOT=APP_ROOT
CACHE=ROOT/'data'/'http_cache'
RUN_LOCK=threading.Lock()
LAST_REQUEST=0.0

def fetch(url, build=None, json_result=True):
 global LAST_REQUEST
 key=hashlib.sha256((url+'|'+str(build)).encode()).hexdigest()
 path=CACHE/key
 if build and path.exists():
  data=path.read_bytes()
 else:
  time.sleep(max(0,0.4-(time.monotonic()-LAST_REQUEST)))
  LAST_REQUEST=time.monotonic()
  req=urllib.request.Request(url,headers={'User-Agent':'PokedexLocal/2.0','Accept':'application/json,text/html,text/plain'})
  with urllib.request.urlopen(req,timeout=25) as r:
   data=r.read(30_000_001)
  if len(data)>30_000_000: raise ValueError('响应过大，已停止此来源')
  if build:
   CACHE.mkdir(parents=True,exist_ok=True)
   tmp=path.with_suffix('.tmp');tmp.write_bytes(data);tmp.replace(path)
 if json_result:
  obj=json.loads(data)
  if isinstance(obj,dict) and obj.get('success') is False: raise ValueError('数据源返回失败')
  return obj
 return data.decode('utf-8')

def progress(c,source,message):
 c.execute("UPDATE sync_runs SET message=? WHERE source=? AND status='running'",(message,source));c.commit()

def cv(c,key,default=None):
 r=c.execute('SELECT value FROM source_cache WHERE key=?',(key,)).fetchone()
 return r[0] if r else default

def put(c,key,value):
 c.execute('INSERT OR REPLACE INTO source_cache VALUES(?,?)',(key,str(value)));c.commit()

def normalize(s):
 return re.sub(r'[^a-z0-9]','',(s or '').lower().replace('&','and'))

def number(s):
 s=(s or '').split('/')[0].strip().upper()
 return str(int(s)) if s.isdigit() else s

def match_set(c,group):
 name=group['name'].split(': ',1)[-1]
 candidates=[r for r in c.execute("SELECT set_id,name FROM sets WHERE lang='en'") if normalize(r['name'])==normalize(name)]
 return candidates[0]['set_id'] if len(candidates)==1 else None

def match_product(c,sid,p):
 fields={x['name']:x.get('value','') for x in p.get('extendedData',[])}
 num=fields.get('Number')
 if not num: return None
 # Strict set + exact card number + exact normalized name; ambiguous matches are skipped.
 rows=[r for r in c.execute('SELECT card_id,number,name FROM cards WHERE set_id=?',(sid,)) if number(r['number'])==number(num) and normalize(r['name'])==normalize(p.get('name'))]
 return rows[0]['card_id'] if len(rows)==1 else None

def sync_tcgcsv(c):
 build=fetch('https://tcgcsv.com/last-updated.txt',json_result=False).strip()
 dt=datetime.fromisoformat(build.replace('Z','+00:00')).date().isoformat()
 if cv(c,'tcg_build')==build: return 0,0,'来源批次未变化'
 groups=fetch('https://tcgcsv.com/tcgplayer/3/groups',build)['results']
 matched=0;prices=0;skipped=0
 for g in groups:
  sid=match_set(c,g)
  if not sid: skipped+=1;continue
  gid=g['groupId'];key=f'tcg_group:{gid}'
  if cv(c,key)==build: continue
  base=f'https://tcgcsv.com/tcgplayer/3/{gid}'
  products=fetch(base+'/products',build)['results']
  ps=fetch(base+'/prices',build)['results']
  mapping={}
  for p in products:
   cid=match_product(c,sid,p)
   if cid: mapping[p['productId']]=(cid,p)
  for p in ps:
   hit=mapping.get(p['productId']);value=p.get('marketPrice')
   if not hit or value is None: continue
   cid,product=hit
   r=dict(card_id=cid,source='tcgcsv',metric='market',variant=p.get('subTypeName') or '未标注',report_date=dt,
    value=float(value),total=None,currency='USD',condition='raw',url=hub.safe_url(product.get('url')),fetched_at=hub.now(),external_id=str(p['productId']))
   if r['value']<0: continue
   hub.write_observation(c,r);prices+=1
   c.execute('''INSERT INTO card_links(card_id,source,external_id,url,matched_by,confidence,updated_at) VALUES(?,?,?,?,?,?,?)
    ON CONFLICT(card_id,source) DO UPDATE SET external_id=excluded.external_id,url=excluded.url,updated_at=excluded.updated_at''',
    (cid,'tcgcsv',str(p['productId']),r['url'],'exact set + number + name',1,hub.now()))
  matched+=len(mapping)
  put(c,key,build)
  progress(c,'tcgcsv',f'已更新本轮 {matched} 张卡 / {prices} 条报价；当前系列 {g["name"]}')
 put(c,'tcg_build',build)
 # Only keep a few days of immutable per-build response cache.
 if CACHE.exists():
  for p in CACHE.iterdir():
   if time.time()-p.stat().st_mtime>7*86400: p.unlink()
 return 0,prices,f'匹配 {matched} 张卡，写入 {prices} 个变体报价；{skipped} 个系列未精确匹配，未猜配'

def sync_en(c):
 build=datetime.now(timezone.utc).date().isoformat()
 sets=fetch(en.CDN+'/sets/en.json',build)
 if not isinstance(sets,list) or not sets: raise ValueError('英文系列清单结构异常')
 added=updated=0
 for s in sets:
  key='en_set:'+s['id']
  cards=fetch(en.CDN+'/cards/en/'+s['id']+'.json',build)
  digest=hashlib.sha256(json.dumps([s,cards],sort_keys=True).encode()).hexdigest()
  if cv(c,key)==digest: continue
  en.upsert_set(c,s)
  for item in cards:
   cid='en:'+item['id'];old=c.execute('SELECT * FROM cards WHERE card_id=?',(cid,)).fetchone()
   if not item.get('images'):
    item['images']={'small':f"https://images.pokemontcg.io/{s['id']}/{item['number']}.png",'large':f"https://images.pokemontcg.io/{s['id']}/{item['number']}_hires.png"}
   en.upsert_card(c,item,s,en._promo(s))
   if old:
    # Catalog refresh must never erase Chinese aliases or Pop/price history.
    c.execute('UPDATE cards SET search_name=? WHERE card_id=?',(db.normalize_search_name(' '.join(x for x in [old['search_name'],old['name_zh'],item['name']] if x)),cid))
    updated+=1
   else: added+=1
  put(c,key,digest)
  progress(c,'catalog_en',f'处理系列 {s["name"]}，本轮新增 {added} 张')
 return added,updated,f'新增 {added} 张，刷新 {updated} 张；既有 Pop 与价格保留'

def sync_ja(c):
 # Read all index pages so late inserts into old sets are not missed; detail pages only for new IDs.
 build=datetime.now(timezone.utc).date().isoformat()
 first=fetch(jp.API+'?page=1&regulation_sidebar_form=all',build)
 if 'maxPage' not in first or 'cardList' not in first: raise ValueError('日文卡表结构异常')
 added=0
 for page in range(1,int(first['maxPage'])+1):
  data=first if page==1 else fetch(jp.API+f'?page={page}&regulation_sidebar_form=all',build)
  if 'cardList' not in data: raise ValueError('日文卡表分页结构异常')
  for item in data['cardList']:
   cid='ja:'+str(item['cardID'])
   if c.execute('SELECT 1 FROM cards WHERE card_id=?',(cid,)).fetchone(): continue
   url=jp.BASE+'/card-search/details.php/card/'+str(item['cardID'])
   info=jp.parse_detail(fetch(url,build,json_result=False))
   thumb=item.get('cardThumbFile') or ''
   m=re.search(r'/card_images/(?:large|small)/([A-Za-z0-9_-]+)/',thumb)
   code=m.group(1) if m else info.get('set_code','unknown')
   sid='ja:'+code
   existing=c.execute('SELECT * FROM sets WHERE set_id=?',(sid,)).fetchone()
   name=info.get('name') or item.get('cardNameViewText')
   if not name: raise ValueError('日文新卡缺少名称')
   if existing: setname=existing['name'];promo=bool(existing['is_promo']);rel=existing['release_date']
   else:
    setname=info.get('set_name') or code;promo=code.upper().endswith('-P') or 'プロモ' in setname;rel=None
    jp.upsert_set(c,code,setname,rel,promo)
   img=jp.BASE+thumb if thumb.startswith('/') else thumb
   rarity=(info.get('rarity_code') or '').upper() or None
   tier=db.rarity_tier(rarity)
   import scoring
   diff,detail=scoring.difficulty(None,None,tier,promo,rel)
   num=info.get('number')
   c.execute('''INSERT INTO cards(card_id,set_id,lang,number,number_int,set_total,name,search_name,rarity,rarity_code,rarity_tier,
    artist,image_small,image_large,release_date,is_promo,source_label,source_url,difficulty,diff_json,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
    (cid,sid,'ja',num,en._num_int(num),info.get('set_total'),name,db.normalize_search_name(name),rarity,rarity,tier,info.get('artist'),img,img,rel,int(promo),f'日版《{setname}》；官方卡表',url,diff,json.dumps(detail),hub.now()))
   c.commit();added+=1
  if page%10==0: progress(c,'catalog_ja',f'已扫描 {page}/{first["maxPage"]} 页，新增 {added} 张')
 return added,0,f'扫描 {first["maxPage"]} 页，新增 {added} 张'

class ProcessLock:
 def __enter__(self):
  self.f=open(ROOT/'data'/'update.lock','a+b')
  if os.name=='nt':
   import msvcrt
   self.f.seek(0,2)
   if self.f.tell()==0: self.f.write(b'0');self.f.flush()
   self.f.seek(0)
   try: msvcrt.locking(self.f.fileno(),msvcrt.LK_NBLCK,1)
   except OSError: self.f.close();raise RuntimeError('已有更新任务运行中')
  else:
   import fcntl
   try: fcntl.flock(self.f,fcntl.LOCK_EX|fcntl.LOCK_NB)
   except OSError: self.f.close();raise RuntimeError('已有更新任务运行中')
  return self
 def __exit__(self,*args): self.f.close()

def is_running():
 if RUN_LOCK.locked(): return True
 try:
  with ProcessLock(): return False
 except RuntimeError: return True

def backup(c):
 folder=ROOT/'data'/'backups';folder.mkdir(exist_ok=True)
 path=folder/(datetime.now(timezone.utc).strftime('%Y-%m-%d')+'.db')
 if not path.exists():
  target=sqlite3.connect(str(path)+'.tmp')
  try: c.backup(target)
  finally: target.close()
  Path(str(path)+'.tmp').replace(path)
 for old in sorted(folder.glob('*.db'))[:-3]: old.unlink()

from pop_sync import sync as sync_pop_snapshot
FUNCTIONS={'betterpop':sync_pop_snapshot,'catalog_en':sync_en,'catalog_ja':sync_ja,'tcgcsv':sync_tcgcsv}

def run(selected=None):
 if not RUN_LOCK.acquire(blocking=False): return {'status':'busy'}
 try:
  with ProcessLock():
   c=db.init();hub.init(c)
   try:
    # Any running row here belonged to a terminated process (we hold the OS lock).
    c.execute("UPDATE sync_runs SET status='interrupted',finished_at=?,message='上次进程中断；保留已完成数据，下一轮可续跑' WHERE status='running'",(hub.now(),));c.commit()
    cfg=hub.settings(c);results=[]
    for source,fn in FUNCTIONS.items():
     if selected and source not in selected: continue
     if not cfg[source]: continue
     last=c.execute("SELECT started_at FROM sync_runs WHERE source=? AND status!='partial' ORDER BY id DESC LIMIT 1",(source,)).fetchone()
     if last and (datetime.now(timezone.utc)-datetime.fromisoformat(last[0])).total_seconds()<cfg['interval_hours']*3600:
      results.append({'source':source,'status':'cooldown'});continue
     rid=c.execute("INSERT INTO sync_runs(source,started_at,status,message) VALUES(?,?,'running','正在更新…')",(source,hub.now())).lastrowid;c.commit()
     before=c.execute('SELECT count(*) FROM cards').fetchone()[0]
     before_obs=c.execute('SELECT count(*) FROM observations').fetchone()[0]
     try:
      backup(c)
      added,updated,msg=fn(c);status='success'
     except Exception as e:
      c.rollback();added=c.execute('SELECT count(*) FROM cards').fetchone()[0]-before;updated=0
      updated=c.execute('SELECT count(*) FROM observations').fetchone()[0]-before_obs
      msg=f'{type(e).__name__}: {e}；保留本次已写入的 {updated} 条观测，已停止此来源，下个周期再尝试';status='failed'
     c.execute('UPDATE sync_runs SET finished_at=?,status=?,message=?,added=?,updated=? WHERE id=?',(hub.now(),status,msg,added,updated,rid));c.commit()
     results.append({'source':source,'status':status,'message':msg})
    # Enrich only new / refreshed catalog rows via the bundled local name map.
    if any(x.get('status')=='success' and x['source'].startswith('catalog') for x in results):
     from tools.build_zh_names import apply
     apply()
    return {'status':'finished','results':results}
   finally: c.close()
 except RuntimeError as e: return {'status':'busy','message':str(e)}
 finally: RUN_LOCK.release()

def start():
 if RUN_LOCK.locked(): return {'status':'busy'}
 threading.Thread(target=run,daemon=True,name='data-update').start()
 return {'status':'started'}

def scheduler(stop):
 while not stop.wait(15):
  c=db.connect()
  try: enabled=hub.settings(c)['enabled']
  finally: c.close()
  if enabled: run()
  if stop.wait(285): return

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--source',choices=list(FUNCTIONS),action='append');ap.add_argument('--scheduled',action='store_true');a=ap.parse_args()
 c=db.init();hub.init(c);enabled=hub.settings(c)['enabled'];c.close()
 print(json.dumps(run(a.source) if enabled or not a.scheduled else {'status':'disabled'},ensure_ascii=False))
