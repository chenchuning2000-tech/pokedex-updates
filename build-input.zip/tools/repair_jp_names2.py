"""补日版系列名（v2）：从卡片详情页的「収録商品」链接取

之前失败的原因：详情页里商品链接有两种形式——
    新系列：/ex/m7/                  （我原来只认这种）
    老系列：/products/xy/20th.html     ← 大多数卡是这种，所以漏了
而且名称不总在 /ex/ 目录页上，直接写在链接文字里：

    <li class="List_item"><a href="/products/xy/20th.html">ポケモンカードゲームXY BREAK 「ポケットモンスターカードゲーム スターターパック」</a></li>

做法：对每个「只有系列码」的日版系列，抽 1 张卡取详情页，解析第一个 List_item 的链接文字，
取「」内的名称；没有「」就剥掉常见前缀。

用法：
    python tools/repair_jp_names2.py --dry-run
    python tools/repair_jp_names2.py
"""
from __future__ import annotations

import argparse
import re
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import db
from fetcher import get_text

BASE = "https://www.pokemon-card.com"
RE_ITEM = re.compile(
    r'<li class="List_item">\s*<a href="([^"]+)"[^>]*>(.*?)</a>', re.S)
RE_BRACKET = re.compile(r"「([^」]+)」")
TAG = re.compile(r"<[^>]+>")

PREFIXES = [
    "ポケモンカードゲーム", "ポケットモンスターカードゲーム", "拡張パック",
    "強化拡張パック", "ハイクラスパック", "ハイクラスデッキ", "スペシャルデッキセット",
    "XY BREAK", "XY", "SM", "S", "SV", "BW", "DP", "PCG", "ADV",
]


def clean(text: str) -> str | None:
    t = TAG.sub(" ", text)
    t = re.sub(r"\s+", " ", t).strip()
    if not t:
        return None
    m = RE_BRACKET.search(t)
    if m:
        return m.group(1).strip() or None
    for p in PREFIXES:
        if t.startswith(p):
            t = t[len(p):].strip()
    t = t.strip("・ 　-")
    return t or None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    conn = db.init()
    # 每个「名字还等于系列码」的系列，抽最多 3 张卡做一致性校验
    rows = []
    for s in conn.execute(
            """SELECT set_id, code FROM sets
               WHERE lang='ja' AND code IS NOT NULL AND name = code"""):
        cids = [r[0] for r in conn.execute(
            "SELECT card_id FROM cards WHERE set_id=? LIMIT 3", (s["set_id"],))]
        rows.append({"set_id": s["set_id"], "code": s["code"], "cids": cids})
    if args.limit:
        rows = rows[: args.limit]
    print(f"待补名的系列 {len(rows)} 个（每个抽 ≤3 张卡校验）")

    ok = skip = 0
    for i, r in enumerate(rows, 1):
        if not r["cids"]:
            print(f"  [{i}/{len(rows)}] {r['code']:8} 没有卡，跳过")
            continue
        names: list[str] = []
        for cid in r["cids"]:
            num = cid.split(":", 1)[-1]
            try:
                h = get_text(f"{BASE}/card-search/details.php/card/{num}")
            except Exception:
                continue
            m = RE_ITEM.search(h)
            nm = clean(m.group(2)) if m else None
            if nm:
                names.append(nm)
        # 名称必须完全一致才采信：大系列里每张卡的「収録商品」是各自的发行活动，
        # 直接取第一条会把系列名写成某个促销活动的名字（如 XYP -> 教室2013 参加賞）
        uniq = set(names)
        if len(uniq) == 1 and len(names) >= 2:
            name = names[0]
            # 再挡一层：如果这个名字就是该系列里某张卡的名字，
            # 说明取到的是「单卡发行活动」而不是系列名（如 BWP -> なぞのタマゴ）
            dup = conn.execute(
                "SELECT 1 FROM cards WHERE set_id=? AND name=? LIMIT 1",
                (r["set_id"], name)).fetchone()
            if dup:
                skip += 1
                print(f"  [{i}/{len(rows)}] {r['code']:8} 与卡名重复，跳过（{name[:30]}）")
                continue
            if not args.dry_run:
                conn.execute("UPDATE sets SET name=? WHERE set_id=?",
                             (name, r["set_id"]))
                conn.commit()
            ok += 1
            print(f"  [{i}/{len(rows)}] {r['code']:8} -> {name}")
        else:
            skip += 1
            sample = " / ".join(sorted(uniq)[:2]) if uniq else "无"
            print(f"  [{i}/{len(rows)}] {r['code']:8} 不一致，跳过（{sample[:40]}）")

    left = conn.execute(
        "SELECT COUNT(*) n FROM sets WHERE lang='ja' AND code IS NOT NULL "
        "AND name = code").fetchone()["n"]
    print(f"\n补上 {ok}，跳过 {skip}；仍只有码 {left} 个"
          + ("（--dry-run 未写库）" if args.dry_run else ""))


if __name__ == "__main__":
    main()
