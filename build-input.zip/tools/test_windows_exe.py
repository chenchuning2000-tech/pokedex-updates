"""Windows CI: run the actual frozen EXE from a directory with spaces and Chinese."""
import json,os,shutil,subprocess,tempfile,time,urllib.request,zipfile,hashlib
from pathlib import Path

def wait_http(port,process):
 for _ in range(90):
  if process.poll() is not None:raise AssertionError('EXE exited before serving HTTP')
  try:
   with urllib.request.urlopen('http://127.0.0.1:%s/api/manage'%port,timeout=1) as r:return json.load(r)
  except Exception:time.sleep(1)
 raise AssertionError('EXE did not start')

def main():
 with tempfile.TemporaryDirectory(prefix='pokedex 中文 test ') as temp:
  root=Path(temp);shutil.copy2('dist/Pokedex.exe',root/'Pokedex.exe')
  log=open(root/'test.log','w',encoding='utf-8')
  p=subprocess.Popen([str(root/'Pokedex.exe'),'--no-browser','--no-auto-update','--port','8777'],cwd=root,stdout=log,stderr=log)
  try:
   d=wait_http(8777,p);assert d['software']['edition']=='Windows 独立版'
   for path in ['/', '/anniversary-assets.css']:
    with urllib.request.urlopen('http://127.0.0.1:8777'+path,timeout=10) as r:assert r.status==200
   second=subprocess.run([str(root/'Pokedex.exe'),'--no-browser','--no-auto-update'],cwd=root,stdout=log,stderr=log,timeout=30)
   assert second.returncode==0
  finally:p.terminate();p.wait(timeout=15);log.close()
  assert (root/'data/cards.db').exists()
  print('Windows EXE HTTP, embedded assets, duplicate launch and writable data passed.')
if __name__=='__main__':main()
