"""修复日版系列归属：把落在 ja:unknown 的卡按卡图路径里的系列码重新归类

背景：日版入库时靠详情页里的「拡張パック」链接取系列，但多数页面没解析到，
15,649 张卡（占日版 66%）被塞进了 ja:unknown，导致时代/系列筛选对它们失效。

关键发现：卡图路径自带系列码，不用重爬详情页：
    /card_images/large/M6a/050813_P_WANINOKO.jpg  -> M6a

做法：
  1. 从 image_large 提取系列码，归并出缺失的系列
  2. 每个系列抓一次 /ex/{code}/ 拿正式名称与发售日（约 100-200 次请求）
  3. 回填 cards.set_id / release_date，并重算时代与难度分

用法：
    python tools/repair_jp_sets.py --dry-run   # 只看会建哪些系列
    python tools/repair_jp_sets.py
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import db
import scoring
from fetcher import get_text

BASE = "https://www.pokemon-card.com"
RE_CODE = re.compile(r"/card_images/large/([A-Za-z0-9]+)/")
PROMO_HINTS = ("プロモ", "PROMO", "promo", "スペシャル")


def fetch_set_meta(code: str) -> tuple[str | None, str | None]:
    """返回 (系列名, 发售日)。拿不到就返回 None，不猜。"""
    url = f"{BASE}/ex/{code}/"
    try:
        h = get_text(url)
    except Exception:
        return None, None
    # 老系列（XYP / SMP / BWP / DPP…）在 /ex/ 下是 404，别把 404 页的标题当系列名
    if len(h) < 600 or "404" in h[:400] or "Not Found" in h[:400] \
            or "ページが見つかりません" in h:
        return None, None

    name = None
    m = re.search(r'<meta[^>]+property="og:title"[^>]+content="([^"]+)"', h)
    if not m:
        m = re.search(r"<title>([^<]*)</title>", h)
    if m:
        name = m.group(1)
        name = re.split(r"[｜|]", name)[0].strip()
        name = re.sub(r"^拡張パック|強化拡張パック|ハイクラスパック", "", name).strip()
        mm = re.search(r"「([^」]+)」", name)
        if mm:
            name = mm.group(1)
        name = name.strip() or None

    rel = None
    m = re.search(r"(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日", h)
    if m:
        rel = f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    else:
        m = re.search(r"発売日[^0-9]{0,24}(\d{4})[./\-](\d{1,2})[./\-](\d{1,2})", h)
        if m:
            rel = f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    return name, rel


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    conn = db.init()

    rows = conn.execute(
        "SELECT card_id, image_large FROM cards WHERE set_id='ja:unknown'").fetchall()
    print(f"待修复卡片：{len(rows)} 张")

    by_code: dict[str, list[str]] = {}
    no_code = 0
    for r in rows:
        m = RE_CODE.search(r["image_large"] or "")
        if not m:
            no_code += 1
            continue
        by_code.setdefault(m.group(1), []).append(r["card_id"])

    print(f"可反推出系列码：{len(by_code)} 个系列，覆盖 "
          f"{sum(len(v) for v in by_code.values())} 张；无码 {no_code} 张")

    codes = sorted(by_code, key=lambda c: -len(by_code[c]))
    if args.limit:
        codes = codes[: args.limit]

    known = {r[0] for r in conn.execute(
        "SELECT code FROM sets WHERE lang='ja' AND code IS NOT NULL")}

    created = moved = 0
    for i, code in enumerate(codes, 1):
        set_id = f"ja:{code}"
        card_ids = by_code[code]
        if code in known:
            name, rel = None, None
            row = conn.execute("SELECT name, release_date FROM sets WHERE set_id=?",
                               (set_id,)).fetchone()
            if row:
                name, rel = row["name"], row["release_date"]
        else:
            name, rel = fetch_set_meta(code)
            is_promo = any(k in (name or "") for k in PROMO_HINTS) or \
                code.upper().endswith("-P") or code.upper().endswith("P")
            era = db.era_of("ja", None, code, name)
            print(f"  [{i}/{len(codes)}] 新建 {code:8} {name or '(未取到名称)'} "
                  f"{rel or ''} · {len(card_ids)} 张 · era={era}")
            if not args.dry_run:
                conn.execute(
                    """INSERT INTO sets(set_id,lang,code,name,name_en,series,era,
                           release_date,printed_total,total,is_promo,source_url)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(set_id) DO UPDATE SET name=excluded.name,
                         era=excluded.era,
                         release_date=COALESCE(excluded.release_date, sets.release_date)""",
                    (set_id, "ja", code, name or code, None, "ポケモンカードゲーム",
                     era, rel, None, None, int(is_promo), f"{BASE}/ex/{code}/"))
                created += 1
        if args.dry_run:
            continue

        for cid in card_ids:
            conn.execute("UPDATE cards SET set_id=?, release_date=? WHERE card_id=?",
                         (set_id, rel, cid))
            moved += 1
        conn.commit()

    if args.dry_run:
        print("（--dry-run：未写库）")
        return

    # 剩下的无码卡：给一个明确命名的兜底系列，别再叫 unknown
    left = conn.execute("SELECT COUNT(*) n FROM cards WHERE set_id='ja:unknown'").fetchone()["n"]
    if left:
        conn.execute(
            """INSERT INTO sets(set_id,lang,code,name,name_en,series,era,release_date,
                   printed_total,total,is_promo,source_url)
               VALUES('ja:unclassified','ja',NULL,'未归类','Unclassified',
                      'ポケモンカードゲーム','other',NULL,NULL,NULL,0,NULL)
               ON CONFLICT(set_id) DO NOTHING""")
        conn.execute("UPDATE cards SET set_id='ja:unclassified' WHERE set_id='ja:unknown'")
        conn.commit()
        print(f"仍有 {left} 张无系列码，归入「未归类」")

    # 系列/卡片的时代与难度重算（release_date 变了，age 因子跟着变）
    db.backfill_era(conn)
    for r in conn.execute(
            "SELECT card_id, rarity_tier, is_promo, release_date, price_usd, psa_total "
            "FROM cards WHERE lang='ja'"):
        diff, detail = scoring.difficulty(
            r["price_usd"], r["psa_total"], r["rarity_tier"],
            bool(r["is_promo"]), r["release_date"])
        conn.execute("UPDATE cards SET difficulty=?, diff_json=? WHERE card_id=?",
                     (diff, json.dumps(detail, ensure_ascii=False), r["card_id"]))
    conn.commit()
    db.set_meta(conn, "jp_set_repair", datetime.now(timezone.utc).isoformat(timespec="seconds"))
    conn.commit()
    print(f"完成：新建系列 {created} 个，迁移卡片 {moved} 张")


if __name__ == "__main__":
    main()
