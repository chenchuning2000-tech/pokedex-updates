"""PSA Pop 同步（登录态 + 无头浏览器）

前置：先跑一次 tools/psa_login.py 存下登录态（psacard.com 的 pop 报告已强制登录）。

站点结构（2026-11 实测）：
    /pop/tcg-cards/156940                 TCG 大类 -> 年份
    /pop/tcg-cards/{年}/{id}              年份 -> 该年全部 TCG 系列（DataTables 分页）
    /pop/tcg-cards/{年}/{slug}/{id}       系列 -> 卡片表格
表格列： CARD NO. | NAME | AUTH | 1 | 1.5 | 2 ... 10 | TOTAL
每格三行（分数 / + / Q），第一行是数量。

两个坑：
  · 年份页一次只渲染 50 行，Pokémon 在字母 P 段（第 3-4 页），
    必须把 tableSets_length 设成 250 再逐页翻。
  · 宝可梦没有独立大类，混在 tcg-cards 里，按系列名以 "Pokemon" 开头过滤。

用法：
    python tools/sync_pop.py --list-sets 2023
    python tools/sync_pop.py --year 2023 --dry-run
    python tools/sync_pop.py --year 2023
"""
from __future__ import annotations

import argparse
import os
import re
import sys
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import db

BASE = "https://www.psacard.com"
TCG = "/pop/tcg-cards/156940"
PROFILE = os.path.join(ROOT, "data", "psa_profile")
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")


def launch(pw, headless=True):
    common = dict(user_data_dir=PROFILE, headless=headless, locale="en-US",
                  user_agent=UA, viewport={"width": 1440, "height": 1400},
                  args=["--disable-blink-features=AutomationControlled", "--no-sandbox"])
    for ch in ("msedge", "chrome"):
        try:
            return pw.chromium.launch_persistent_context(channel=ch, **common)
        except Exception:
            continue
    return pw.chromium.launch_persistent_context(**common)


def _challenged(page) -> bool:
    try:
        t = (page.title() or "").lower()
        return "just a moment" in t or "attention required" in t
    except Exception:
        return False


def goto(page, path: str, tries: int = 3) -> bool:
    url = path if path.startswith("http") else BASE + path
    for k in range(tries):
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=25000)
            page.wait_for_timeout(1600)
            # Cloudflare 人机验证页：等它自己过；过不去判定失败，不要硬刷
            for _ in range(5):
                if not _challenged(page):
                    break
                page.wait_for_timeout(4000)
            if _challenged(page):
                print("    ⚠ Cloudflare 验证未通过")
                return False
            return True
        except Exception:
            if k == tries - 1:
                return False
            page.wait_for_timeout(1500)
    return False


def norm_set(s: str) -> str:
    s = (s or "").lower()
    s = re.sub(r"pok[eé]mon", " ", s)
    s = re.sub(r"\b(tcg|trading card game|cards?|set|edition|series)\b", " ", s)
    s = re.sub(r"[^a-z0-9]+", "", s)
    return s


def num_key(n) -> str:
    s = str(n or "").split("/")[0].strip()
    return re.sub(r"^0+", "", s).lower()


def collect_sets(page, year: str, english_only: bool = False) -> list[tuple[str, str]]:
    """返回 [(系列名, 链接)]，只保留 Pokemon 开头的。"""
    out: list[tuple[str, str]] = []
    # 非英文变体系列：本地库里是英文系列名，跑它们几乎匹配不到，纯浪费时间
    OTHER_LANG = ("french", "german", "spanish", "italian", "portuguese",
                  "korean", "chinese", "japanese", "dutch", "russian", "polish")
    try:
        page.select_option("select[name='tableSets_length']", "250")
        page.wait_for_timeout(2500)
    except Exception:
        pass
    pages = ["1"]
    try:
        opts = page.eval_on_selector_all(
            "select", "els=>els.filter(s=>!s.name).map(s=>[...s.options].map(o=>o.value))")
        if opts:
            pages = opts[0]
    except Exception:
        pass
    print(f"  年份页共 {len(pages)} 页")
    for pg in pages:
        if pg != "1":
            try:
                page.select_option("select:not([name])", pg)
                page.wait_for_timeout(2200)
            except Exception:
                break
        items = page.eval_on_selector_all(
            "a[href*='/pop/tcg-cards/']",
            "els=>els.map(e=>[e.innerText.trim(), e.getAttribute('href')])")
        for name, href in items:
            if not name.lower().startswith("pokemon") or not href or "/tcg-cards/" not in href:
                continue
            if english_only and any(k in name.lower() for k in OTHER_LANG):
                continue
            out.append((name, BASE + href))
    # 去重
    seen, uniq = set(), []
    for n, h in out:
        if h not in seen:
            seen.add(h)
            uniq.append((n, h))
    return uniq


def parse_table(page) -> list[dict]:
    rows = page.eval_on_selector_all(
        "table tr",
        "els=>els.map(tr=>[...tr.querySelectorAll('td,th')].map(td=>td.innerText.trim()))")
    if not rows:
        return []
    head = next(([c.upper() for c in r] for r in rows
                 if any("CARD NO" in c.upper() for c in r)), None)
    if not head:
        return []
    try:
        i_no = next(i for i, c in enumerate(head) if "CARD NO" in c)
        i_name = next(i for i, c in enumerate(head) if c.startswith("NAME"))
        i_10 = next(i for i, c in enumerate(head) if c.strip() == "10")
        i_tot = next(i for i, c in enumerate(head) if c.startswith("TOTAL"))
    except StopIteration:
        return []

    def first(cell: str):
        v = (cell or "").split("\n")[0].strip().replace(",", "")
        return int(v) if v.isdigit() else None

    out = []
    for r in rows:
        if len(r) <= max(i_no, i_name, i_10, i_tot):
            continue
        # 名称栏是多行：第 1 行卡名，第 2 行是变体（Holo / Reverse Holo / 1st Edition…）
        parts = [p.strip() for p in (r[i_name] or "").split("\n") if p.strip()]
        parts = [p for p in parts if "Shop with Affiliates" not in p]
        if not parts:
            continue
        name = parts[0]
        if name.upper().startswith("TOTAL POPULATION"):
            continue
        variant = parts[1] if len(parts) > 1 else ""

        def first(cell: str):
            v = (cell or "").split("\n")[0].strip().replace(",", "")
            return int(v) if v.isdigit() else None

        out.append({"no": r[i_no].strip(), "name": name, "variant": variant,
                    "psa10": first(r[i_10]), "total": first(r[i_tot])})
    return out


def upsert_pop(conn, card_id: str, psa10: int, total: int, report_date: str) -> None:
    rate = round(psa10 / total * 100, 2) if total else None
    conn.execute(
        "UPDATE cards SET psa_total=?, psa_10=?, psa10_rate=?, psa_report_date=?, "
        "pop_updated=? WHERE card_id=?",
        (total, psa10, rate, report_date,
         datetime.now(timezone.utc).isoformat(timespec="seconds"), card_id))
    conn.execute(
        "INSERT INTO pop_history(card_id,report_date,psa_total,psa_10) VALUES(?,?,?,?) "
        "ON CONFLICT(card_id,report_date) DO UPDATE SET "
        "psa_total=excluded.psa_total, psa_10=excluded.psa_10",
        (card_id, report_date, total, psa10))

    # pop 是难度分的第一大因子（权重 40%），拿到 pop 后必须重算，
    # 否则难度分还是入库时那个「无 pop」版本
    import json as _json
    import scoring
    row = conn.execute(
        "SELECT rarity_tier, is_promo, release_date, price_usd FROM cards "
        "WHERE card_id=?", (card_id,)).fetchone()
    if row:
        diff, detail = scoring.difficulty(
            row["price_usd"], total, row["rarity_tier"],
            bool(row["is_promo"]), row["release_date"])
        conn.execute("UPDATE cards SET difficulty=?, diff_json=? WHERE card_id=?",
                     (diff, _json.dumps(detail, ensure_ascii=False), card_id))


def match_sets(local_sets: list[str], psa_name: str) -> list[str]:
    """把 PSA 的系列名对到本地系列。**只接受「等于」或「后缀」匹配**。

    为什么不用子串：PSA 的命名是「大系列 + 具体系列」串在一起，
    例如 Pokemon Sword & Shield Rebel Clash。子串匹配会同时命中
    swordshield 和 rebelclash，按「最长」选又选中了更长的 swordshield，
    结果 Rebel Clash 的 pop 被写到了 Sword & Shield 基础系列上 —— 全错。

    PSA 总是把具体系列放在末尾，所以后缀匹配才是对的：
      pokemonswordshieldrebelclash  -> 命中 rebelclash（后缀）
      pokemonswordshield            -> 命中 swordshield（等于）
      pokemonindonesiansunmoonskyruler -> 无后缀命中 -> 放弃（本地没有该系列）
    宁可少配，绝不把 pop 写到别的卡上。
    """
    p = norm_set(psa_name)
    if not p:
        return []
    cands = [s for s in local_sets
             if s and (p == s or (len(s) >= 5 and p.endswith(s)))]
    if not cands:
        return []
    return [max(cands, key=len)]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--list-sets", metavar="YEAR")
    ap.add_argument("--year", metavar="YEAR")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--headed", action="store_true")
    ap.add_argument("--max-sets", type=int, default=0)
    ap.add_argument("--only", help="只跑系列名包含该子串的（调试用）")
    ap.add_argument("--english-only", action="store_true",
                    help="跳过法/德/西/意/葡/日中韩等语言变体系列")
    args = ap.parse_args()

    from playwright.sync_api import sync_playwright
    conn = db.init()
    report_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # 本地索引：归一化系列名 -> {卡号: [card_id]}
    local: dict[str, dict[str, list[str]]] = {}
    for r in conn.execute(
            "SELECT c.card_id, c.number, s.name AS set_name FROM cards c "
            "JOIN sets s ON s.set_id=c.set_id WHERE c.lang='en'"):
        sn = norm_set(r["set_name"])
        local.setdefault(sn, {}).setdefault(num_key(r["number"]), []).append(r["card_id"])

    with sync_playwright() as pw:
        ctx = launch(pw, headless=not args.headed)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.set_default_timeout(6000)   # 默认 30s 太久，某些页没有控件会白等

        if not args.year and not args.list_sets:
            print("请指定 --year 或 --list-sets")
            ctx.close()
            return

        year = args.year or args.list_sets
        if not goto(page, TCG):
            print("打开 TCG 大类失败")
            ctx.close()
            return
        year_url = next((BASE + l for l in page.eval_on_selector_all(
            "a[href*='/pop/tcg-cards/']", "e=>[...new Set(e.map(x=>x.getAttribute('href')))]")
            if re.match(rf"^/pop/tcg-cards/{year}/\d+$", l)), None)
        if not year_url:
            print(f"找不到 {year} 年份页")
            ctx.close()
            return
        if not goto(page, year_url):
            print("打开年份页失败")
            ctx.close()
            return

        sets = collect_sets(page, year, args.english_only)
        print(f"{year} 年 Pokémon 系列 {len(sets)} 个")
        if args.list_sets:
            for n, h in sets:
                print(f"   {n}  ->  {h}")
            ctx.close()
            return

        if args.only:
            sets = [(n, u) for n, u in sets if args.only.lower() in n.lower()]
            print(f"（--only 过滤后剩 {len(sets)} 个）")
        if args.max_sets:
            sets = sets[: args.max_sets]

        matched = written = 0
        for i, (name, url) in enumerate(sets, 1):
            if not goto(page, url):
                print(f"  [{i}/{len(sets)}] 打开失败 {name}")
                continue
            # 系列页同样是 DataTables：等表格渲染出来，并把每页行数拉到 250
            try:
                page.wait_for_selector("table tr td", timeout=20000)
                page.select_option("select[name='tableSets_length']", "250")
                page.wait_for_timeout(2200)
            except Exception:
                pass
            rows = parse_table(page)
            sns = match_sets(list(local.keys()), name)
            # 同一张卡可能命中多行（不同变体），先按卡汇总再写，
            # 否则后一行会覆盖前一行（这正是之前的 bug）
            agg: dict[str, list[int]] = {}
            vrows: list[tuple] = []
            for row in rows:
                if not row["total"]:
                    continue
                nk = num_key(row["no"])
                for sn in sns:
                    for cid in local[sn].get(nk, []):
                        a = agg.setdefault(cid, [0, 0])
                        a[0] += row["psa10"] or 0
                        a[1] += row["total"]
                        vrows.append((cid, row.get("variant") or "标准",
                                      row["psa10"] or 0, row["total"]))
            hits = len(agg)
            if not args.dry_run:
                for cid, (p10, tot) in agg.items():
                    upsert_pop(conn, cid, p10, tot, report_date)
                    written += 1
                for cid, var, p10, tot in vrows:
                    conn.execute(
                        "INSERT INTO card_variants(card_id,variant,psa_total,psa_10,"
                        "report_date) VALUES(?,?,?,?,?) "
                        "ON CONFLICT(card_id,variant,report_date) DO UPDATE SET "
                        "psa_total=excluded.psa_total, psa_10=excluded.psa_10",
                        (cid, var, tot, p10, report_date))
                conn.commit()
            matched += hits
            print(f"  [{i}/{len(sets)}] {name[:44]:44} 卡{len(rows):5} 匹配{hits:5}"
                  f" | 本地系列 {sns[:2]}")

        print(f"\n完成：匹配 {matched} 张，写入 {written} 张")
        if args.dry_run:
            print("（--dry-run：只统计未写库）")
        ctx.close()


if __name__ == "__main__":
    main()
