"""eBay 成交价同步（官方 API）

为什么不用爬网页：ebay.com 对脚本一律 403。官方 API 通道实测可达，
但必须用你自己的开发者凭据（免费申请，个人账号审核通常 1-3 天）。

准备：
  1. https://developer.ebay.com 注册开发者账号 → Application Keys
  2. 取 App ID (Client ID) 与 Cert ID (Client Secret)
  3. 写到 pokedex/config.json：
       {"ebay": {"app_id": "...", "cert_id": "...", "env": "production"}}

重要口径：eBay 官方 only 提供近 90 天成交（Marketplace Insights）。
因此本脚本写入的成交点最远就是 90 天，年K/全部 不会被凭空延长。

用法：
    python tools/sync_ebay.py --check          # 验证凭据是否可用
    python tools/sync_ebay.py --limit 20       # 同步前 20 张有映射的卡
    python tools/sync_ebay.py --match --limit 20   # 先按卡名搜索并建立映射
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
import urllib.parse
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import db
from fetcher import get_json, get_text

CFG_PATH = os.path.join(ROOT, "config.json")
MS = "https://api.ebay.com/buy/marketplace_insights/v1_beta"
BR = "https://api.ebay.com/buy/browse/v1"


def load_cfg() -> dict:
    if not os.path.exists(CFG_PATH):
        return {}
    with open(CFG_PATH, encoding="utf-8") as f:
        return json.load(f)


def token(cfg: dict) -> str:
    eb = cfg.get("ebay") or {}
    app_id, cert_id = eb.get("app_id"), eb.get("cert_id")
    if not app_id or not cert_id:
        raise SystemExit(
            "缺少 eBay 凭据。请在 pokedex/config.json 写入：\n"
            '{"ebay":{"app_id":"你的AppID","cert_id":"你的CertID","env":"production"}}')
    basic = base64.b64encode(f"{app_id}:{cert_id}".encode()).decode()
    body = ("grant_type=client_credentials"
            "&scope=" + urllib.parse.quote(
                "https://api.ebay.com/oauth/api_scope "
                "https://api.ebay.com/oauth/api_scope/buy.marketplace.insights"))
    import subprocess
    cmd = ["curl", "-sS", "--max-time", "40", "-X", "POST",
           "https://api.ebay.com/identity/v1/oauth2/token",
           "-H", f"Authorization: Basic {basic}",
           "-H", "Content-Type: application/x-www-form-urlencoded",
           "-d", body]
    p = subprocess.run(cmd, capture_output=True, timeout=60)
    data = json.loads(p.stdout or b"{}")
    if "access_token" not in data:
        raise SystemExit(f"取 token 失败：{data}")
    return data["access_token"]


def search_sales(tok: str, q: str, limit: int = 60) -> list[dict]:
    """Marketplace Insights：近 90 天真实成交。"""
    url = (f"{MS}/item_sales/search?q={urllib.parse.quote(q)}&&limit={limit}"
           "&sort=lastSoldDate")
    raw = get_text(url, headers={"Authorization": f"Bearer {tok}",
                                 "X-EBAY-C-MARKETPLACE-ID": "EBAY_US"}, prefer_curl=True)
    d = json.loads(raw or "{}")
    out = []
    for it in (d.get("itemSales") or []):
        price = (it.get("lastSoldPrice") or {})
        if not price.get("value"):
            continue
        out.append({
            "price": float(price["value"]),
            "currency": price.get("currency", "USD"),
            "ts": (it.get("lastSoldDate") or "")[:19],
            "url": it.get("itemWebUrl"),
            "title": it.get("title"),
        })
    return out


def search_listings(tok: str, q: str, limit: int = 50) -> list[dict]:
    url = (f"{BR}/item_summary/search?q={urllib.parse.quote(q)}&limit={limit}"
           "&filter=buyingOptions:{FIXED_PRICE}")
    raw = get_text(url, headers={"Authorization": f"Bearer {tok}",
                                 "X-EBAY-C-MARKETPLACE-ID": "EBAY_US"}, prefer_curl=True)
    d = json.loads(raw or "{}")
    out = []
    for it in (d.get("itemSummaries") or []):
        price = (it.get("price") or {})
        if not price.get("value"):
            continue
        out.append({
            "price": float(price["value"]),
            "currency": price.get("currency", "USD"),
            "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "url": it.get("itemWebUrl"),
            "title": it.get("title"),
        })
    return out


def query_for(card: dict) -> str:
    """构造检索串：卡名 + 编号 + Pokemon，降低他游戏/其他卡的噪声。"""
    name = (card.get("name") or "").replace("'", "")
    return f"{name} {card.get('number') or ''} Pokemon".strip()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--limit", type=int, default=20)
    ap.add_argument("--listings", action="store_true", help="同时抓在售挂价")
    args = ap.parse_args()

    cfg = load_cfg()
    tok = token(cfg)
    print("token 获取成功")

    if args.check:
        try:
            r = search_sales(tok, "Charizard Pokemon", 3)
            print(f"Marketplace Insights 可用，返回 {len(r)} 条成交")
            if r:
                print("示例：", r[0])
        except Exception as e:  # noqa: BLE001
            print("Insights 不可用（可能需要申请权限）：", e)
            print("将退回 Browse API 仅采集挂价。")
        return

    conn = db.init()
    rows = [dict(r) for r in conn.execute(
        "SELECT card_id,name,number FROM cards WHERE lang='en' "
        f"ORDER BY release_date DESC LIMIT {args.limit}")]

    ok = 0
    for i, card in enumerate(rows, 1):
        q = query_for(card)
        try:
            sales = search_sales(tok, q)
        except Exception as e:  # noqa: BLE001
            print(f"[{i}/{len(rows)}] {card['name']} 成交查询失败：{e}")
            sales = []
        for s in sales:
            conn.execute(
                "INSERT OR IGNORE INTO price_points(card_id,source,kind,ts,price,currency,"
                "condition,url,extra) VALUES(?,?,?,?,?,?,?,?,?)",
                (card["card_id"], "ebay", "trade", s["ts"], s["price"], s["currency"],
                 "raw", s["url"], s.get("title")))
        if args.listings:
            try:
                for l in search_listings(tok, q):
                    conn.execute(
                        "INSERT OR IGNORE INTO price_points(card_id,source,kind,ts,price,"
                        "currency,condition,url,extra) VALUES(?,?,?,?,?,?,?,?,?)",
                        (card["card_id"], "ebay", "listing", l["ts"], l["price"],
                         l["currency"], "raw", l["url"], l.get("title")))
            except Exception:
                pass
        conn.commit()
        if sales:
            ok += 1
        print(f"[{i}/{len(rows)}] {card['name']} -> {len(sales)} 条成交")
        time.sleep(0.6)

    db.set_meta(conn, "ebay_last_sync", datetime.now().isoformat(timespec="seconds"))
    conn.commit()
    print(f"完成：{ok}/{len(rows)} 张卡有成交记录")


if __name__ == "__main__":
    main()
