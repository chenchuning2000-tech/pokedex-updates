"""美版入库：PokemonTCG/pokemon-tcg-data（经 jsDelivr CDN）-> 本地 SQLite

为什么不用官方 API：api.pokemontcg.io 实测可用率约 1/6（502/500 频发），
全量 180+ 次请求会被拖到一小时以上。同一份数据的 GitHub 官方仓库
经 jsDelivr 镜像后每个系列一次请求即可，稳定且快。

代价：镜像不含 Tcgplayer / Cardmarket 价格（价格服务当前 500）。
因此难度分走「pop + 罕度 + 年份 + 渠道」四因子，价格缺省时自动降权。

用法：
    python tools/ingest_en.py                 # 全量 177 个系列
    python tools/ingest_en.py --limit-sets 3  # 只跑最新 3 个系列
    python tools/ingest_en.py --set sv3pt5
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import db
import scoring
from fetcher import get_json

CDN = "https://gcore.jsdelivr.net/gh/PokemonTCG/pokemon-tcg-data@master"
PROMO_HINTS = ("promo", "black star", "prerelease", "staff", "league", "play! pokemon")


def _promo(s: dict) -> bool:
    name = (s.get("name") or "").lower()
    sid = (s.get("id") or "").lower()
    if any(h in name for h in PROMO_HINTS):
        return True
    return sid.endswith("p") and not sid[-2:-1].isdigit()


def _date(s):
    return str(s).replace("/", "-") if s else None


def _num_int(number):
    if not number:
        return None
    d = "".join(ch for ch in str(number).split("/")[0] if ch.isdigit())
    return int(d) if d else None


def upsert_set(conn, s: dict) -> None:
    promo = _promo(s)
    era = db.era_of("en", s.get("series"), s.get("id"), s.get("name"))
    conn.execute(
        """INSERT INTO sets(set_id,lang,code,name,name_en,series,era,release_date,
               printed_total,total,is_promo,source_url)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
           ON CONFLICT(set_id) DO UPDATE SET
             name=excluded.name, series=excluded.series, era=excluded.era,
             release_date=excluded.release_date, printed_total=excluded.printed_total,
             total=excluded.total, is_promo=excluded.is_promo""",
        (f"en:{s['id']}", "en", s["id"], s.get("name"), s.get("name"),
         s.get("series"), era, _date(s.get("releaseDate")), s.get("printedTotal"),
         s.get("total"), int(promo),
         f"https://prices.pokemontcg.io/tcgplayer/{s['id']}"),
    )


def upsert_card(conn, c: dict, s: dict, promo: bool) -> None:
    rarity = c.get("rarity")
    tier = db.rarity_tier(rarity)
    rel = _date(s.get("releaseDate"))
    total = s.get("printedTotal") or s.get("total")
    diff, detail = scoring.difficulty(None, None, tier, promo, rel)

    num = c.get("number")
    src = (f"美版《{s.get('name')}》（{s.get('series') or '—'}）"
           f"{s.get('releaseDate') or '—'} 发售，卡号 {num}/{total}")
    if promo:
        src += "；PROMO 渠道：赛事 / 购买赠送 / 特别活动等多渠道散发，具体场次以官方公告为准"

    conn.execute(
        """INSERT INTO cards(card_id,set_id,lang,number,number_int,set_total,name,name_en,
              search_name,rarity,rarity_code,rarity_tier,artist,supertype,image_small,
              image_large,release_date,is_promo,source_label,source_url,
              difficulty,diff_json,updated_at)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
           ON CONFLICT(card_id) DO UPDATE SET
             name=excluded.name, rarity=excluded.rarity, rarity_tier=excluded.rarity_tier,
             image_small=excluded.image_small, image_large=excluded.image_large,
             release_date=excluded.release_date, is_promo=excluded.is_promo,
             source_label=excluded.source_label, search_name=excluded.search_name,
             updated_at=excluded.updated_at""",
        (f"en:{c['id']}", f"en:{s['id']}", "en", num, _num_int(num), total,
         c.get("name"), c.get("name_en") or c.get("name"),
         db.normalize_search_name(c.get("name")), rarity, None, tier,
         c.get("artist"), c.get("supertype"),
         (c.get("images") or {}).get("small"), (c.get("images") or {}).get("large"),
         rel, int(promo), src, f"https://prices.pokemontcg.io/tcgplayer/{c['id']}",
         diff, json.dumps(detail, ensure_ascii=False),
         datetime.now(timezone.utc).isoformat(timespec="seconds")),
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--set", action="append")
    ap.add_argument("--limit-sets", type=int, default=0)
    args = ap.parse_args()

    conn = db.init()
    print("拉取系列清单 …")
    sets = get_json(f"{CDN}/sets/en.json")
    sets.sort(key=lambda s: s.get("releaseDate") or "", reverse=True)
    if args.set:
        sets = [s for s in sets if s["id"] in set(args.set)]
    if args.limit_sets:
        sets = sets[: args.limit_sets]

    total = 0
    for i, s in enumerate(sets, 1):
        try:
            cards = get_json(f"{CDN}/cards/en/{s['id']}.json")
        except Exception as e:  # noqa: BLE001
            print(f"  跳过 {s['id']}：{e}")
            continue
        upsert_set(conn, s)
        promo = _promo(s)
        # 部分卡图字段缺失时用 id 拼 CDN 地址
        for c in cards:
            c.setdefault("name_en", c.get("name"))
            images = c.get("images") or {}
            if not images.get("small"):
                images["small"] = f"https://images.pokemontcg.io/{s['id']}/{c['number']}.png"
            if not images.get("large"):
                images["large"] = f"https://images.pokemontcg.io/{s['id']}/{c['number']}_hires.png"
            c["images"] = images
            upsert_card(conn, c, s, promo)
        conn.commit()
        total += len(cards)
        print(f"[{i}/{len(sets)}] {s.get('name')} (+{len(cards)}) 累计 {total}")

    db.set_meta(conn, "en_last_sync", datetime.now().isoformat(timespec="seconds"))
    conn.commit()
    print(f"完成：{len(sets)} 系列 / {total} 张卡")


if __name__ == "__main__":
    main()
