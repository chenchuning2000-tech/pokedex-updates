"""官方中文名 + 卡名分词索引

中文名来源：PokeAPI 的 pokemon-species.names 里 `zh-hans` 字段，
这是宝可梦官方简体中文译名（喷火龙 / 烈空坐 / 皮卡丘）。
只覆盖「宝可梦」本身；训练家卡、能量卡没有官方中文名数据源，
保持原名并标 zh_mapped=0，不臆造。

分词目的（配合 app.py 的搜索规则）：
    超级烈空坐 -> 分组 [烈空坐|レックウザ|Rayquaza] [超级|メガ|Mega]
    搜「烈空坐」时第二组没被查询覆盖 -> 不命中；与集换社行为一致。
    search_tokens 用空格分「组」，组内用 | 分「别名」。

用法：
    python tools/build_zh_names.py --download   # 下载物种名表（约 1025 次请求，可续跑）
    python tools/build_zh_names.py --apply      # 写入 name_zh / name_core / search_tokens
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import db
from fetcher import get_json

from runtime_paths import APP_ROOT
MAP_PATH = str(APP_ROOT / "data" / "name_map.json")
POKEAPI = "https://pokeapi.co/api/v2/pokeapi"


def download() -> None:
    print("拉取物种清单 …")
    lst = get_json(f"https://pokeapi.co/api/v2/pokemon-species?limit=1200")["results"]
    names: dict[str, dict] = {}
    if os.path.exists(MAP_PATH):
        with open(MAP_PATH, encoding="utf-8") as f:
            names = json.load(f)
    done = 0
    for i, item in enumerate(lst, 1):
        sid = item["url"].rstrip("/").split("/")[-1]
        if sid in names:
            continue
        try:
            d = get_json(f"https://pokeapi.co/api/v2/pokemon-species/{sid}")
        except Exception as e:  # noqa: BLE001
            print(f"  跳过 {sid}: {e}")
            continue
        loc = {n["language"]["name"]: n["name"] for n in d.get("names", [])}
        zh = loc.get("zh-hans") or loc.get("zh-hant")
        if not zh:
            continue
        names[sid] = {"en": loc.get("en"), "ja": loc.get("ja"), "zh": zh,
                      "ja_hrkt": loc.get("ja-hrkt")}
        done += 1
        if i % 40 == 0:
            print(f"[{i}/{len(lst)}] 累计 {len(names)}")
            with open(MAP_PATH, "w", encoding="utf-8") as f:
                json.dump(names, f, ensure_ascii=False)
    with open(MAP_PATH, "w", encoding="utf-8") as f:
        json.dump(names, f, ensure_ascii=False)
    print(f"完成：共 {len(names)} 个物种，本次新增 {done}")


def build_lookup() -> tuple[dict, dict]:
    with open(MAP_PATH, encoding="utf-8") as f:
        raw = json.load(f)
    by_en, by_ja = {}, {}
    for v in raw.values():
        if v.get("en"):
            by_en[v["en"].strip().lower()] = v
        for k in ("ja", "ja_hrkt"):
            if v.get(k):
                by_ja[v[k].strip()] = v
    return by_en, by_ja


def apply() -> None:
    by_en, by_ja = build_lookup()
    print(f"名表：英文 {len(by_en)} / 日文 {len(by_ja)}")
    conn = db.init()
    rows = [dict(r) for r in conn.execute("SELECT card_id,lang,name FROM cards")]

    hit = miss = 0
    for r in rows:
        lang = r["lang"]
        core, pre, suf = db.split_card_name(r["name"])
        entry = by_en.get(core.strip().lower()) if lang == "en" else by_ja.get(core.strip())

        if entry:
            zh_core = entry["zh"]
            name_zh = "".join(
                db.PREFIX_EN.get(p.strip().lower()) or db.PREFIX_JA.get(p) or p
                for p in pre) + zh_core + "".join(suf)
            hit += 1
        else:
            zh_core = None
            name_zh = None
            miss += 1

        # 分组：第 1 组是核心名别名，其后每组一个修饰词（含中文写法）
        groups: list[list[str]] = []
        aliases = [a for a in (zh_core, core,
                               entry.get("en") if entry else None,
                               entry.get("ja") if entry else None) if a]
        if aliases:
            groups.append(aliases)
        for p in pre:
            zhp = db.PREFIX_EN.get(p.strip().lower()) or db.PREFIX_JA.get(p)
            groups.append([x for x in (zhp, p) if x])
        for s in suf:
            groups.append([s])

        tokens = " ".join("|".join(g) for g in groups if g)
        # search_name 是归一化检索串：中文名 + 原名 + 英文名 + 别名，
        # 搜索时直接对其做 LIKE，片假名/大小写差异已被归一化抹平
        blob = " ".join(x for x in (name_zh, r["name"],
                                    entry.get("en") if entry else None,
                                    entry.get("ja") if entry else None) if x)
        conn.execute(
            "UPDATE cards SET name_zh=?, name_core=?, search_tokens=?, zh_mapped=?, "
            "search_name=? WHERE card_id=?",
            (name_zh, zh_core or core, tokens, 1 if entry else 0,
             db.normalize_search_name(blob), r["card_id"]))
    conn.commit()
    db.set_meta(conn, "zh_name_sync", datetime.now().isoformat(timespec="seconds"))
    conn.commit()
    print(f"完成：命中 {hit} 张，未命中 {miss} 张（未命中=无官方中文名的卡）")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--download", action="store_true")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()
    if a.download:
        download()
    elif a.apply:
        apply()
    else:
        print("请加 --download 或 --apply")
