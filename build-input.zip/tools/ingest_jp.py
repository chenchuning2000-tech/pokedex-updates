"""日版入库：pokemon-card.com 官方卡表 -> 本地 SQLite

官方站是 Next.js 前端，但数据走一个公开 JSON 接口：
    GET /card-search/resultAPI.php?page=N&regulation_sidebar_form=all
返回 {"maxPage":607,"hitCnt":23640,"cardList":[{cardID, cardThumbFile, cardNameViewText}]}
详情页 /card-search/details.php/card/{cardID} 里有编号、稀有度图标、所属扩展包、绘师。

已实测：全站约 23640 张、607 页、每页 39 张，按新→旧排序。
因此先跑有限页数时，拿到的是最新系列（通常也是查询热点）。

用法：
    python tools/ingest_jp.py --pages 20        # 只跑最新 20 页（约 780 张）
    python tools/ingest_jp.py --max-cards 2000  # 跑到 2000 张为止
    python tools/ingest_jp.py                   # 全量（约 2.4 万张，耗时数小时）
    python tools/ingest_jp.py --refresh-sets    # 只刷新系列发售日
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import db
import scoring
from fetcher import get_json, get_text

BASE = "https://www.pokemon-card.com"
API = BASE + "/card-search/resultAPI.php"
IMG = BASE + "/assets/images/card_images/large/"

PROMO_SET_HINTS = ("プロモ", "PROMO", "promo", "スペシャル")

# 稀有度图标 -> 代码，例如 /assets/images/card/rarity/ic_rare_c_c.gif -> c
RE_RARITY = re.compile(r"ic_rare_([a-z0-9]+)")
RE_NUM = re.compile(r">\s*([0-9A-Za-z\-]+)\s*/\s*([0-9]+)\s*<")
RE_SETLINK = re.compile(r'href="/ex/([A-Za-z0-9\-_]+)/"[^>]*>([^<]*)<')
RE_SETNAME = re.compile(r"「([^」]+)」")
RE_ILLUS = re.compile(r"イラストレーター</[^>]+>\s*(?:<[^>]+>\s*)*([^<]+)")


def clean(s: str | None) -> str | None:
    if s is None:
        return None
    s = re.sub(r"&nbsp;", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s or None


def parse_detail(h: str) -> dict:
    out: dict = {}
    hs = h.replace("&nbsp;", " ")   # 编号写作 " 001 / 078 "，不换掉实体匹配不到

    m = re.search(r"<title>([^<]*)</title>", h)
    if m:
        out["name"] = clean(m.group(1).split("|")[0]) or None

    m = RE_NUM.search(hs)
    if m:
        out["number"] = clean(m.group(1))
        out["set_total"] = int(m.group(2))

    m = RE_RARITY.search(h)
    if m:
        out["rarity_code"] = m.group(1)

    m = RE_SETLINK.search(h)
    if m:
        out["set_code"] = m.group(1)
        raw = clean(m.group(2)) or ""
        mm = RE_SETNAME.search(raw)
        out["set_name"] = mm.group(1) if mm else (raw.split("「")[-1].rstrip("」") or raw)
        out["set_name"] = out["set_name"].replace("拡張パック", "").strip() or raw

    m = RE_ILLUS.search(h)
    if m:
        out["artist"] = clean(m.group(1))

    # 卡片大类
    for kw, label in (("ポケモン", "Pokémon"), ("グッズ", "Trainer"),
                      ("サポート", "Trainer"), ("スタジアム", "Trainer"),
                      ("エネルギー", "Energy")):
        if kw in h:
            out["supertype"] = label
            break
    return out


def upsert_set(conn, code: str, name: str, release: str | None, is_promo: bool) -> str:
    set_id = f"ja:{code}"
    era = db.era_of("ja", None, code, name)
    conn.execute(
        """INSERT INTO sets(set_id,lang,code,name,name_en,series,era,release_date,
               printed_total,total,is_promo,source_url)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
           ON CONFLICT(set_id) DO UPDATE SET
             name=excluded.name, era=excluded.era,
             release_date=COALESCE(excluded.release_date, sets.release_date),
             is_promo=excluded.is_promo""",
        (set_id, "ja", code, name, None, "ポケモンカードゲーム", era, release,
         None, None, int(is_promo), f"{BASE}/ex/{code}/"),
    )
    return set_id


def fetch_set_release(code: str) -> str | None:
    """扩展包页面上找发售日，找不到返回 None（不猜）。"""
    try:
        h = get_text(f"{BASE}/ex/{code}/", prefer_curl=False)
    except Exception:
        return None
    m = re.search(r"(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日", h)
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    m = re.search(r"発売日[^0-9]{0,20}(\d{4})[./\-](\d{1,2})[./\-](\d{1,2})", h)
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pages", type=int, default=0)
    ap.add_argument("--max-cards", type=int, default=0)
    ap.add_argument("--start-page", type=int, default=1)
    ap.add_argument("--refresh-sets", action="store_true")
    args = ap.parse_args()

    conn = db.init()

    if args.refresh_sets:
        codes = [r["code"] for r in conn.execute(
            "SELECT code FROM sets WHERE lang='ja' AND code IS NOT NULL")]
        for i, code in enumerate(codes, 1):
            rel = fetch_set_release(code)
            if rel:
                conn.execute("UPDATE sets SET release_date=? WHERE set_id=?",
                             (rel, f"ja:{code}"))
            conn.commit()
            print(f"[{i}/{len(codes)}] {code} -> {rel}")
        return

    first = get_json(f"{API}?page={args.start_page}&regulation_sidebar_form=all")
    max_page = int(first.get("maxPage") or 1)
    print(f"日版总卡数 {first.get('hitCnt')}，共 {max_page} 页")

    end_page = max_page
    if args.pages:
        end_page = min(max_page, args.start_page + args.pages - 1)

    seen = 0
    set_cache: dict[str, str | None] = {}
    for page in range(args.start_page, end_page + 1):
        data = first if page == args.start_page else get_json(
            f"{API}?page={page}&regulation_sidebar_form=all")
        cards = data.get("cardList") or []
        for item in cards:
            cid = item.get("cardID")
            if not cid:
                continue
            full_id = f"ja:{cid}"
            if conn.execute("SELECT 1 FROM cards WHERE card_id=?", (full_id,)).fetchone():
                seen += 1
                continue

            try:
                h = get_text(f"{BASE}/card-search/details.php/card/{cid}")
            except Exception as e:  # noqa: BLE001
                print(f"  跳过 {cid}: {e}")
                continue
            info = parse_detail(h)
            name = info.get("name") or item.get("cardNameViewText")
            code = info.get("set_code") or "unknown"
            set_name = info.get("set_name") or code
            is_promo = any(k in set_name for k in PROMO_SET_HINTS) or code.upper().endswith("-P")

            if code not in set_cache:
                set_cache[code] = fetch_set_release(code) if not code.startswith("unknown") else None
            set_id = upsert_set(conn, code, set_name, set_cache[code], is_promo)

            rcode = info.get("rarity_code")
            tier = db.rarity_tier(rcode)
            rarity = db.RARITY_LABEL_JA.get(rcode, rcode.upper() if rcode else None)
            diff, detail = scoring.difficulty(None, None, tier, is_promo, set_cache[code])

            base_src = f"日版《{set_name}》"
            if set_cache[code]:
                base_src += f"（{set_cache[code]} 发售）"
            if info.get("number"):
                base_src += f"，编号 {info['number']}/{info.get('set_total')}"
            if is_promo:
                base_src += "；プロモ流通：イベント配布・購入特典・キャンペーン等多渠道"

            thumb = item.get("cardThumbFile") or ""
            img = BASE + thumb if thumb.startswith("/") else thumb

            conn.execute(
                """INSERT INTO cards(card_id,set_id,lang,number,number_int,set_total,name,
                      search_name,rarity,rarity_code,rarity_tier,artist,supertype,
                      image_small,image_large,release_date,is_promo,source_label,
                      source_url,difficulty,diff_json,updated_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(card_id) DO UPDATE SET
                     name=excluded.name, rarity=excluded.rarity,
                     rarity_tier=excluded.rarity_tier, image_large=excluded.image_large,
                     source_label=excluded.source_label, updated_at=excluded.updated_at""",
                (full_id, set_id, "ja", info.get("number"),
                 int(re.sub(r"\D", "", info["number"])) if info.get("number") else None,
                 info.get("set_total"), name, db.normalize_search_name(name),
                 rarity, rcode, tier, info.get("artist"), info.get("supertype"),
                 img, img, set_cache[code], int(is_promo), base_src,
                 f"{BASE}/card-search/details.php/card/{cid}",
                 diff, json.dumps(detail, ensure_ascii=False),
                 datetime.now(timezone.utc).isoformat(timespec="seconds")),
            )
            conn.commit()   # 必须逐张提交：下次循环要发网络请求，
                            # 事务挂在请求之间会把库锁住几十秒，价格同步脚本就写不进来
            seen += 1
            if seen % 25 == 0:
                print(f"  已入库 {seen} 张（第 {page} 页）")
            if args.max_cards and seen >= args.max_cards:
                break
        conn.commit()
        print(f"[页 {page}/{end_page}] 累计 {seen} 张")
        if args.max_cards and seen >= args.max_cards:
            break

    db.set_meta(conn, "ja_last_sync", datetime.now().isoformat(timespec="seconds"))
    conn.commit()
    print(f"完成：本次处理 {seen} 张")


if __name__ == "__main__":
    main()
