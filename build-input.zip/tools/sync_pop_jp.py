"""日版 PSA Pop 同步：按日版系列码精确匹配

关键发现：PSA 收录了日文版卡组，且系列名里直接带日版系列码：
    Pokemon Japanese Sv1a-Triplet Beat       -> SV1a
    Pokemon Japanese Sv2a-Pokemon Card 151   -> SV2a
所以不需要「日文名 → 英文名」对照表，按码匹配即可，还能顺带拿到英文系列名。

做法：
  1. 遍历年份页，只收名字含 "Japanese" 的系列
  2. 从名字里抽系列码（Japanese XXX-...），对上本地 sets.code
  3. 系列页表格按卡号匹配到本地日版卡，写 pop
  4. 顺手把英文系列名写进 sets.name_en（补上只有码没有名字的系列）

用法：
    python tools/sync_pop_jp.py --year 2023 --dry-run
    python tools/sync_pop_jp.py --year 2023
    python tools/sync_pop_jp.py --years 2025,2024,2023
"""
from __future__ import annotations

import argparse
import os
import random
import time
import re
import sys
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tools"))

import db
from sync_pop import BASE, TCG, goto, launch, num_key, parse_table, upsert_pop

RE_CODE = re.compile(r"Japanese\s+([A-Za-z0-9]+)\s*-")


def collect_jp_sets(page, year: str) -> list[tuple[str, str, str]]:
    """返回 [(PSA系列名, 链接, 日版系列码)]"""
    out: list[tuple[str, str, str]] = []
    try:
        page.select_option("select[name='tableSets_length']", "250")
        page.wait_for_timeout(2500)
    except Exception:
        pass
    pages = ["1"]
    try:
        opts = page.eval_on_selector_all(
            "select", "els=>els.filter(s=>!s.name).map(s=>[...s.options].map(o=>o.value))")
        if opts:
            pages = opts[0]
    except Exception:
        pass

    for pg in pages:
        if pg != "1":
            try:
                page.select_option("select:not([name])", pg)
                page.wait_for_timeout(2000)
            except Exception:
                break
        items = page.eval_on_selector_all(
            "a[href*='/pop/tcg-cards/']",
            "els=>els.map(e=>[e.innerText.trim(), e.getAttribute('href')])")
        for name, href in items:
            low = name.lower()
            # tcg-cards 下混着高达/数码宝贝等其他 TCG，必须先卡 Pokemon 开头
            if not low.startswith("pokemon") or "japanese" not in low or not href:
                continue
            m = RE_CODE.search(name)
            if not m:
                continue
            out.append((name, BASE + href, m.group(1).upper()))
    seen, uniq = set(), []
    for n, h, c in out:
        if h not in seen:
            seen.add(h)
            uniq.append((n, h, c))
    return uniq


def english_name(psa_name: str) -> str | None:
    """Pokemon Japanese Sv1a-Triplet Beat -> Triplet Beat"""
    m = re.search(r"Japanese\s+[A-Za-z0-9]+\s*-\s*(.+)$", psa_name)
    if m:
        return m.group(1).strip()
    return psa_name.replace("Pokemon Japanese", "").strip() or None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--year")
    ap.add_argument("--years", help="逗号分隔，如 2025,2024,2023")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--headed", action="store_true")
    ap.add_argument("--max-sets", type=int, default=0)
    ap.add_argument("--only", help="只跑系列码匹配该值的（调试用）")
    args = ap.parse_args()

    years = []
    if args.years:
        years = [y.strip() for y in args.years.split(",") if y.strip()]
    elif args.year:
        years = [args.year]
    if not years:
        print("请指定 --year 或 --years")
        return

    from playwright.sync_api import sync_playwright

    conn = db.init()
    report_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # 本地日版系列：码(大写) -> set_id
    local = {r["code"].upper(): r["set_id"] for r in conn.execute(
        "SELECT code, set_id FROM sets WHERE lang='ja' AND code IS NOT NULL")}
    # 本地日版卡：set_id + 卡号 -> card_id
    cards: dict[tuple[str, str], list[str]] = {}
    for r in conn.execute(
            "SELECT card_id, set_id, number FROM cards WHERE lang='ja'"):
        cards.setdefault((r["set_id"], num_key(r["number"])), []).append(r["card_id"])
    print(f"本地日版系列 {len(local)} 个，卡 {sum(len(v) for v in cards.values())} 张")

    total_matched = total_written = 0
    with sync_playwright() as pw:
        ctx = launch(pw, headless=not args.headed)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.set_default_timeout(6000)

        for year in years:
            if not goto(page, TCG):
                print(f"{year}: 打开 TCG 大类失败")
                continue
            year_url = next((BASE + l for l in page.eval_on_selector_all(
                "a[href*='/pop/tcg-cards/']",
                "e=>[...new Set(e.map(x=>x.getAttribute('href')))]")
                if re.match(rf"^/pop/tcg-cards/{year}/\d+$", l)), None)
            if not year_url:
                print(f"{year}: 找不到年份页")
                continue
            goto(page, year_url)
            sets = collect_jp_sets(page, year)
            print(f"\n===== {year}：日文版系列 {len(sets)} 个")
            if args.only:
                sets = [t for t in sets if t[2] == args.only.upper()]
                print(f"（--only 过滤后剩 {len(sets)} 个）")
            if args.max_sets:
                sets = sets[: args.max_sets]

            for i, (psa_name, url, code) in enumerate(sets, 1):
                set_id = local.get(code)
                if not set_id:
                    print(f"  [{i}/{len(sets)}] {code:8} 本地无此系列，跳过")
                    continue
                if not goto(page, url):
                    print(f"  [{i}/{len(sets)}] {code:8} 打开失败")
                    continue
                try:
                    page.wait_for_selector("table tr td", timeout=15000)
                    page.select_option("select[name='tableSets_length']", "250")
                    page.wait_for_timeout(2000)
                except Exception:
                    pass
                rows = parse_table(page)
                # 同样按卡汇总多行变体，避免后写覆盖前写
                agg: dict[str, list[int]] = {}
                vrows: list[tuple] = []
                for row in rows:
                    if not row["total"]:
                        continue
                    for cid in cards.get((set_id, num_key(row["no"])), []):
                        a = agg.setdefault(cid, [0, 0])
                        a[0] += row["psa10"] or 0
                        a[1] += row["total"]
                        vrows.append((cid, row.get("variant") or "标准",
                                      row["psa10"] or 0, row["total"]))
                hits = len(agg)
                total_matched += hits
                if not args.dry_run:
                    for cid, (p10, tot) in agg.items():
                        upsert_pop(conn, cid, p10, tot, report_date)
                        total_written += 1
                    for cid, var, p10, tot in vrows:
                        conn.execute(
                            "INSERT INTO card_variants(card_id,variant,psa_total,psa_10,"
                            "report_date) VALUES(?,?,?,?,?) "
                            "ON CONFLICT(card_id,variant,report_date) DO UPDATE SET "
                            "psa_total=excluded.psa_total, psa_10=excluded.psa_10",
                            (cid, var, tot, p10, report_date))
                if not args.dry_run:
                    en = english_name(psa_name)
                    if en:
                        conn.execute(
                            "UPDATE sets SET name_en=? WHERE set_id=? "
                            "AND (name_en IS NULL OR name_en='')", (en, set_id))
                    conn.commit()
                print(f"  [{i}/{len(sets)}] {code:8} 卡{len(rows):5} 匹配{hits:5} | {psa_name[:40]}")
                time.sleep(random.uniform(2.5, 5.5))

        ctx.close()

    print(f"\n完成：匹配 {total_matched}，写入 {total_written}"
          + ("（--dry-run 未写库）" if args.dry_run else ""))


if __name__ == "__main__":
    main()
