"""PSA 登录态采集（只需做一次）

psacard.com 的 pop 报告现在要登录（307 跳 app.collectors.com/signin）。
抓取脚本跑在独立的 Chromium 里，拿不到你日常浏览器里的 cookie，
所以要走这一步：弹出一个浏览器窗口，你在里面登录，脚本把登录态存下来。

用法：
    python tools/psa_login.py

窗口里登录完成后不用关窗口，脚本会自动检测到已跳回 pop 页面并保存。
登录态保存在 data/psa_profile/（持久化用户目录），后续 sync_pop.py 直接复用。
"""
from __future__ import annotations

import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROFILE = os.path.join(ROOT, "data", "psa_profile")
STATE = os.path.join(ROOT, "data", "psa_state.json")
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
WAIT_SECONDS = 420


def _launch(pw, headless: bool):
    """优先用系统已装的 Edge / Chrome 开窗口（Playwright 自带 Chromium 在这台
    机器上下载不下来），都不可用时再回退到自带内核。"""
    common = dict(user_data_dir=PROFILE, headless=headless, locale="en-US",
                  user_agent=UA, viewport={"width": 1280, "height": 900},
                  args=["--disable-blink-features=AutomationControlled",
                        "--no-sandbox"])
    last: Exception | None = None
    for ch in ("msedge", "chrome"):
        try:
            print(f"  使用系统浏览器：{ch}")
            return pw.chromium.launch_persistent_context(channel=ch, **common)
        except Exception as e:  # noqa: BLE001
            last = e
            print(f"  {ch} 不可用：{str(e)[:120]}")
    print("  回退到 Playwright 自带 Chromium")
    return pw.chromium.launch_persistent_context(**common)


def main() -> None:
    from playwright.sync_api import sync_playwright

    os.makedirs(PROFILE, exist_ok=True)
    print("=" * 62)
    print("  即将弹出一个浏览器窗口，请在里面登录 PSA / Collectors 账号")
    print("  登录成功后会自动跳回 PSA 的 pop 页面，脚本会自动保存登录态")
    print(f"  最长等待 {WAIT_SECONDS // 60} 分钟；期间请不要关闭窗口")
    print("=" * 62)

    with sync_playwright() as pw:
        ctx = _launch(pw, headless=False)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        try:
            page.goto("https://www.psacard.com/pop", timeout=90000)
        except Exception as e:  # noqa: BLE001
            print("打开 pop 页失败：", e)

        t0 = time.time()
        saved = False
        last = ""
        while time.time() - t0 < WAIT_SECONDS:
            try:
                url = page.url
                if url != last:
                    print("  当前页面：", url[:110])
                    last = url
                if "signin" not in url.lower() and "psacard.com" in url:
                    body = page.inner_text("body")
                    if len(body) > 800:
                        ctx.storage_state(path=STATE)
                        print("\n✅ 已登录，登录态已保存：")
                        print("   ", STATE)
                        print("   用户目录：", PROFILE)
                        saved = True
                        page.screenshot(path=os.path.join(ROOT, "data", "psa_after_login.png"))
                        break
            except Exception:
                pass
            page.wait_for_timeout(2000)

        if not saved:
            print("\n⚠️  等待超时，没有检测到登录完成。")
            print("   请重跑本脚本，并在窗口里完成登录后再等待几秒。")
        ctx.close()


if __name__ == "__main__":
    main()
