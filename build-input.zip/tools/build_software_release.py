"""Create a code-only release ZIP and latest.json; never include local user data.
Usage: python tools/build_software_release.py --url https://host/pokedex-2.4.0.zip --output /path/to/release
Upload ZIP and latest.json to your trusted static HTTPS release host.
"""
import argparse,hashlib,json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import software_update as sw

def build(output,address,notes):
 sw.url(address);output=Path(output);output.mkdir(parents=True,exist_ok=True)
 archive=output/('pokedex-'+sw.VERSION+'.zip')
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(ROOT.rglob('*')):
   if p.is_file() and sw.allowed(p.relative_to(ROOT).as_posix()) and p.suffix.lower()!='.md':z.write(p,p.relative_to(ROOT))
 m={'version':sw.VERSION,'url':address,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'size':archive.stat().st_size,'notes':notes}
 (output/'latest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),'utf-8')
 return archive
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--url',required=True);p.add_argument('--output',required=True);p.add_argument('--notes',default='');a=p.parse_args();print(build(a.output,a.url,a.notes))
