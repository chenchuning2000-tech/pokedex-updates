"""SNKRDUNK 成交价同步（无头浏览器）

实测要点（2026-11 验证）：
  · 用 curl 请求任何子页都返回 404（反爬伪装），必须真实 Chromium
  · 搜索 URL 是 `?keywords=`（复数），结果项路径为 `/apparels/{id}`
  · 商品页自带「相場」（市场价）与「売買履歴」（成交履歴），
    成交记录含 状态 A/B/C/D、PSA10/PSA9/BGS 等分级、枚数、价格、相对时间
    —— 这就是要落库的成交数据源。

三阶段：
    python tools/sync_snkrdunk.py --probe "リザードン"
    python tools/sync_snkrdunk.py --match --limit 30     # 建卡→商品页映射
    python tools/sync_snkrdunk.py --fetch --limit 30     # 抓相場+成交履歴

时间说明：売買履歴 给的是「36分前」这类相对时间，脚本按抓取时刻换算成
绝对时间；这是估算，误差在分钟级，已在 extra 里标注 rel。
"""
from __future__ import annotations

import argparse
import os
import re
import sys
import time
from datetime import datetime, timedelta, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import db

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
PROFILE = os.path.join(ROOT, "data", "snk_profile")
BASE = "https://snkrdunk.com"

RE_TITLE = re.compile(r"^(?P<name>.+?)\s*\[(?P<code>[A-Za-z0-9\-]+)\s+(?P<num>[0-9A-Za-z\-]+)\s*/\s*(?P<tot>\d+)\]")
RE_PRICE = re.compile(r"¥\s?([\d,]+)")
RE_REL = re.compile(r"(\d+)\s*(分|時間|日|週間|ヶ月)前")
RE_GRADE = re.compile(r"^(PSA\s?10|PSA\s?9|PSA\s?8以下|BGS\s?10\s?(?:BL|GL)?|BGS\s?9\.5|"
                      r"BGS\d以下|ARS\d+\+?|CGC\d*|[A-D]|未開封品)$")
# 行内找状态：PSA/BGS/ARS 系列优先，最后才是单个 A-D
RE_GRADE_INLINE = re.compile(
    r"(PSA\s?10|PSA\s?9|PSA\s?8以下|BGS\s?10\s?(?:BL|GL)?|BGS\s?9\.5|BGS\d以下|"
    r"ARS\d+\+?|CGC\d*|未開封品|(?<![A-Za-z0-9])[A-D](?![A-Za-z0-9]))")


def launch(pw, headed=False):
    # 不用 persistent context：上次进程被杀会留下 SingletonLock，
    # 导致后续启动直接卡死。公开页不需要登录态。
    browser = pw.chromium.launch(
        headless=not headed,
        args=["--disable-blink-features=AutomationControlled", "--no-sandbox",
              "--disable-dev-shm-usage"],
    )
    return browser, browser.new_context(
        locale="ja-JP", user_agent=UA,
        viewport={"width": 1400, "height": 1000},
        extra_http_headers={"Accept-Language": "ja,en;q=0.8"},
    )


def page_of(ctx):
    return ctx.pages[0] if ctx.pages else ctx.new_page()


def rel_to_dt(m) -> str:
    n, unit = int(m.group(1)), m.group(2)
    delta = {"分": timedelta(minutes=n), "時間": timedelta(hours=n),
             "日": timedelta(days=n), "週間": timedelta(weeks=n),
             "ヶ月": timedelta(days=30 * n)}.get(unit, timedelta(0))
    return (datetime.now(timezone.utc) - delta).isoformat(timespec="seconds")


def parse_product(page) -> dict:
    """返回 {title, name, code, number, market, grades, trades}"""
    title = ""
    try:
        title = page.inner_text("h1").strip().split("\n")[0]
    except Exception:
        pass
    out = {"title": title, "market": None, "grades": {}, "trades": []}
    m = RE_TITLE.match(title)
    if m:
        out.update(name=m.group("name").strip(), code=m.group("code"),
                   number=m.group("num"), total=int(m.group("tot")))

    body = page.inner_text("body")

    # 相場定位：锚在「購入手数料」之后、分级表（PSA10）之前的那一段。
    # 早期版本取「全文第一个 ≥100 的价格」，页面异常时会抓到推荐位价格（三张卡同为 18000），
    # 这里改成有锚点的区间截取。
    start = body.find("購入手数料")
    endc = body.find("PSA10")
    if start < 0:
        start = body.find("販売価格")
    if start < 0:
        start = 0
    seg = body[start: (endc if endc > start else start + 600)][:600]
    for pm in RE_PRICE.finditer(seg):
        val = float(pm.group(1).replace(",", ""))
        if val >= 100:
            out["market"] = val
            break

    # 分级相場：把「PSA10\n¥99,000~」这类成对读出
    lines = [l.strip() for l in body.split("\n") if l.strip()]
    for i, ln in enumerate(lines):
        if RE_GRADE.match(ln) and i + 1 < len(lines):
            pm = RE_PRICE.search(lines[i + 1])
            if pm:
                out["grades"][ln.replace(" ", "")] = float(pm.group(1).replace(",", ""))

    # 売買履歴：含相对时间的行，同行或邻近行里有 状态 / 枚数 / 价格
    for i, ln in enumerate(lines):
        rm = RE_REL.search(ln)
        if not rm:
            continue
        win = lines[i:i + 4]
        grade = None
        for w in win:
            gm = RE_GRADE_INLINE.search(w)
            if gm:
                grade = gm.group(1).replace(" ", "")
                break
        price = None
        for w in win:
            pm = RE_PRICE.search(w)
            if pm:
                price = float(pm.group(1).replace(",", ""))
                break
        cnt = None
        for w in win:
            cm = re.search(r"(\d+)\s*枚", w)
            if cm:
                cnt = int(cm.group(1))
                break
        if price:
            out["trades"].append({"ts": rel_to_dt(rm), "rel": rm.group(0),
                                  "price": price, "grade": grade, "count": cnt})
    return out


def goto_retry(page, url: str, tries: int = 3) -> bool:
    """弱网下 domcontentloaded 常等到超时；用 commit 先拿到文档，
    再单独等 h1，成功率高很多。"""
    for k in range(tries):
        try:
            page.goto(url, wait_until="commit", timeout=30000)
            page.wait_for_selector("h1", timeout=15000)
            return True
        except Exception:
            if k == tries - 1:
                return False
            time.sleep(2)
    return False


def load_more(page, rounds: int = 3) -> None:
    """点「もっと見る」把成交履歴拉长，拿更多历史点。"""
    for _ in range(rounds):
        try:
            btn = page.query_selector(
                "button:has-text('もっと見る'), a:has-text('もっと見る')")
            if not btn:
                break
            btn.click()
            page.wait_for_timeout(1800)
        except Exception:
            break


def match_one(page, card: dict) -> tuple[str | None, dict | None]:
    q = f"{card['name']} {card['number']}"
    if not goto_retry(page, f"{BASE}/search?keywords={q}", tries=2):
        return None, None
    page.wait_for_timeout(3500)
    items = page.eval_on_selector_all(
        "a[href*='/apparels/']",
        "els=>els.map(e=>({href:e.href,text:(e.innerText||'').slice(0,120)}))")
    code = (card.get("code") or "").upper()
    num = str(card.get("number") or "")
    best, best_score = None, 0.0
    for it in items:
        t = it["text"].upper()
        s = 0.0
        if f"[{code} {num}/" in t or f"[{code} {num.zfill(3)}/" in t:
            s = 0.95
        elif code and f"[{code} " in t and re.search(rf"\b{re.escape(num)}\b", t):
            s = 0.8
        elif num and re.search(rf"\b{re.escape(num)}\b", t):
            s = 0.5
        if s > best_score:
            best, best_score = it["href"], s
    return best, {"confidence": round(best_score, 2)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--probe")
    ap.add_argument("--match", action="store_true")
    ap.add_argument("--fetch", action="store_true")
    ap.add_argument("--limit", type=int, default=20)
    ap.add_argument("--headed", action="store_true")
    ap.add_argument("--more", type=int, default=2, help="点几次「もっと見る」")
    args = ap.parse_args()

    from playwright.sync_api import sync_playwright

    if args.probe:
        with sync_playwright() as pw:
            browser, ctx = launch(pw, args.headed)
            p = page_of(ctx)
            p.goto(f"{BASE}/search?keywords={args.probe}", wait_until="domcontentloaded",
                   timeout=60000)
            p.wait_for_timeout(4000)
            links = p.eval_on_selector_all(
                "a[href*='/apparels/']",
                "els=>[...new Set(els.map(e=>e.href))]")
            print(f"搜索「{args.probe}」得到 {len(links)} 个商品")
            for l in links[:5]:
                print("  ", l)
            if links:
                p.goto(links[0], wait_until="domcontentloaded", timeout=60000)
                p.wait_for_timeout(4500)
                p.screenshot(path=os.path.join(ROOT, "data", "snk_product.png"))
                d = parse_product(p)
                print("解析结果：", {k: v for k, v in d.items() if k != "trades"})
                print("成交样本：", d["trades"][:5])
            browser.close()
        return

    conn = db.init()

    if args.match:
        rows = [dict(r) for r in conn.execute(
            "SELECT c.card_id,c.name,c.number,s.code FROM cards c "
            "JOIN sets s ON s.set_id=c.set_id WHERE c.lang='ja' "
            "AND c.card_id NOT IN (SELECT card_id FROM card_links "
            "WHERE source='snkrdunk') LIMIT ?", (args.limit,))]
        print(f"待匹配 {len(rows)} 张")
        with sync_playwright() as pw:
            browser, ctx = launch(pw, args.headed)
            p = page_of(ctx)
            for i, c in enumerate(rows, 1):
                try:
                    url, meta = match_one(p, c)
                except Exception as e:  # noqa: BLE001
                    print(f"[{i}/{len(rows)}] {c['name']} 失败 {e}")
                    continue
                if url and meta["confidence"] >= 0.5:
                    conn.execute(
                        "INSERT INTO card_links(card_id,source,external_id,url,matched_by,"
                        "confidence,updated_at) VALUES(?,?,?,?,?,?,?) "
                        "ON CONFLICT(card_id,source) DO UPDATE SET url=excluded.url,"
                        "confidence=excluded.confidence,updated_at=excluded.updated_at",
                        (c["card_id"], "snkrdunk", url.rstrip("/").split("/")[-1], url,
                         f"{c.get('code')} {c['number']}", meta["confidence"],
                         datetime.now(timezone.utc).isoformat(timespec="seconds")))
                    conn.commit()
                    print(f"[{i}/{len(rows)}] {c['name']} #{c['number']} -> {url} "
                          f"({meta['confidence']})")
                else:
                    print(f"[{i}/{len(rows)}] {c['name']} #{c['number']} 未匹配")
                time.sleep(1.2)
            browser.close()
        return

    if args.fetch:
        rows = [dict(r) for r in conn.execute(
            "SELECT l.card_id, l.url, c.name, c.number, s.code FROM card_links l "
            "JOIN cards c ON c.card_id=l.card_id "
            "JOIN sets s ON s.set_id=c.set_id "
            "WHERE l.source='snkrdunk' AND l.url IS NOT NULL LIMIT ?", (args.limit,))]
        print(f"待抓价 {len(rows)} 张")
        with sync_playwright() as pw:
            browser, ctx = launch(pw, args.headed)
            p = page_of(ctx)
            for i, r in enumerate(rows, 1):
                try:
                    if not goto_retry(p, r["url"]):
                        print(f"[{i}/{len(rows)}] {r['name']} 打开超时，跳过")
                        continue
                    p.wait_for_timeout(3800)
                    if args.more:
                        load_more(p, args.more)
                    d = parse_product(p)
                except Exception as e:  # noqa: BLE001
                    print(f"[{i}/{len(rows)}] {r['name']} 失败 {e}")
                    continue

                # 校验：标题必须解析出系列码与编号，且编号与本卡一致，
                # 否则说明抓到的是错误页/推荐位，宁可跳过也不写脏数据
                num = str(r.get("number") or "").lstrip("0")
                if not d.get("code") or (num and str(d.get("number")).lstrip("0") != num):
                    print(f"[{i}/{len(rows)}] {r['name']} 校验未过（{d.get('code')} "
                          f"{d.get('number')}），跳过")
                    continue

                n = 0
                now = datetime.now(timezone.utc).isoformat(timespec="seconds")
                # 相場作为当日挂价快照
                if d["market"]:
                    conn.execute(
                        "INSERT OR IGNORE INTO price_points(card_id,source,kind,ts,price,"
                        "currency,condition,url,extra) VALUES(?,?,?,?,?,?,?,?,?)",
                        (r["card_id"], "snkrdunk", "listing", now[:10] + "T00:00:00",
                         d["market"], "JPY", "raw", r["url"], "market=相場"))
                for t in d["trades"]:
                    conn.execute(
                        "INSERT OR IGNORE INTO price_points(card_id,source,kind,ts,price,"
                        "currency,condition,url,extra) VALUES(?,?,?,?,?,?,?,?,?)",
                        (r["card_id"], "snkrdunk", "trade", t["ts"], t["price"], "JPY",
                         t.get("grade") or "raw", r["url"], f"rel={t['rel']}"))
                    n += 1
                # PSA10 分档相場单独存一条，便于对比评级溢价
                if d["grades"].get("PSA10"):
                    conn.execute(
                        "INSERT OR IGNORE INTO price_points(card_id,source,kind,ts,price,"
                        "currency,condition,url,extra) VALUES(?,?,?,?,?,?,?,?,?)",
                        (r["card_id"], "snkrdunk", "listing", now[:10] + "T00:00:00",
                         d["grades"]["PSA10"], "JPY", "PSA 10", r["url"], "grade_market"))
                conn.commit()
                print(f"[{i}/{len(rows)}] {r['name']} 相場 {d['market']} / 成交 {n} 条")
                time.sleep(1.5)
            browser.close()
        return

    print("请指定 --probe / --match / --fetch")


if __name__ == "__main__":
    main()
