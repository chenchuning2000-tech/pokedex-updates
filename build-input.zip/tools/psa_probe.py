"""探查登录后的 PSA pop 页面结构（一次性诊断工具）

用途：登录态拿到后，先看清 pop 页的 DOM 与它自己的接口，再写解析。
输出：data/psa_probe.json（抓到的请求）、data/psa_pop*.png（截图）、控制台摘要。
"""
from __future__ import annotations

import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROFILE = os.path.join(ROOT, "data", "psa_profile")
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")


def main() -> None:
    from playwright.sync_api import sync_playwright

    hits: list[dict] = []
    with sync_playwright() as pw:
        ctx = pw.chromium.launch_persistent_context(
            PROFILE, headless=True, channel="msedge", locale="en-US",
            user_agent=UA, viewport={"width": 1440, "height": 1000},
            args=["--disable-blink-features=AutomationControlled", "--no-sandbox"])

        page = ctx.pages[0] if ctx.pages else ctx.new_page()

        def on_resp(r):
            u = r.url
            if r.request.resource_type not in ("xhr", "fetch", "document"):
                return
            if any(k in u for k in ("/pop", "api", "graphql", "search")):
                item = {"status": r.status, "url": u[:300], "type": r.request.resource_type}
                ct = r.headers.get("content-type") or ""
                if "json" in ct:
                    try:
                        item["body"] = r.text()[:3000]
                    except Exception:
                        pass
                hits.append(item)

        page.on("response", on_resp)

        page.goto("https://www.psacard.com/pop", wait_until="domcontentloaded", timeout=90000)
        page.wait_for_timeout(6000)
        print("URL:", page.url)
        print("TITLE:", page.title())
        page.screenshot(path=os.path.join(ROOT, "data", "psa_pop1.png"))
        txt = page.inner_text("body")
        print("BODY LEN:", len(txt))
        print("--- 前 700 字 ---")
        print(txt[:700])

        # 找搜索框
        box = page.query_selector("input[type=search], input[placeholder*=earch], "
                                 "input[name*=earch]")
        print("\n搜索框:", bool(box))
        if box:
            box.click()
            box.fill("Charizard")
            page.keyboard.press("Enter")
            page.wait_for_timeout(6000)
            print("搜索后 URL:", page.url)
            page.screenshot(path=os.path.join(ROOT, "data", "psa_pop2.png"))
            t2 = page.inner_text("body")
            print("--- 搜索结果前 800 字 ---")
            print(t2[:800])
            # 结果链接
            links = page.eval_on_selector_all(
                "a[href*='/pop/']", "els=>[...new Set(els.map(e=>e.getAttribute('href')))]")
            print("\n结果链接（前 10）:")
            for l in links[:10]:
                print("   ", l)

        with open(os.path.join(ROOT, "data", "psa_probe.json"), "w", encoding="utf-8") as f:
            json.dump(hits, f, ensure_ascii=False, indent=1)
        print(f"\n捕获 {len(hits)} 条请求 -> data/psa_probe.json")
        for h in hits[:20]:
            print(f"  [{h['status']}] {h['type']:8} {h['url'][:150]}")
        ctx.close()


if __name__ == "__main__":
    main()
