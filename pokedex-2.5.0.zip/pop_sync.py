"""Import the public BetterPop dataset, with conservative bilingual identity checks.
Only two snapshot requests per new build; never queries PSA or a private partner API.
"""
import collections
import gzip
import hashlib
import json
import re
import unicodedata
from datetime import date
from pathlib import Path
import hub
import scoring

BASE='https://better-pop.com/app/'
ROOT=Path(__file__).resolve().parent

def norm(s):
 s=unicodedata.normalize('NFKD',str(s or '')).lower().replace('&','and')
 return re.sub(r'[^a-z0-9]','',s)

def num(s):
 s=str(s or '').split('/')[0].strip().upper()
 return re.sub(r'^0+(?=\d)','',s)

def cardname(s):
 s=re.sub(r'^(Full Art|FA)/','',s or '',flags=re.I)
 s=re.sub(r'-(Reverse Foil|Holo|Gold Star|Hyper|Glossy|Secret)$','',s,flags=re.I)
 return norm(s)

def unpack(core,meta):
 built=date.fromisoformat(meta['built']).isoformat()
 if built>date.today().isoformat(): raise ValueError('来源批次日期在未来')
 sets=core['sets'];cards=core['cards'];n=len(cards['si'])
 required=['si','num','name','par','g10','g9','tot','img','lang']
 if n!=meta['cards'] or len(sets)!=meta['sets']: raise ValueError('批次与卡表数量不一致，停止写入')
 for k in required:
  if len(cards[k])!=n: raise ValueError('来源列长度不一致：'+k)
 rows=[]
 for i in range(n):
  si=cards['si'][i]
  if not isinstance(si,int) or not 0<=si<len(sets): raise ValueError('无效系列索引')
  year,name,lang=sets[si]
  # Source sets can contain cards of several languages; use per-card language too.
  if cards['lang'][i]!=lang: continue
  if lang not in ('en','jp'): continue
  counts=[cards[k][i] for k in ['g10','g9','tot']]
  if any(type(v)!=int or v<0 for v in counts) or sum(counts[:2])>counts[2]: raise ValueError('来源评级数量无效')
  row={k:cards[k][i] for k in required};row.update(year=year,set_name=name,index=i)
  row['identity']=json.dumps([year,name,lang,row['num'],row['name'],row['par']],ensure_ascii=False,separators=(',',':'))
  rows.append(row)
 return rows,built

class Matcher:
 def __init__(self,c):
  self.cards={r['card_id']:dict(r) for r in c.execute('SELECT * FROM cards')}
  self.sets={r['set_id']:dict(r) for r in c.execute('SELECT * FROM sets')}
  self.en_index=collections.defaultdict(list);self.jp_index=collections.defaultdict(list)
  for cid,r in self.cards.items():
   if r['lang']=='en':self.en_index[(r['set_id'],num(r['number']))].append(cid)
   else:
    # Original official image paths retain full SV1S/SV1V etc. The legacy set_id can be collapsed!
    m=re.search(r'/card_images/(?:large|small)/([A-Za-z0-9_-]+)/',r['image_large'] or '')
    if m:self.jp_index[(m[1].upper(),num(r['number']))].append(cid)
  names=json.loads((ROOT/'data/name_map.json').read_text())
  self.jnames={}
  for v in names.values():
   for k in ['ja','ja_hrkt']:
    if v.get(k) and v.get('en'):self.jnames[v[k]]=v['en']
  self.code_years=collections.defaultdict(set)
  for (code,number),cids in self.jp_index.items():
   for cid in cids:
    rel=self.cards[cid]['release_date']
    if rel and rel[:4].isdigit():self.code_years[code].add(int(rel[:4]))
  self.set_cache={}
  self.jp_aliases={}
  self.jp_evidence={}
  self.translated={cid:self.jp_name(r) for cid,r in self.cards.items() if r['lang']=='ja'}
 def jp_name(self,r):
  raw=r['name']
  prefix=''
  for jp,en in [('アローラ','Alolan'),('ガラル','Galarian'),('ヒスイ','Hisuian'),('パルデア','Paldean')]:
   if raw.startswith(jp):prefix=en;raw=raw[len(jp):];break
  # Exact species with optional common suffix; do not guess trainer translations or ownership.
  for name in sorted(self.jnames,key=len,reverse=True):
   if raw==name:return norm(prefix+self.jnames[name])
   if raw.startswith(name) and raw[len(name):].upper() in ('EX','GX','V','VMAX','VSTAR','BREAK'):
    return norm(prefix+self.jnames[name]+raw[len(name):])
  return None
 def en_sets(self,name):
  if name in self.set_cache:return self.set_cache[name]
  aliases={'Game':'en:base1','Game Base II':'en:base2','Expedition':'en:ecard1','Wizards of the Coast Black Star Promos':'en:basep',
   'XY Black Star Promos':'en:xyp','SM Black Star Promo':'en:smp','Sun & Moon Black Star Promos':'en:smp',
   'Swsh Black Star Promo':'en:swshp','Svp EN-SV Black Star Promo':'en:svp',
   'Diamond & Pearl Black Star Promo':'en:dpp','Nintendo Black Star Promos':'en:np'}
  target=aliases.get(name)
  if target in self.sets:result=[target]
  else:
   normalized=norm(name)
   matches=[(len(norm(s['name'])),sid) for sid,s in self.sets.items() if s['lang']=='en' and norm(s['name']) and normalized.endswith(norm(s['name']))]
   longest=max([a for a,b in matches],default=-1)
   result=[sid for n,sid in matches if n==longest]
   # Ambiguous suffix mappings are not accepted.
   if len(result)!=1:result=[]
  # PSA often keeps TG/GG/RC cards inside the main expansion.
  if result:
   main=self.sets[result[0]]['name']
   result += [sid for sid,s in self.sets.items() if s['lang']=='en' and s['name'].startswith(main+' ') and any(k in s['name'] for k in ['Trainer Gallery','Galarian Gallery','Radiant Collection'])]
  self.set_cache[name]=result
  return result
 def infer_jp_sets(self,rows):
  # Infer only if >=10 distinct numbered Pokemon agree and the next-best code has <=1/3 support.
  # Evidence is retained. This never uses prices or Pop to decide identity.
  index=collections.defaultdict(set)
  for (code,number),cids in self.jp_index.items():
   for cid in cids:
    translated=self.translated[cid]
    if translated:index[(number,translated)].add(code)
  source=collections.defaultdict(set)
  source_years=collections.defaultdict(set)
  for r in rows:
   if r['lang']=='jp':
    source[r['set_name']].add((num(r['num']),cardname(r['name'])))
    source_years[r['set_name']].add(r['year'])
  for name,keys in source.items():
   if re.match(r'Japanese\s+([A-Za-z0-9]+)-',name):continue
   counts=collections.Counter(code for key in keys if key[0] for code in index.get(key,[]))
   best=counts.most_common(2)
   if not best:continue
   code,n=best[0];second=best[1][1] if len(best)>1 else 0
   supported=sum(1 for key in keys if key in index)
   years=self.code_years.get(code,set())
   # Old Japanese cards used Pokedex numbers, which mimic modern Pokemon 151 numbering.
   # Reject historical sets before this catalog's numbered-series era and any known year conflict.
   chronology_ok=min(source_years[name])>=2007 and (not years or all(any(abs(y-sy)<=1 for y in years) for sy in source_years[name]))
   if chronology_ok and n>=10 and n>=3*second and n>=.8*max(1,supported):
    self.jp_aliases[name]=code
    self.jp_evidence[name]={'code':code,'distinct_matching_cards':n,'runner_up':second,'supported_keys':supported,'source_years':sorted(source_years[name]),'local_years':sorted(years)}

 def match(self,r):
  if not num(r['num']):return None,'missing_number'
  if r['lang']=='en':
   sids=self.en_sets(r['set_name'])
   if not sids:return None,'unknown_set'
   candidates=[]
   for sid in sids:
    number=num(r['num'])
    prefix={'en:swshp':'SWSH','en:smp':'SM','en:xyp':'XY','en:bwp':'BW','en:dpp':'DP','en:hsp':'HGSS'}.get(sid)
    choices=self.en_index.get((sid,number),[])
    if prefix and number.isdigit():
     choices += [cid for (setid,n),ids in self.en_index.items() if setid==sid and n.startswith(prefix) and num(n[len(prefix):])==number for cid in ids]
    candidates.extend(cid for cid in choices if cardname(self.cards[cid]['name'])==cardname(r['name']))
   if len(candidates)!=1:return None,'name_or_number_ambiguous'
   cid=candidates[0]
   image=r['img'] or ''
   if image.startswith('p:'):
    image_id='en:'+image[2:].replace('/','-')
    if image_id in self.cards and image_id!=cid:return None,'image_conflict'
   return cid,'set_number_name'
  m=re.match(r'Japanese\s+([A-Za-z0-9]+)-',r['set_name'])
  code=m[1].upper() if m else self.jp_aliases.get(r['set_name'])
  if not code:return None,'unknown_jp_code'
  candidates=self.jp_index.get((code,num(r['num'])),[])
  if len(candidates)!=1:return None,'jp_number_ambiguous'
  cid=candidates[0];translated=self.translated[cid]
  if translated and translated!=cardname(r['name']):return None,'jp_name_conflict'
  return cid,('official_image_code_number' if m else 'crosschecked_set_code_number')+('_name' if translated else '')

def plan(c,core,meta):
 rows,built=unpack(core,meta);matcher=Matcher(c);matcher.infer_jp_sets(rows)
 duplicate=collections.Counter(r['identity'] for r in rows)
 matches=[];unmatched=[];reasons=collections.Counter()
 for r in rows:
  if duplicate[r['identity']]>1:cid,reason=None,'duplicate_source_key'
  else:cid,reason=matcher.match(r)
  if cid:
   r.update(card_id=cid,matched_by=reason);matches.append(r)
  else:
   r['reason']=reason;unmatched.append(r);reasons[reason]+=1
 return dict(date=built,source_rows=len(rows),matched_rows=len(matches),matched_cards=len({r['card_id'] for r in matches}),
  unmatched_rows=len(unmatched),reasons=dict(reasons),jp_set_evidence=matcher.jp_evidence),matches,unmatched

def apply(c,core,meta):
 report,rows,unmatched=plan(c,core,meta)
 built=report['date'];fetched=hub.now();groups=collections.defaultdict(list)
 # Persist full source and unmatched queue for audit, without treating unmatched rows as local cards.
 folder=ROOT/'data'/'pop_snapshots';folder.mkdir(exist_ok=True)
 snapshot=folder/(built+'.json.gz')
 if not snapshot.exists():
  with gzip.open(str(snapshot)+'.tmp','wt',encoding='utf-8') as f:json.dump({'meta':meta,'core':core},f,ensure_ascii=False)
  Path(str(snapshot)+'.tmp').replace(snapshot)
 c.execute('''CREATE TABLE IF NOT EXISTS pop_matches (source_id TEXT,report_date TEXT,card_id TEXT,source_json TEXT,matched_by TEXT,PRIMARY KEY(source_id,report_date))''')
 try:
  for r in rows:
   ident=hashlib.sha256(r['identity'].encode()).hexdigest()
   # Preserve full source name: Holo and Reverse Foil can live in NAME even when PAR is Base.
   variant=f"{r['year']} {r['set_name']} · {r['name']} · {r['par'] or '标准'}"
   hub.write_observation(c,dict(card_id=r['card_id'],source='betterpop',metric='pop',variant=variant,
    report_date=built,value=r['g10'],total=r['tot'],currency='',condition='PSA',url=BASE,
    fetched_at=fetched,external_id=ident))
   c.execute('INSERT OR REPLACE INTO pop_matches VALUES(?,?,?,?,?)',(ident,built,r['card_id'],json.dumps(r,ensure_ascii=False),r['matched_by']))
   groups[r['card_id']].append(r)
  filled=updated=preserved=0
  for cid,items in groups.items():
   old=c.execute('SELECT * FROM cards WHERE card_id=?',(cid,)).fetchone()
   total=sum(r['tot'] for r in items);p10=sum(r['g10'] for r in items);p9=sum(r['g9'] for r in items)
   # Snapshot-derived aggregate is explicitly labelled, never advertised as an official complete total.
   hub.write_observation(c,dict(card_id=cid,source='betterpop',metric='pop',variant='__all__',report_date=built,
    value=p10,total=total,currency='',condition='PSA',url=BASE,fetched_at=fetched,external_id='matched_variants'))
   if old['psa_report_date'] and old['psa_report_date']>built:
    preserved+=1;continue
   if old['psa_total'] is None:filled+=1
   else:updated+=1
   difficulty,detail=scoring.difficulty(old['price_usd'],total,old['rarity_tier'],bool(old['is_promo']),old['release_date'])
   c.execute('''UPDATE cards SET psa_total=?,psa_10=?,psa_9=?,psa_8=NULL,psa_7=NULL,psa_half=NULL,psa_lower=NULL,
    psa10_rate=?,psa_report_date=?,pop_updated=?,pop_source='betterpop',pop_scope='matched_variants',difficulty=?,diff_json=? WHERE card_id=?''',
    (total,p10,p9,scoring.psa10_rate(p10,total),built,fetched,difficulty,json.dumps(detail),cid))
  report.update(new_coverage=filled,refreshed_totals=updated,preserved_newer=preserved)
  labels=sorted({r['par'] or 'Base' for r in rows}|{'Holo','Reverse Foil','Full Art','Master Ball','1st Edition','Shadowless'})
  c.execute('INSERT OR REPLACE INTO source_cache VALUES(?,?)',('betterpop_variant_labels',json.dumps(labels)))
  c.execute('INSERT OR REPLACE INTO source_cache VALUES(?,?)',('betterpop_build',built))
  c.execute('INSERT OR REPLACE INTO source_cache VALUES(?,?)',('betterpop_report',json.dumps(report,ensure_ascii=False)))
  c.commit()
 except Exception:c.rollback();raise
 (folder/'latest-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 with gzip.open(folder/'unmatched.json.gz','wt',encoding='utf-8') as f:json.dump(unmatched,f,ensure_ascii=False)
 return report

def sync(c):
 import updater
 meta=updater.fetch(BASE+'data/meta.json')
 last=updater.cv(c,'betterpop_build')
 if last and meta['built']<=last:return 0,0,'BetterPop 批次未变化'
 core=updater.fetch(BASE+'data/core.json',meta['built'])
 report=apply(c,core,meta)
 return 0,report['matched_rows'],f"批次 {report['date']}：{report['matched_cards']} 张卡 / {report['matched_rows']} 条变体，新增覆盖 {report['new_coverage']} 张；歧义记录保留待核验"

if __name__=='__main__':
 import argparse,db
 ap=argparse.ArgumentParser();ap.add_argument('--core',required=True);ap.add_argument('--meta',required=True);ap.add_argument('--apply',action='store_true');a=ap.parse_args()
 c=db.init();hub.init(c)
 core=json.loads(Path(a.core).read_text());meta=json.loads(Path(a.meta).read_text())
 if a.apply:
  import updater
  with updater.ProcessLock():updater.backup(c);report=apply(c,core,meta)
 else:
  report,rows,unmatched=plan(c,core,meta)
  Path('pop-research/matched-preview.json').write_text(json.dumps(rows,ensure_ascii=False))
  Path('pop-research/unmatched-preview.json').write_text(json.dumps(unmatched,ensure_ascii=False))
 print(json.dumps(report,ensure_ascii=False,indent=2));c.close()
