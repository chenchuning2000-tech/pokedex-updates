param([switch]$Remove)
$ErrorActionPreference = 'Stop'
$taskName = 'PokemonCardDex-DailyUpdate'
if ($Remove) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
    Write-Host 'Daily update task removed.'
    exit
}
$python = (Get-Command python -ErrorAction Stop).Source
& $python -c "import sys; assert sys.version_info >= (3,10), 'Python 3.10+ required'"
if ($LASTEXITCODE -ne 0) { throw 'Python 3.10+ is required.' }
$script = Join-Path $PSScriptRoot 'updater.py'
$action = New-ScheduledTaskAction -Execute $python -Argument ('"' + $script + '" --scheduled') -WorkingDirectory $PSScriptRoot
$trigger = New-ScheduledTaskTrigger -Daily -At '09:00'
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 4) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$principal = New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
Write-Host 'Installed: daily at 09:00 local time, while this user is logged in. Missed runs start when available.'
Write-Host 'Keep this folder in its current location. The computer must be on and online.'
